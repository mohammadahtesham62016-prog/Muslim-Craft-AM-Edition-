/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { ChestModal } from './components/ChestModal';
import { CraftingTableModal } from './components/CraftingTableModal';
import { DeathScreen } from './components/DeathScreen';
import { FurnaceModal } from './components/FurnaceModal';
import { HomeScreen } from './components/HomeScreen';
import { InGameHUD } from './components/InGameHUD';
import { InventoryModal } from './components/InventoryModal';
import { LoadingScreen } from './components/LoadingScreen';
import { MobileControls } from './components/MobileControls';
import { PauseModal } from './components/PauseModal';
import { SettingsModal } from './components/SettingsModal';
import { WorldSelectModal } from './components/WorldSelectModal';
import { soundManager } from './game/audio';
import { VoxelEngine } from './game/engine';
import { PRESET_WORLD_0786, StorageService } from './game/storage';
import {
  Dimension,
  GameSettings,
  ItemStack,
  PlayerPosition,
  PlayerStats,
  SavedWorld,
} from './types/game';

type AppScreen = 'initial_loading' | 'home' | 'world_loading' | 'playing';

export default function App() {
  const [screen, setScreen] = useState<AppScreen>('initial_loading');
  const [worlds, setWorlds] = useState<SavedWorld[]>([]);
  const [currentWorld, setCurrentWorld] = useState<SavedWorld>(PRESET_WORLD_0786);
  const [settings, setSettings] = useState<GameSettings>(StorageService.loadSettings());

  // Active Modals during gameplay
  const [isWorldSelectOpen, setIsWorldSelectOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPauseOpen, setIsPauseOpen] = useState(false);
  const [isInventoryOpen, setIsInventoryOpen] = useState(false);
  const [isCraftingTableOpen, setIsCraftingTableOpen] = useState(false);
  const [isFurnaceOpen, setIsFurnaceOpen] = useState(false);
  const [openChestKey, setOpenChestKey] = useState<string | null>(null);
  const [isDead, setIsDead] = useState(false);

  // HUD live states synced from engine loop
  const [hudStats, setHudStats] = useState<PlayerStats>(PRESET_WORLD_0786.playerStats);
  const [hudPos, setHudPos] = useState<PlayerPosition>(PRESET_WORLD_0786.playerPos);
  const [hudDimension, setHudDimension] = useState<Dimension>('overworld');
  const [hudTimeOfDay, setHudTimeOfDay] = useState<number>(0.25);
  const [hudFps, setHudFps] = useState<number>(60);
  const [hudTargetBlock, setHudTargetBlock] = useState<string | null>(null);
  const [activeHotbarIndex, setActiveHotbarIndex] = useState<number>(0);
  const [hotbar, setHotbar] = useState<(ItemStack | null)[]>([...PRESET_WORLD_0786.hotbar]);
  const [inventory, setInventory] = useState<(ItemStack | null)[]>([...PRESET_WORLD_0786.inventory]);

  // Voxel Engine & Canvas Ref
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<VoxelEngine | null>(null);

  // Load saved worlds on startup
  useEffect(() => {
    const list = StorageService.loadWorlds();
    setWorlds(list);
    const loadedSettings = StorageService.loadSettings();
    setSettings(loadedSettings);
    soundManager.setVolumes(loadedSettings.sfxVolume, loadedSettings.musicVolume);
  }, []);

  // Initialize and run VoxelEngine when entering 'playing' screen
  useEffect(() => {
    if (screen !== 'playing') {
      if (engineRef.current) {
        engineRef.current.dispose();
        engineRef.current = null;
      }
      return;
    }

    const container = canvasMountRef.current;
    if (!container) return;

    // Reset dead state
    setIsDead(false);
    setHotbar([...currentWorld.hotbar]);
    setInventory([...currentWorld.inventory]);
    setActiveHotbarIndex(currentWorld.activeHotbarIndex);

    const engine = new VoxelEngine(container, currentWorld, settings, {
      onUpdateHUD: (data) => {
        setHudStats({ ...data.stats });
        setHudPos({ ...data.pos });
        setHudDimension(data.dimension);
        setHudTimeOfDay(data.timeOfDay);
        setHudFps(data.fps);
        setHudTargetBlock(data.targetBlockName);
      },
      onOpenInventory: () => setIsInventoryOpen(true),
      onOpenChest: (chestKey: string) => setOpenChestKey(chestKey),
      onOpenCraftingTable: () => setIsCraftingTableOpen(true),
      onOpenFurnace: () => setIsFurnaceOpen(true),
      onPlayerDeath: () => setIsDead(true),
    });

    engineRef.current = engine;
    engine.start();

    const handleResize = () => {
      if (!container) return;
      engine.resize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      engine.dispose();
      engineRef.current = null;
    };
  }, [screen, currentWorld]);

  // Save current world periodically or when exiting
  const handleSaveWorld = () => {
    if (engineRef.current) {
      const w = engineRef.current.world;
      w.hotbar = [...hotbar];
      w.inventory = [...inventory];
      w.activeHotbarIndex = activeHotbarIndex;
      w.lastPlayed = Date.now();
      StorageService.saveWorld(w);
      setWorlds(StorageService.loadWorlds());
    }
  };

  // Launch world
  const handleLaunchWorld = (world: SavedWorld) => {
    setCurrentWorld(world);
    setIsWorldSelectOpen(false);
    setScreen('world_loading');
  };

  // Quick launch 0786
  const handleQuickStart0786 = () => {
    let world0786 = worlds.find((w) => w.seed === '0786');
    if (!world0786) {
      world0786 = PRESET_WORLD_0786;
      StorageService.saveWorld(world0786);
      setWorlds(StorageService.loadWorlds());
    }
    handleLaunchWorld(world0786);
  };

  // Switch dimension warp
  const handleWarpDimension = (newDim: Dimension) => {
    if (engineRef.current) {
      engineRef.current.loadWorldDimension(newDim);
      setHudDimension(newDim);
      setIsPauseOpen(false);
    }
  };

  // Select Hotbar Slot
  const handleSelectHotbarSlot = (idx: number) => {
    setActiveHotbarIndex(idx);
    if (engineRef.current) {
      engineRef.current.world.activeHotbarIndex = idx;
    }
  };

  // Sync inventory changes
  const handleUpdateInventory = (newInv: (ItemStack | null)[], newHot: (ItemStack | null)[]) => {
    setInventory(newInv);
    setHotbar(newHot);
    if (engineRef.current) {
      engineRef.current.world.inventory = newInv;
      engineRef.current.world.hotbar = newHot;
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black select-none font-pixel">
      {/* 1. Initial Loading Screen */}
      {screen === 'initial_loading' && (
        <LoadingScreen onLoaded={() => setScreen('home')} />
      )}

      {/* 2. Main Home Screen */}
      {screen === 'home' && (
        <HomeScreen
          onPlay={() => setIsWorldSelectOpen(true)}
          onSettings={() => setIsSettingsOpen(true)}
          onQuickStart0786={handleQuickStart0786}
        />
      )}

      {/* 3. World Loading Screen */}
      {screen === 'world_loading' && (
        <LoadingScreen
          targetWorldName={currentWorld.name}
          onLoaded={() => setScreen('playing')}
        />
      )}

      {/* 4. Active Gameplay Viewport */}
      {screen === 'playing' && (
        <div className="relative w-full h-full">
          {/* Isolated 3D Canvas Mount */}
          <div ref={canvasMountRef} className="absolute inset-0 w-full h-full z-0" />

          {/* In-Game HUD Overlay */}
          <InGameHUD
            stats={hudStats}
            pos={hudPos}
            dimension={hudDimension}
            timeOfDay={hudTimeOfDay}
            fps={hudFps}
            targetBlockName={hudTargetBlock}
            hotbar={hotbar}
            activeHotbarIndex={activeHotbarIndex}
            onSelectHotbarIndex={handleSelectHotbarSlot}
            onOpenInventory={() => setIsInventoryOpen(true)}
            onPause={() => setIsPauseOpen(true)}
            onToggleCamera={() => {
              const next = !settings.thirdPerson;
              const newSettings = { ...settings, thirdPerson: next };
              setSettings(newSettings);
              engineRef.current?.setThirdPerson(next);
            }}
            onWarpDimension={() => setIsPauseOpen(true)}
            showCoordinates={settings.showCoordinates}
            thirdPerson={settings.thirdPerson}
            isUnderwater={engineRef.current?.isUnderwater ?? false}
          />

          {/* Mobile On-Screen Dual Controls */}
          <MobileControls
            engine={engineRef.current}
            onOpenInventory={() => setIsInventoryOpen(true)}
          />

          {/* Inventory Modal */}
          {isInventoryOpen && (
            <InventoryModal
              inventory={inventory}
              hotbar={hotbar}
              onClose={() => setIsInventoryOpen(false)}
              onUpdateInventory={handleUpdateInventory}
            />
          )}

          {/* Crafting Table 3x3 Modal */}
          {isCraftingTableOpen && (
            <CraftingTableModal
              inventory={inventory}
              hotbar={hotbar}
              onClose={() => setIsCraftingTableOpen(false)}
              onUpdateInventory={handleUpdateInventory}
            />
          )}

          {/* Furnace Modal */}
          {isFurnaceOpen && (
            <FurnaceModal
              inventory={inventory}
              hotbar={hotbar}
              onClose={() => setIsFurnaceOpen(false)}
              onUpdateInventory={handleUpdateInventory}
            />
          )}

          {/* Chest Modal */}
          {openChestKey && engineRef.current && (
            <ChestModal
              chestKey={openChestKey}
              chestItems={engineRef.current.world.chests[openChestKey] || new Array(27).fill(null)}
              inventory={inventory}
              hotbar={hotbar}
              onClose={() => setOpenChestKey(null)}
              onUpdateChest={(key, items) => {
                if (engineRef.current) {
                  engineRef.current.world.chests[key] = items;
                }
              }}
              onUpdateInventory={handleUpdateInventory}
            />
          )}

          {/* Pause Modal */}
          {isPauseOpen && (
            <PauseModal
              currentDimension={hudDimension}
              onResume={() => setIsPauseOpen(false)}
              onOpenSettings={() => setIsSettingsOpen(true)}
              onSelectDimension={handleWarpDimension}
              onSaveAndQuit={() => {
                handleSaveWorld();
                setIsPauseOpen(false);
                setScreen('home');
              }}
            />
          )}

          {/* Death Screen */}
          {isDead && (
            <DeathScreen
              score={hudStats.score}
              onRespawn={() => {
                engineRef.current?.respawn();
                setIsDead(false);
              }}
              onQuitToTitle={() => {
                handleSaveWorld();
                setScreen('home');
              }}
            />
          )}
        </div>
      )}

      {/* World Selection Modal */}
      {isWorldSelectOpen && (
        <WorldSelectModal
          worlds={worlds}
          onSelectWorld={handleLaunchWorld}
          onClose={() => setIsWorldSelectOpen(false)}
          onRefreshWorlds={() => setWorlds(StorageService.loadWorlds())}
        />
      )}

      {/* Settings Modal */}
      {isSettingsOpen && (
        <SettingsModal
          currentSettings={settings}
          onSave={(newSet: GameSettings) => {
            setSettings(newSet);
            if (engineRef.current) {
              engineRef.current.settings = newSet;
              engineRef.current.setThirdPerson(newSet.thirdPerson);
            }
          }}
          onClose={() => setIsSettingsOpen(false)}
        />
      )}
    </div>
  );
}
