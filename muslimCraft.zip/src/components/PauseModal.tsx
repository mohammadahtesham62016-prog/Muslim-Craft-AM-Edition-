import React from 'react';
import { Dimension } from '../types/game';

interface PauseModalProps {
  currentDimension: Dimension;
  onResume: () => void;
  onOpenSettings: () => void;
  onSelectDimension: (dim: Dimension) => void;
  onSaveAndQuit: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  currentDimension,
  onResume,
  onOpenSettings,
  onSelectDimension,
  onSaveAndQuit,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 font-pixel select-none">
      <div className="mc-panel w-full max-w-md p-6 text-stone-900 flex flex-col items-center gap-4">
        <h2 className="text-xl sm:text-2xl font-bold tracking-wider text-stone-800">GAME PAUSED</h2>

        {/* Dimension Warp Selector */}
        <div className="w-full bg-stone-300 p-3 border-2 border-stone-400">
          <span className="text-xs font-bold text-stone-700 block mb-2 text-center">
            DIMENSION PORTAL WARP
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onSelectDimension('overworld')}
              className={`mc-button py-2 px-1 text-[11px] cursor-pointer ${
                currentDimension === 'overworld' ? 'mc-button-green text-white font-bold' : 'text-stone-200'
              }`}
            >
              🌲 Overworld
            </button>
            <button
              onClick={() => onSelectDimension('nether')}
              className={`mc-button py-2 px-1 text-[11px] cursor-pointer ${
                currentDimension === 'nether' ? 'bg-red-800 border-red-500 text-white font-bold' : 'text-stone-200'
              }`}
            >
              🔥 Nether
            </button>
            <button
              onClick={() => onSelectDimension('the_end')}
              className={`mc-button py-2 px-1 text-[11px] cursor-pointer ${
                currentDimension === 'the_end' ? 'bg-purple-900 border-purple-500 text-white font-bold' : 'text-stone-200'
              }`}
            >
              🌌 The End
            </button>
            <button
              onClick={() => onSelectDimension('muslim_realm')}
              className={`mc-button py-2 px-1 text-[11px] cursor-pointer ${
                currentDimension === 'muslim_realm' ? 'bg-amber-700 border-amber-400 text-amber-200 font-bold' : 'text-stone-200'
              }`}
            >
              🕌 Muslim Realm
            </button>
          </div>
        </div>

        {/* Main Action Buttons */}
        <div className="w-full flex flex-col gap-2 mt-2">
          <button
            onClick={onResume}
            className="mc-button mc-button-green w-full py-3.5 text-sm sm:text-base text-white tracking-wider cursor-pointer"
          >
            BACK TO GAME
          </button>

          <button
            onClick={onOpenSettings}
            className="mc-button w-full py-3 text-xs sm:text-sm text-stone-200 cursor-pointer"
          >
            SETTINGS
          </button>

          <button
            onClick={onSaveAndQuit}
            className="mc-button w-full py-3 text-xs sm:text-sm text-amber-200 cursor-pointer"
          >
            SAVE & QUIT TO TITLE
          </button>
        </div>
      </div>
    </div>
  );
};
