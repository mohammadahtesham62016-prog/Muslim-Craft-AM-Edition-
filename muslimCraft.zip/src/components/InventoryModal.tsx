import React, { useState } from 'react';
import { CRAFTING_RECIPES, CraftingRecipe } from '../game/recipes';
import { BlockType, ItemStack } from '../types/game';
import { getItemEmoji } from './InGameHUD';
import { soundManager } from '../game/audio';

interface InventoryModalProps {
  inventory: (ItemStack | null)[];
  hotbar: (ItemStack | null)[];
  onClose: () => void;
  onUpdateInventory: (inv: (ItemStack | null)[], hot: (ItemStack | null)[]) => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  inventory,
  hotbar,
  onClose,
  onUpdateInventory,
}) => {
  const [inv, setInv] = useState<(ItemStack | null)[]>([...inventory]);
  const [hot, setHot] = useState<(ItemStack | null)[]>([...hotbar]);
  const [craftGrid, setCraftGrid] = useState<(ItemStack | null)[]>([null, null, null, null]);
  const [craftOutput, setCraftOutput] = useState<ItemStack | null>(null);

  const checkCrafting = (grid: (ItemStack | null)[]) => {
    const woodCount = grid.filter((s) => s?.isBlock && s.blockType === BlockType.OAK_WOOD).length;
    if (woodCount === 1 && grid.filter(Boolean).length === 1) {
      setCraftOutput({
        id: 'oak_wood',
        isBlock: true,
        blockType: BlockType.OAK_WOOD,
        count: 4,
        maxStack: 64,
      });
      return;
    }

    if (grid[0] && grid[2] && !grid[1] && !grid[3]) {
      setCraftOutput({ id: 'stick', isBlock: false, itemType: 'stick', count: 4, maxStack: 64 });
      return;
    }
    if (grid[1] && grid[3] && !grid[0] && !grid[2]) {
      setCraftOutput({ id: 'stick', isBlock: false, itemType: 'stick', count: 4, maxStack: 64 });
      return;
    }

    if (grid.every((s) => s?.isBlock && s.blockType === BlockType.OAK_WOOD)) {
      setCraftOutput({
        id: 'crafting_table',
        isBlock: true,
        blockType: BlockType.CRAFTING_TABLE,
        count: 1,
        maxStack: 64,
      });
      return;
    }

    if (
      (grid[0]?.itemType === 'coal' && grid[2]?.itemType === 'stick') ||
      (grid[1]?.itemType === 'coal' && grid[3]?.itemType === 'stick')
    ) {
      setCraftOutput({
        id: 'torch',
        isBlock: true,
        blockType: BlockType.TORCH,
        count: 4,
        maxStack: 64,
      });
      return;
    }

    setCraftOutput(null);
  };

  const handleTakeCraftOutput = () => {
    if (!craftOutput) return;
    soundManager.playPlace();

    const newHot = [...hot];
    const newInv = [...inv];
    let placed = false;

    for (let i = 0; i < newHot.length; i++) {
      if (newHot[i] === null) {
        newHot[i] = { ...craftOutput };
        placed = true;
        break;
      }
    }
    if (!placed) {
      for (let i = 0; i < newInv.length; i++) {
        if (newInv[i] === null) {
          newInv[i] = { ...craftOutput };
          placed = true;
          break;
        }
      }
    }

    if (placed) {
      const nextGrid = craftGrid.map((s) => {
        if (!s) return null;
        if (s.count <= 1) return null;
        return { ...s, count: s.count - 1 };
      });
      setCraftGrid(nextGrid);
      setHot(newHot);
      setInv(newInv);
      onUpdateInventory(newInv, newHot);
      checkCrafting(nextGrid);
    }
  };

  const handleQuickCraft = (recipe: CraftingRecipe) => {
    const allSlots = [...hot, ...inv].filter(Boolean) as ItemStack[];
    const requiredItems = recipe.pattern.filter(Boolean) as string[];

    let hasAll = true;
    for (const req of requiredItems) {
      const match = allSlots.find((s) => s.id === req || s.itemType === req);
      if (!match || match.count < 1) {
        hasAll = false;
        break;
      }
    }

    if (hasAll) {
      soundManager.playPlace();
      const newHot = [...hot];
      const newInv = [...inv];

      for (const req of requiredItems) {
        let deducted = false;
        for (let i = 0; i < newHot.length; i++) {
          if (newHot[i] && (newHot[i]?.id === req || newHot[i]?.itemType === req)) {
            newHot[i]!.count -= 1;
            if (newHot[i]!.count <= 0) newHot[i] = null;
            deducted = true;
            break;
          }
        }
        if (!deducted) {
          for (let i = 0; i < newInv.length; i++) {
            if (newInv[i] && (newInv[i]?.id === req || newInv[i]?.itemType === req)) {
              newInv[i]!.count -= 1;
              if (newInv[i]!.count <= 0) newInv[i] = null;
              break;
            }
          }
        }
      }

      let placed = false;
      for (let i = 0; i < newHot.length; i++) {
        if (newHot[i] === null) {
          newHot[i] = { ...recipe.result };
          placed = true;
          break;
        }
      }
      if (!placed) {
        for (let i = 0; i < newInv.length; i++) {
          if (newInv[i] === null) {
            newInv[i] = { ...recipe.result };
            placed = true;
            break;
          }
        }
      }

      setHot(newHot);
      setInv(newInv);
      onUpdateInventory(newInv, newHot);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 font-pixel select-none">
      <div className="mc-panel w-full max-w-2xl max-h-[92vh] flex flex-col p-4 text-stone-900 overflow-hidden">
        <div className="flex items-center justify-between pb-2 border-b-2 border-stone-400 mb-3">
          <h2 className="text-sm sm:text-base font-bold text-stone-800">CRAFTING & INVENTORY</h2>
          <button onClick={onClose} className="mc-button px-3 py-1 text-xs text-stone-200 cursor-pointer">
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-3 bg-stone-300 border-2 border-stone-400">
            <div>
              <span className="text-xs font-bold text-stone-700 block mb-1">Crafting (2x2)</span>
              <div className="grid grid-cols-2 gap-1">
                {craftGrid.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      const firstAvailable = hot.find(Boolean) || inv.find(Boolean);
                      if (firstAvailable && !item) {
                        const nextGrid = [...craftGrid];
                        nextGrid[idx] = { ...firstAvailable, count: 1 };
                        setCraftGrid(nextGrid);
                        checkCrafting(nextGrid);
                      } else if (item) {
                        const nextGrid = [...craftGrid];
                        nextGrid[idx] = null;
                        setCraftGrid(nextGrid);
                        checkCrafting(nextGrid);
                      }
                    }}
                    className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer text-lg"
                  >
                    {item && getItemEmoji(item)}
                  </div>
                ))}
              </div>
            </div>

            <div className="text-xl text-stone-600 font-bold">➔</div>

            <div>
              <span className="text-xs font-bold text-stone-700 block mb-1">Result</span>
              <div
                onClick={handleTakeCraftOutput}
                className={`w-12 h-12 mc-slot flex items-center justify-center cursor-pointer text-xl ${
                  craftOutput ? 'ring-2 ring-amber-400 bg-amber-100' : ''
                }`}
              >
                {craftOutput && (
                  <div className="relative flex items-center justify-center">
                    <span>{getItemEmoji(craftOutput)}</span>
                    {craftOutput.count > 1 && (
                      <span className="absolute -bottom-1 -right-1 text-[10px] font-bold text-white bg-black/70 px-1">
                        {craftOutput.count}
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="flex-1 max-w-xs">
              <span className="text-[11px] font-bold text-stone-700 block mb-1">Quick Craft:</span>
              <div className="flex flex-wrap gap-1">
                {CRAFTING_RECIPES.slice(0, 6).map((rec) => (
                  <button
                    key={rec.id}
                    onClick={() => handleQuickCraft(rec)}
                    className="mc-button px-2 py-1 text-[10px] text-stone-200 cursor-pointer flex items-center gap-1 active:scale-95"
                    title={`Craft ${rec.name}`}
                  >
                    <span>{getItemEmoji(rec.result)}</span>
                    <span className="hidden sm:inline">{rec.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <span className="text-xs font-bold text-stone-700 block mb-1.5">Inventory (27 Slots)</span>
            <div className="grid grid-cols-9 gap-1 p-2 bg-stone-300 border-2 border-stone-400">
              {inv.map((item, idx) => (
                <div
                  key={idx}
                  className="w-8 h-8 sm:w-10 sm:h-10 mc-slot flex items-center justify-center relative cursor-pointer"
                >
                  {item && (
                    <>
                      <span className="text-sm sm:text-base select-none">{getItemEmoji(item)}</span>
                      {item.count > 1 && (
                        <span className="absolute bottom-0 right-0.5 text-[9px] font-bold text-white drop-shadow-[0_1px_1px_#000]">
                          {item.count}
                        </span>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div>
            <span className="text-xs font-bold text-stone-700 block mb-1.5">Hotbar</span>
            <div className="grid grid-cols-9 gap-1 p-2 bg-stone-300 border-2 border-stone-400">
              {hot.map((item, idx) => (
                <div
                  key={idx}
                  className="w-8 h-8 sm:w-10 sm:h-10 mc-slot flex items-center justify-center relative cursor-pointer"
                >
                  {item && (
                    <>
                      <span className="text-sm sm:text-base select-none">{getItemEmoji(item)}</span>
                      {item.count > 1 && (
                        <span className="absolute bottom-0 right-0.5 text-[9px] font-bold text-white drop-shadow-[0_1px_1px_#000]">
                          {item.count}
                        </span>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
