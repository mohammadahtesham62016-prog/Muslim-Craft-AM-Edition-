import React, { useEffect, useState } from 'react';
import { Dimension, ItemStack, PlayerPosition, PlayerStats } from '../types/game';
import { getBlockName } from '../game/textures';

interface InGameHUDProps {
  stats: PlayerStats;
  pos: PlayerPosition;
  dimension: Dimension;
  timeOfDay: number;
  fps: number;
  targetBlockName: string | null;
  hotbar: (ItemStack | null)[];
  activeHotbarIndex: number;
  onSelectHotbarIndex: (idx: number) => void;
  onOpenInventory: () => void;
  onPause: () => void;
  onToggleCamera: () => void;
  onWarpDimension: () => void;
  showCoordinates: boolean;
  thirdPerson: boolean;
  isUnderwater: boolean;
}

export function getItemEmoji(item: ItemStack): string {
  if (item.isBlock) {
    switch (item.blockType) {
      case 1: return '🟩';
      case 2: return '🟫';
      case 3: return '🪨';
      case 4: return '🧱';
      case 5: return '🪵';
      case 6: return '🍃';
      case 7: return '🏖️';
      case 9: return '🪟';
      case 13: return '💎';
      case 14: return '🔨';
      case 15: return '🔥';
      case 16: return '📦';
      case 17: return '🕯️';
      case 30: return '🏛️';
      case 33: return '💠';
      case 34: return '✨';
      case 36: return '🏛️';
      default: return '🧱';
    }
  }

  if (item.itemType?.includes('pickaxe')) return '⛏️';
  if (item.itemType?.includes('sword')) return '⚔️';
  if (item.itemType?.includes('axe')) return '🪓';
  if (item.itemType?.includes('shovel')) return '🥄';
  if (item.itemType === 'bow') return '🏹';
  if (item.itemType === 'arrow') return '🔺';
  if (item.itemType === 'diamond') return '💎';
  if (item.itemType === 'iron_ingot') return '🔩';
  if (item.itemType === 'gold_ingot') return '🪙';
  if (item.itemType === 'coal') return '⚫';
  if (item.itemType === 'bread') return '🍞';
  if (item.itemType === 'apple') return '🍎';
  if (item.itemType === 'raw_beef' || item.itemType === 'cooked_beef') return '🥩';
  if (item.itemType === 'stick') return '🥢';
  return '📦';
}

export const InGameHUD: React.FC<InGameHUDProps> = ({
  stats,
  pos,
  dimension,
  timeOfDay,
  fps,
  targetBlockName,
  hotbar,
  activeHotbarIndex,
  onSelectHotbarIndex,
  onOpenInventory,
  onPause,
  onToggleCamera,
  onWarpDimension,
  showCoordinates,
  thirdPerson,
  isUnderwater,
}) => {
  const [activeItemPopup, setActiveItemPopup] = useState<string>('');

  const activeItem = hotbar[activeHotbarIndex];

  useEffect(() => {
    if (activeItem) {
      const name = activeItem.isBlock && activeItem.blockType !== undefined
        ? getBlockName(activeItem.blockType)
        : activeItem.itemType?.replace(/_/g, ' ') || 'Item';
      setActiveItemPopup(name);
      const timer = setTimeout(() => setActiveItemPopup(''), 1600);
      return () => clearTimeout(timer);
    } else {
      setActiveItemPopup('');
    }
  }, [activeHotbarIndex, activeItem]);

  const getDimensionLabel = () => {
    switch (dimension) {
      case 'overworld':
        return '🌲 Overworld';
      case 'nether':
        return '🔥 Nether';
      case 'the_end':
        return '🌌 The End';
      case 'muslim_realm':
        return '🕌 Muslim Realm';
    }
  };

  const hours = Math.floor((timeOfDay * 24 + 6) % 24);
  const minutes = Math.floor(((timeOfDay * 24 * 60) % 60));
  const timeStr = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;

  return (
    <div className="fixed inset-0 pointer-events-none select-none z-20 flex flex-col justify-between p-2 sm:p-4 font-pixel text-white">
      <div className="flex items-start justify-between w-full">
        <div className="flex flex-col gap-1">
          <div className="px-2.5 py-1 bg-black/60 border border-stone-600 text-[11px] sm:text-xs flex items-center gap-2">
            <span className="text-amber-400 font-bold">{getDimensionLabel()}</span>
            <span className="text-stone-400">|</span>
            <span className="text-stone-300">⏳ {timeStr}</span>
          </div>

          {showCoordinates && (
            <div className="px-2.5 py-1 bg-black/50 border border-stone-700 text-[10px] text-stone-300 tabular-nums">
              XYZ: {pos.x.toFixed(1)} / {pos.y.toFixed(1)} / {pos.z.toFixed(1)} • {fps} FPS
            </div>
          )}

          {targetBlockName && (
            <div className="px-2 py-0.5 bg-black/40 text-[10px] text-stone-400 self-start">
              Target: <span className="text-stone-200">{targetBlockName}</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={onWarpDimension}
            className="mc-button px-2.5 py-1.5 text-[10px] sm:text-xs text-amber-300 flex items-center gap-1 cursor-pointer active:scale-95"
            title="Switch Dimension"
          >
            <span>🌀</span>
            <span className="hidden sm:inline">WARP</span>
          </button>

          <button
            onClick={onToggleCamera}
            className="mc-button px-2.5 py-1.5 text-[10px] sm:text-xs text-stone-200 cursor-pointer active:scale-95"
            title="Toggle Perspective (F5)"
          >
            {thirdPerson ? '3RD' : '1ST'}
          </button>

          <button
            onClick={onOpenInventory}
            className="mc-button px-2.5 py-1.5 text-[10px] sm:text-xs text-stone-200 cursor-pointer active:scale-95"
            title="Inventory (E)"
          >
            🎒 <span className="hidden sm:inline">INV</span>
          </button>

          <button
            onClick={onPause}
            className="mc-button px-2.5 py-1.5 text-[10px] sm:text-xs text-stone-200 cursor-pointer active:scale-95"
            title="Pause Menu"
          >
            ⏸️
          </button>
        </div>
      </div>

      {!thirdPerson && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="relative w-4 h-4">
            <div className="absolute left-1.5 top-0 w-1 h-4 bg-white/75 mix-blend-difference" />
            <div className="absolute top-1.5 left-0 w-4 h-1 bg-white/75 mix-blend-difference" />
          </div>
        </div>
      )}

      {activeItemPopup && (
        <div className="self-center mb-2 px-3 py-1 bg-black/60 border border-stone-500 text-xs text-amber-300 uppercase tracking-wider animate-fade-in shadow-md">
          {activeItemPopup}
        </div>
      )}

      <div className="w-full flex flex-col items-center gap-1 mb-1">
        <div className="w-full max-w-sm sm:max-w-md flex justify-between items-center px-2 text-sm sm:text-base">
          <div className="flex gap-0.5 items-center drop-shadow-[0_2px_2px_#000]">
            {Array.from({ length: 10 }).map((_, i) => {
              const heartValue = (i + 1) * 2;
              const isFull = stats.health >= heartValue;
              const isHalf = stats.health === heartValue - 1;
              return (
                <span
                  key={i}
                  className={`text-xs sm:text-sm ${
                    isFull ? 'text-red-500' : isHalf ? 'text-red-400' : 'text-stone-700'
                  }`}
                >
                  {isFull ? '❤️' : isHalf ? '💔' : '🖤'}
                </span>
              );
            })}
          </div>

          {isUnderwater && (
            <div className="flex gap-0.5 text-xs text-cyan-400 animate-pulse">
              🫧🫧🫧🫧🫧
            </div>
          )}

          <div className="flex gap-0.5 items-center drop-shadow-[0_2px_2px_#000]">
            {Array.from({ length: 10 }).map((_, i) => {
              const hungerValue = (i + 1) * 2;
              const isFull = stats.hunger >= hungerValue;
              return (
                <span
                  key={i}
                  className={`text-xs sm:text-sm ${isFull ? 'text-amber-500' : 'text-stone-700'}`}
                >
                  🍗
                </span>
              );
            })}
          </div>
        </div>

        <div className="pointer-events-auto flex items-center bg-stone-900/90 border-2 border-stone-600 p-1 rounded-sm shadow-2xl gap-1">
          {hotbar.map((item, idx) => {
            const isSelected = idx === activeHotbarIndex;
            return (
              <div
                key={idx}
                onClick={() => onSelectHotbarIndex(idx)}
                className={`relative w-8 h-8 sm:w-11 sm:h-11 mc-slot flex items-center justify-center cursor-pointer transition-all ${
                  isSelected ? 'mc-slot-selected ring-2 ring-white scale-105' : ''
                }`}
              >
                <span className="absolute top-0.5 left-1 text-[8px] text-stone-400 font-silkscreen">
                  {idx + 1}
                </span>

                {item && (
                  <div className="flex flex-col items-center justify-center">
                    <span className="text-sm sm:text-lg select-none">
                      {getItemEmoji(item)}
                    </span>
                    {item.count > 1 && (
                      <span className="absolute bottom-0.5 right-1 text-[9px] sm:text-[11px] font-bold text-white drop-shadow-[0_1px_1px_#000]">
                        {item.count}
                      </span>
                    )}
                    {item.durability !== undefined && item.maxDurability !== undefined && (
                      <div className="absolute bottom-0.5 left-1 right-1 h-0.5 sm:h-1 bg-stone-900">
                        <div
                          className="h-full bg-emerald-500"
                          style={{
                            width: `${(item.durability / item.maxDurability) * 100}%`,
                          }}
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
