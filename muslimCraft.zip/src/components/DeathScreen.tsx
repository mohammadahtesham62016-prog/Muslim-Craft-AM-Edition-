import React from 'react';

interface DeathScreenProps {
  score: number;
  onRespawn: () => void;
  onQuitToTitle: () => void;
}

export const DeathScreen: React.FC<DeathScreenProps> = ({
  score,
  onRespawn,
  onQuitToTitle,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-red-950/85 font-pixel select-none animate-fade-in">
      <div className="flex flex-col items-center gap-6 max-w-sm w-full text-center">
        <h1 className="text-4xl sm:text-5xl font-bold text-red-500 tracking-wider drop-shadow-[0_4px_0_#450a0a]">
          YOU DIED!
        </h1>

        <div className="text-sm text-stone-200">
          Score: <span className="text-amber-400 font-bold">{score}</span>
        </div>

        <div className="w-full flex flex-col gap-3 mt-4">
          <button
            onClick={onRespawn}
            className="mc-button mc-button-green w-full py-4 text-sm sm:text-base text-white tracking-widest cursor-pointer shadow-xl active:scale-95"
          >
            RESPAWN
          </button>

          <button
            onClick={onQuitToTitle}
            className="mc-button w-full py-3.5 text-xs sm:text-sm text-stone-200 tracking-wider cursor-pointer active:scale-95"
          >
            TITLE SCREEN
          </button>
        </div>
      </div>
    </div>
  );
};
