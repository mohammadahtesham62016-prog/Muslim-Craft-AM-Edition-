import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { getBlockMaterial } from '../game/textures';
import { BlockType } from '../types/game';

interface HomeScreenProps {
  onPlay: () => void;
  onSettings: () => void;
  onQuickStart0786: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onPlay,
  onSettings,
  onQuickStart0786,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x7bc0ee);
    scene.fog = new THREE.FogExp2(0x7bc0ee, 0.025);

    const camera = new THREE.PerspectiveCamera(
      65,
      container.clientWidth / container.clientHeight,
      0.1,
      120
    );
    camera.position.set(0, 14, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'low-power' });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(renderer.domElement);

    const hemi = new THREE.HemisphereLight(0xffffff, 0x555555, 0.9);
    scene.add(hemi);
    const dirLight = new THREE.DirectionalLight(0xfff5dd, 1.2);
    dirLight.position.set(20, 30, 20);
    scene.add(dirLight);

    const boxGeo = new THREE.BoxGeometry(1, 1, 1);
    const radius = 22;

    for (let x = -radius; x <= radius; x++) {
      for (let z = -radius; z <= radius; z++) {
        const dist = Math.hypot(x, z);
        if (dist > radius) continue;
        const h = Math.floor(10 + Math.sin(x * 0.2) * 2 + Math.cos(z * 0.2) * 2);

        const grassMesh = new THREE.Mesh(boxGeo, getBlockMaterial(BlockType.GRASS));
        grassMesh.position.set(x + 0.5, h + 0.5, z + 0.5);
        scene.add(grassMesh);

        for (let y = h - 1; y >= h - 2; y--) {
          const dirtMesh = new THREE.Mesh(boxGeo, getBlockMaterial(BlockType.DIRT));
          dirtMesh.position.set(x + 0.5, y + 0.5, z + 0.5);
          scene.add(dirtMesh);
        }

        if ((x + 12) % 6 === 0 && (z + 12) % 6 === 0 && dist > 5) {
          for (let th = 1; th <= 4; th++) {
            const trunk = new THREE.Mesh(boxGeo, getBlockMaterial(BlockType.OAK_WOOD));
            trunk.position.set(x + 0.5, h + th + 0.5, z + 0.5);
            scene.add(trunk);
          }
          for (let lx = -1; lx <= 1; lx++) {
            for (let lz = -1; lz <= 1; lz++) {
              const leaves = new THREE.Mesh(boxGeo, getBlockMaterial(BlockType.OAK_LEAVES));
              leaves.position.set(x + lx + 0.5, h + 5 + 0.5, z + lz + 0.5);
              scene.add(leaves);
            }
          }
        }
      }
    }

    const cloudGeo = new THREE.PlaneGeometry(100, 100);
    const cloudMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.55,
      side: THREE.DoubleSide,
    });
    const clouds = new THREE.Mesh(cloudGeo, cloudMat);
    clouds.position.y = 25;
    clouds.rotation.x = -Math.PI / 2;
    scene.add(clouds);

    let angle = 0;
    let animId = 0;

    const animate = () => {
      angle += 0.0025;
      camera.rotation.y = angle;
      clouds.position.x = Math.sin(angle * 0.5) * 5;
      renderer.render(scene, camera);
      animId = requestAnimationFrame(animate);
    };

    animId = requestAnimationFrame(animate);

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (renderer.domElement.parentElement) {
        renderer.domElement.parentElement.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div className="relative w-full h-full select-none overflow-hidden flex flex-col items-center justify-between p-4 sm:p-8 font-pixel">
      <div ref={mountRef} className="absolute inset-0 pointer-events-none z-0" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30 pointer-events-none z-0" />

      <div className="z-10 mt-6 sm:mt-12 flex flex-col items-center">
        <div className="relative">
          <h1 className="text-3xl sm:text-6xl text-center text-amber-400 tracking-wider drop-shadow-[0_6px_0_#78350f] transform -rotate-1 hover:rotate-0 transition-transform">
            MUSLIM CRAFT
          </h1>
          <div className="absolute -bottom-3 -right-4 sm:-right-8 text-[11px] sm:text-sm text-yellow-300 font-silkscreen font-bold tracking-wide transform rotate-[-8deg] animate-pulse drop-shadow-[0_2px_0_#000]">
            AM EDITION!
          </div>
        </div>

        <div className="mt-5 px-4 py-1.5 bg-emerald-900/90 border-2 border-emerald-400 text-emerald-200 text-xs sm:text-sm font-silkscreen shadow-lg">
          3D VOXEL SANDBOX • 4 DIMENSIONS • SEED 0786
        </div>
      </div>

      <div className="z-10 flex flex-col items-center gap-3 w-full max-w-sm sm:max-w-md my-auto">
        <button
          onClick={onPlay}
          className="mc-button w-full py-4 text-base sm:text-xl text-white tracking-widest cursor-pointer shadow-lg active:scale-95 transition-transform"
        >
          PLAY
        </button>

        <button
          onClick={onQuickStart0786}
          className="mc-button mc-button-green w-full py-3 text-xs sm:text-sm text-emerald-100 tracking-wider cursor-pointer border-emerald-400 active:scale-95 transition-transform flex items-center justify-center gap-2"
        >
          <span>★</span> QUICK START: SEED 0786 (5 BLACKSMITHS)
        </button>

        <button
          onClick={onSettings}
          className="mc-button w-full py-3.5 text-sm sm:text-base text-stone-200 tracking-wider cursor-pointer active:scale-95 transition-transform"
        >
          SETTINGS
        </button>
      </div>

      <div className="z-10 w-full flex flex-col sm:flex-row items-center justify-between text-[11px] sm:text-xs text-stone-300 drop-shadow-[0_1px_2px_#000] gap-2 pb-2">
        <span>Muslim Craft AM Edition v1.2.0</span>
        <span className="text-stone-400">Mobile & Low-End Device Ready</span>
      </div>
    </div>
  );
};
