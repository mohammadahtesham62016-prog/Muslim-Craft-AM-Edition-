import React, { useState } from 'react';
import { GameMode, SavedWorld } from '../types/game';
import { PRESET_WORLD_0786, StorageService } from '../game/storage';

interface WorldSelectModalProps {
  worlds: SavedWorld[];
  onSelectWorld: (world: SavedWorld) => void;
  onClose: () => void;
  onRefreshWorlds: () => void;
}

export const WorldSelectModal: React.FC<WorldSelectModalProps> = ({
  worlds,
  onSelectWorld,
  onClose,
  onRefreshWorlds,
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [worldName, setWorldName] = useState('New World');
  const [seed, setSeed] = useState('0786');
  const [gameMode, setGameMode] = useState<GameMode>('survival');

  const handleCreate = () => {
    const trimmedSeed = seed.trim() || '0786';
    const newWorld: SavedWorld = {
      id: `world_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: worldName.trim() || 'My World',
      seed: trimmedSeed,
      gameMode,
      dimension: 'overworld',
      createdAt: Date.now(),
      lastPlayed: Date.now(),
      playerPos: { x: 0, y: 15, z: 4, pitch: 0, yaw: 0 },
      playerStats: {
        health: 20,
        maxHealth: 20,
        hunger: 20,
        maxHunger: 20,
        saturation: 10,
        armor: 0,
        score: 0,
        isDead: false,
      },
      inventory: new Array(27).fill(null),
      hotbar: [...PRESET_WORLD_0786.hotbar],
      activeHotbarIndex: 0,
      chests: {},
      modifiedBlocks: {},
      timeOfDay: 0.25,
    };

    StorageService.saveWorld(newWorld);
    onRefreshWorlds();
    onSelectWorld(newWorld);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this world?')) {
      StorageService.deleteWorld(id);
      onRefreshWorlds();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 font-pixel">
      <div className="mc-panel w-full max-w-2xl max-h-[92vh] flex flex-col p-4 sm:p-6 text-stone-900 select-none overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b-2 border-stone-400 mb-4">
          <h2 className="text-base sm:text-xl font-bold tracking-wide text-stone-800">
            {isCreating ? 'CREATE NEW WORLD' : 'SELECT WORLD'}
          </h2>
          <button
            onClick={onClose}
            className="mc-button px-3 py-1 text-xs text-stone-200 cursor-pointer"
          >
            ✕
          </button>
        </div>

        {isCreating ? (
          <div className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs sm:text-sm">
            <div>
              <label className="block font-bold mb-1.5 text-stone-700">World Name</label>
              <input
                type="text"
                value={worldName}
                onChange={(e) => setWorldName(e.target.value)}
                placeholder="Enter world name..."
                className="w-full px-3 py-2 bg-stone-800 border-2 border-stone-600 text-white font-silkscreen focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block font-bold mb-1.5 text-stone-700">Game Mode</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setGameMode('survival')}
                  className={`p-3 text-left border-2 cursor-pointer transition-all ${
                    gameMode === 'survival'
                      ? 'bg-amber-100 border-amber-600 shadow-inner'
                      : 'bg-stone-200 border-stone-400 hover:bg-stone-300'
                  }`}
                >
                  <div className="font-bold text-red-700">SURVIVAL</div>
                  <div className="text-[10px] text-stone-600 mt-1">
                    Health, hunger, mining, hostile mobs & crafting.
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setGameMode('adventure')}
                  className={`p-3 text-left border-2 cursor-pointer transition-all ${
                    gameMode === 'adventure'
                      ? 'bg-amber-100 border-amber-600 shadow-inner'
                      : 'bg-stone-200 border-stone-400 hover:bg-stone-300'
                  }`}
                >
                  <div className="font-bold text-blue-700">ADVENTURE</div>
                  <div className="text-[10px] text-stone-600 mt-1">
                    Exploration, restricted block breaking without tools.
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setGameMode('spectator')}
                  className={`p-3 text-left border-2 cursor-pointer transition-all ${
                    gameMode === 'spectator'
                      ? 'bg-amber-100 border-amber-600 shadow-inner'
                      : 'bg-stone-200 border-stone-400 hover:bg-stone-300'
                  }`}
                >
                  <div className="font-bold text-emerald-700">SPECTATOR</div>
                  <div className="text-[10px] text-stone-600 mt-1">
                    Free flying, noclip through terrain, explore dimensions.
                  </div>
                </button>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-bold text-stone-700">World Seed</label>
                <button
                  type="button"
                  onClick={() => setSeed('0786')}
                  className="text-[11px] text-emerald-800 font-bold hover:underline cursor-pointer"
                >
                  ★ Use Legendary 0786
                </button>
              </div>
              <input
                type="text"
                value={seed}
                onChange={(e) => setSeed(e.target.value)}
                placeholder="Enter seed or leave 0786"
                className="w-full px-3 py-2 bg-stone-800 border-2 border-stone-600 text-amber-300 font-silkscreen focus:outline-none focus:border-amber-400"
              />
              {seed === '0786' && (
                <div className="mt-2 p-2 bg-emerald-100 border border-emerald-500 text-emerald-900 text-[11px] leading-relaxed">
                  ✓ <strong>Seed 0786 Activated:</strong> Spawns adjacent to a massive village with
                  <strong> 5 Blacksmiths</strong>, each with a chest containing{' '}
                  <strong>10 Diamonds</strong> (50 Diamonds total!), plus iron golems, farms, and
                  villagers!
                </div>
              )}
            </div>

            <div className="flex gap-3 pt-3">
              <button
                type="button"
                onClick={handleCreate}
                className="mc-button mc-button-green flex-1 py-3 text-white cursor-pointer font-bold"
              >
                CREATE WORLD
              </button>
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="mc-button px-6 py-3 text-stone-200 cursor-pointer"
              >
                CANCEL
              </button>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col min-h-0">
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 mb-4">
              {worlds.map((w) => (
                <div
                  key={w.id}
                  onClick={() => onSelectWorld(w)}
                  className="p-3 bg-stone-200 border-2 border-stone-400 hover:border-amber-500 hover:bg-stone-100 cursor-pointer transition-all flex items-center justify-between gap-3 group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-stone-800 border-2 border-stone-600 flex items-center justify-center text-amber-400 text-lg">
                      {w.seed === '0786' ? '💎' : '⛏️'}
                    </div>

                    <div>
                      <div className="font-bold text-stone-900 text-xs sm:text-sm group-hover:text-amber-700">
                        {w.name}
                      </div>
                      <div className="text-[10px] text-stone-600 font-silkscreen flex gap-2 mt-0.5">
                        <span className="uppercase text-emerald-800 font-bold">{w.gameMode}</span>
                        <span>•</span>
                        <span>Seed: {w.seed}</span>
                        {w.seed === '0786' && (
                          <span className="text-amber-700 font-bold">★ 5 Blacksmiths</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => handleDelete(w.id, e)}
                      className="mc-button px-2.5 py-1.5 text-[10px] text-red-200 hover:text-white cursor-pointer"
                      title="Delete World"
                    >
                      DELETE
                    </button>
                    <button className="mc-button mc-button-green px-3 py-1.5 text-xs text-white cursor-pointer">
                      PLAY
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-2 pt-2 border-t-2 border-stone-400">
              <button
                onClick={() => setIsCreating(true)}
                className="mc-button mc-button-green flex-1 py-3 text-xs sm:text-sm text-white cursor-pointer font-bold"
              >
                CREATE NEW WORLD
              </button>
              <button
                onClick={onClose}
                className="mc-button px-6 py-3 text-xs sm:text-sm text-stone-200 cursor-pointer"
              >
                BACK
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
