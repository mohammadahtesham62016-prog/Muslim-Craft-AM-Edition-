import React, { useEffect, useState } from 'react';

interface LoadingScreenProps {
  onLoaded: () => void;
  targetWorldName?: string;
}

const LOADING_TIPS = [
  'Generating procedural voxel terrain...',
  'Spawning village houses and cobblestone roads...',
  'Placing 5 blacksmiths and filling chests with diamonds...',
  'Summoning Iron Golems to protect the villagers...',
  'Synthesizing procedural block textures...',
  'Constructing the majestic Muslim Realm with turquoise domes...',
  'Carving caves and embedding diamond ores...',
  'Polishing iron pickaxes and lighting torches...',
];

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onLoaded, targetWorldName }) => {
  const [progress, setProgress] = useState(0);
  const [tipIndex, setTipIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onLoaded, 400);
          return 100;
        }
        const inc = Math.random() * 12 + 6;
        return Math.min(100, Math.floor(prev + inc));
      });
    }, 140);

    const tipTimer = setInterval(() => {
      setTipIndex((prev) => (prev + 1) % LOADING_TIPS.length);
    }, 1800);

    return () => {
      clearInterval(timer);
      clearInterval(tipTimer);
    };
  }, [onLoaded]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between p-6 select-none bg-stone-900 bg-[radial-gradient(circle_at_center,#262626_0%,#111111_100%)] text-white font-pixel">
      <div
        className="absolute inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage:
            'radial-gradient(#ffffff 1px, transparent 1px), radial-gradient(#ffffff 1px, #111111 1px)',
          backgroundSize: '24px 24px',
          backgroundPosition: '0 0, 12px 12px',
        }}
      />

      <div className="mt-8 text-center z-10">
        <h1 className="text-3xl sm:text-5xl tracking-wider text-amber-400 drop-shadow-[0_4px_0_#78350f]">
          MUSLIM CRAFT
        </h1>
        <div className="mt-2 inline-block px-3 py-1 bg-emerald-800 border-2 border-emerald-400 text-emerald-200 text-xs sm:text-sm font-silkscreen uppercase tracking-widest shadow-md">
          AM EDITION
        </div>
      </div>

      <div className="flex flex-col items-center gap-4 z-10">
        <div className="relative w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center">
          <div
            className="w-16 h-16 sm:w-20 sm:h-20 bg-emerald-600 border-4 border-emerald-300 shadow-[0_0_25px_rgba(52,211,153,0.6)] animate-bounce"
            style={{
              clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
            }}
          />
        </div>

        {targetWorldName && (
          <p className="text-xs sm:text-sm text-stone-300 tracking-wide">
            Loading: <span className="text-amber-300">{targetWorldName}</span>
          </p>
        )}

        <p className="text-[11px] sm:text-xs text-stone-400 max-w-md text-center leading-relaxed h-8">
          {LOADING_TIPS[tipIndex]}
        </p>
      </div>

      <div className="w-full max-w-md flex flex-col items-center gap-2 mb-8 z-10">
        <div className="w-full flex justify-between text-xs text-stone-400">
          <span>BUILDING TERRAIN</span>
          <span className="text-amber-400">{progress}%</span>
        </div>

        <div className="w-full h-6 bg-stone-950 border-2 border-stone-600 p-0.5 shadow-inner">
          <div
            className="h-full bg-gradient-to-r from-emerald-600 via-green-500 to-lime-400 transition-all duration-150 border-r-2 border-white"
            style={{ width: `${progress}%` }}
          />
        </div>

        <span className="text-[10px] text-stone-500 mt-1">
          AM Edition Engine v1.2.0 • Low-End Mobile Optimized
        </span>
      </div>
    </div>
  );
};
