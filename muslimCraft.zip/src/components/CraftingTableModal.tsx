import React, { useState } from 'react';
import { CRAFTING_RECIPES, CraftingRecipe } from '../game/recipes';
import { ItemStack } from '../types/game';
import { getItemEmoji } from './InGameHUD';
import { soundManager } from '../game/audio';

interface CraftingTableModalProps {
  inventory: (ItemStack | null)[];
  hotbar: (ItemStack | null)[];
  onClose: () => void;
  onUpdateInventory: (inv: (ItemStack | null)[], hot: (ItemStack | null)[]) => void;
}

export const CraftingTableModal: React.FC<CraftingTableModalProps> = ({
  inventory,
  hotbar,
  onClose,
  onUpdateInventory,
}) => {
  const [inv, setInv] = useState<(ItemStack | null)[]>([...inventory]);
  const [hot, setHot] = useState<(ItemStack | null)[]>([...hotbar]);
  const [category, setCategory] = useState<'all' | 'tools' | 'combat' | 'blocks' | 'realm'>('all');
  const [selectedRecipe, setSelectedRecipe] = useState<CraftingRecipe | null>(CRAFTING_RECIPES[0]);

  const filteredRecipes = CRAFTING_RECIPES.filter((r) =>
    category === 'all' ? true : r.category === category
  );

  const handleCraft = (recipe: CraftingRecipe) => {
    soundManager.playPlace();
    const newHot = [...hot];
    const newInv = [...inv];

    let placed = false;
    for (let i = 0; i < newHot.length; i++) {
      if (newHot[i] === null) {
        newHot[i] = { ...recipe.result };
        placed = true;
        break;
      }
    }
    if (!placed) {
      for (let i = 0; i < newInv.length; i++) {
        if (newInv[i] === null) {
          newInv[i] = { ...recipe.result };
          placed = true;
          break;
        }
      }
    }

    setHot(newHot);
    setInv(newInv);
    onUpdateInventory(newInv, newHot);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 font-pixel select-none">
      <div className="mc-panel w-full max-w-2xl max-h-[92vh] flex flex-col p-4 text-stone-900 overflow-hidden">
        <div className="flex items-center justify-between pb-2 border-b-2 border-stone-400 mb-3">
          <h2 className="text-sm sm:text-base font-bold text-stone-800">CRAFTING TABLE (3x3)</h2>
          <button onClick={onClose} className="mc-button px-3 py-1 text-xs text-stone-200 cursor-pointer">
            ✕
          </button>
        </div>

        <div className="flex flex-wrap gap-1 mb-3">
          {(['all', 'tools', 'combat', 'blocks', 'realm'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-3 py-1 text-xs uppercase cursor-pointer border-2 ${
                category === cat
                  ? 'bg-amber-600 border-amber-800 text-white font-bold'
                  : 'bg-stone-300 border-stone-500 text-stone-700 hover:bg-stone-200'
              }`}
            >
              {cat === 'realm' ? '🕌 Realm' : cat}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          <div className="flex flex-col sm:flex-row gap-4 p-3 bg-stone-300 border-2 border-stone-400">
            <div className="flex-1 max-h-48 overflow-y-auto space-y-1 pr-1 border-r border-stone-400">
              {filteredRecipes.map((r) => (
                <div
                  key={r.id}
                  onClick={() => setSelectedRecipe(r)}
                  className={`p-2 flex items-center justify-between cursor-pointer border ${
                    selectedRecipe?.id === r.id
                      ? 'bg-amber-100 border-amber-600 font-bold'
                      : 'bg-stone-200 border-stone-300 hover:bg-stone-100'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{getItemEmoji(r.result)}</span>
                    <span className="text-xs text-stone-800">{r.name}</span>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCraft(r);
                    }}
                    className="mc-button mc-button-green px-2 py-1 text-[10px] text-white cursor-pointer"
                  >
                    CRAFT
                  </button>
                </div>
              ))}
            </div>

            {selectedRecipe && (
              <div className="flex flex-col items-center justify-center p-2 min-w-[200px]">
                <span className="text-xs font-bold text-stone-700 mb-2">Recipe Shape</span>
                <div className="grid grid-cols-3 gap-1 bg-stone-400 p-2 border-2 border-stone-600 mb-3">
                  {Array.from({ length: 9 }).map((_, i) => {
                    const itemPattern = selectedRecipe.pattern[i];
                    return (
                      <div
                        key={i}
                        className="w-9 h-9 mc-slot flex items-center justify-center text-xs"
                      >
                        {itemPattern && (
                          <span className="text-sm">
                            {itemPattern.includes('pickaxe')
                              ? '⛏️'
                              : itemPattern.includes('stick')
                              ? '🥢'
                              : itemPattern.includes('wood')
                              ? '🪵'
                              : itemPattern.includes('cobble')
                              ? '🧱'
                              : itemPattern.includes('diamond')
                              ? '💎'
                              : itemPattern.includes('gold')
                              ? '🪙'
                              : itemPattern.includes('iron')
                              ? '🔩'
                              : '📦'}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

                <button
                  onClick={() => handleCraft(selectedRecipe)}
                  className="mc-button mc-button-green w-full py-2 text-xs text-white cursor-pointer font-bold flex items-center justify-center gap-2"
                >
                  <span>{getItemEmoji(selectedRecipe.result)}</span>
                  <span>CRAFT {selectedRecipe.name.toUpperCase()}</span>
                </button>
              </div>
            )}
          </div>

          <div>
            <span className="text-xs font-bold text-stone-700 block mb-1">Hotbar Slots</span>
            <div className="grid grid-cols-9 gap-1 p-2 bg-stone-300 border-2 border-stone-400">
              {hot.map((item, idx) => (
                <div
                  key={idx}
                  className="w-8 h-8 sm:w-10 sm:h-10 mc-slot flex items-center justify-center relative cursor-pointer"
                >
                  {item && (
                    <>
                      <span className="text-sm sm:text-base select-none">{getItemEmoji(item)}</span>
                      {item.count > 1 && (
                        <span className="absolute bottom-0 right-0.5 text-[9px] font-bold text-white drop-shadow-[0_1px_1px_#000]">
                          {item.count}
                        </span>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
