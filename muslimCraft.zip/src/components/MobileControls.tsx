import React, { useRef, useState } from 'react';
import { VoxelEngine } from '../game/engine';

interface MobileControlsProps {
  engine: VoxelEngine | null;
  onOpenInventory: () => void;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  engine,
}) => {
  const [, setJoystickActive] = useState(false);
  const [joystickPos, setJoystickPos] = useState({ x: 0, y: 0 });
  const [isSneaking, setIsSneaking] = useState(false);

  const joystickTouchId = useRef<number | null>(null);
  const lookTouchId = useRef<number | null>(null);
  const lastLookPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const joystickCenter = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const handleJoystickStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (joystickTouchId.current !== null) return;
    const touch = e.changedTouches[0];
    joystickTouchId.current = touch.identifier;

    const rect = e.currentTarget.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    joystickCenter.current = { x: cx, y: cy };

    setJoystickActive(true);
    updateJoystick(touch.clientX, touch.clientY);
  };

  const handleJoystickMove = (e: React.TouchEvent<HTMLDivElement>) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === joystickTouchId.current) {
        updateJoystick(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleJoystickEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === joystickTouchId.current) {
        joystickTouchId.current = null;
        setJoystickActive(false);
        setJoystickPos({ x: 0, y: 0 });
        if (engine) {
          engine.moveInput.forward = 0;
          engine.moveInput.right = 0;
        }
        break;
      }
    }
  };

  const updateJoystick = (clientX: number, clientY: number) => {
    const dx = clientX - joystickCenter.current.x;
    const dy = clientY - joystickCenter.current.y;
    const distance = Math.hypot(dx, dy);
    const maxRadius = 45;

    let nx = dx;
    let ny = dy;

    if (distance > maxRadius) {
      nx = (dx / distance) * maxRadius;
      ny = (dy / distance) * maxRadius;
    }

    setJoystickPos({ x: nx, y: ny });

    if (engine) {
      engine.moveInput.forward = -ny / maxRadius;
      engine.moveInput.right = nx / maxRadius;
    }
  };

  const handleLookStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (lookTouchId.current !== null) return;
    const touch = e.changedTouches[0];
    lookTouchId.current = touch.identifier;
    lastLookPos.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleLookMove = (e: React.TouchEvent<HTMLDivElement>) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === lookTouchId.current && engine) {
        const dx = touch.clientX - lastLookPos.current.x;
        const dy = touch.clientY - lastLookPos.current.y;
        lastLookPos.current = { x: touch.clientX, y: touch.clientY };

        const sens = engine.settings.touchSensitivity * 0.005;
        engine.world.playerPos.yaw -= dx * sens;
        engine.world.playerPos.pitch -= dy * sens;
        engine.world.playerPos.pitch = Math.max(-1.5, Math.min(1.5, engine.world.playerPos.pitch));
        break;
      }
    }
  };

  const handleLookEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === lookTouchId.current) {
        lookTouchId.current = null;
        break;
      }
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none select-none z-10 font-pixel">
      <div
        className="absolute bottom-6 left-6 w-36 h-36 rounded-full bg-black/35 border-2 border-white/20 flex items-center justify-center pointer-events-auto touch-none"
        onTouchStart={handleJoystickStart}
        onTouchMove={handleJoystickMove}
        onTouchEnd={handleJoystickEnd}
        onTouchCancel={handleJoystickEnd}
      >
        <div
          className="w-14 h-14 rounded-full bg-stone-300/80 border-2 border-stone-800 shadow-md transition-transform"
          style={{
            transform: `translate(${joystickPos.x}px, ${joystickPos.y}px)`,
          }}
        />
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-40">
          <span className="text-[10px] text-white absolute top-1">▲</span>
          <span className="text-[10px] text-white absolute bottom-1">▼</span>
          <span className="text-[10px] text-white absolute left-1">◀</span>
          <span className="text-[10px] text-white absolute right-1">▶</span>
        </div>
      </div>

      <div
        className="absolute top-16 right-0 bottom-36 left-1/2 pointer-events-auto touch-none"
        onTouchStart={handleLookStart}
        onTouchMove={handleLookMove}
        onTouchEnd={handleLookEnd}
        onTouchCancel={handleLookEnd}
      />

      <div className="absolute bottom-6 right-6 flex flex-col items-end gap-3 pointer-events-auto">
        <div className="flex items-center gap-3">
          <button
            onTouchStart={(e) => {
              e.preventDefault();
              engine?.startMining();
              engine?.attack();
            }}
            onTouchEnd={(e) => {
              e.preventDefault();
              engine?.stopMining();
            }}
            onMouseDown={() => {
              engine?.startMining();
              engine?.attack();
            }}
            onMouseUp={() => engine?.stopMining()}
            className="mc-button w-14 h-14 rounded-md text-xl flex items-center justify-center cursor-pointer active:scale-90 text-amber-300 shadow-xl"
            title="Mine / Attack"
          >
            ⛏️
          </button>

          <button
            onTouchStart={(e) => {
              e.preventDefault();
              engine?.interactOrPlace();
            }}
            onClick={() => engine?.interactOrPlace()}
            className="mc-button mc-button-green w-14 h-14 rounded-md text-xl flex items-center justify-center cursor-pointer active:scale-90 text-emerald-200 shadow-xl"
            title="Place Block / Interact"
          >
            🧱
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              const next = !isSneaking;
              setIsSneaking(next);
              if (engine) engine.isSneaking = next;
            }}
            className={`mc-button w-13 h-13 rounded-md text-sm font-bold flex items-center justify-center cursor-pointer active:scale-90 ${
              isSneaking ? 'bg-amber-800 border-amber-400 text-amber-200' : 'text-stone-300'
            }`}
            title="Toggle Sneak"
          >
            👣
          </button>

          <button
            onTouchStart={(e) => {
              e.preventDefault();
              if (engine) engine.isJumping = true;
            }}
            onTouchEnd={(e) => {
              e.preventDefault();
              if (engine) engine.isJumping = false;
            }}
            onMouseDown={() => {
              if (engine) engine.isJumping = true;
            }}
            onMouseUp={() => {
              if (engine) engine.isJumping = false;
            }}
            className="mc-button w-16 h-16 rounded-md text-2xl flex items-center justify-center cursor-pointer active:scale-90 text-white shadow-2xl"
            title="Jump (Space)"
          >
            🦘
          </button>
        </div>
      </div>
    </div>
  );
};
