import React, { useState } from 'react';
import { ItemStack } from '../types/game';
import { getItemEmoji } from './InGameHUD';
import { soundManager } from '../game/audio';

interface ChestModalProps {
  chestKey: string;
  chestItems: (ItemStack | null)[];
  inventory: (ItemStack | null)[];
  hotbar: (ItemStack | null)[];
  onClose: () => void;
  onUpdateChest: (chestKey: string, items: (ItemStack | null)[]) => void;
  onUpdateInventory: (inv: (ItemStack | null)[], hot: (ItemStack | null)[]) => void;
}

export const ChestModal: React.FC<ChestModalProps> = ({
  chestKey,
  chestItems,
  inventory,
  hotbar,
  onClose,
  onUpdateChest,
  onUpdateInventory,
}) => {
  const [chest, setChest] = useState<(ItemStack | null)[]>([...chestItems]);
  const [inv, setInv] = useState<(ItemStack | null)[]>([...inventory]);
  const [hot, setHot] = useState<(ItemStack | null)[]>([...hotbar]);

  // Click on item in chest -> move to player hotbar or inventory
  const handleTransferFromChest = (idx: number) => {
    const item = chest[idx];
    if (!item) return;

    soundManager.playPlace();
    const newHot = [...hot];
    const newInv = [...inv];
    const newChest = [...chest];

    let placed = false;
    // Try hotbar
    for (let i = 0; i < newHot.length; i++) {
      if (newHot[i] === null) {
        newHot[i] = { ...item };
        placed = true;
        break;
      }
    }
    // Try inventory
    if (!placed) {
      for (let i = 0; i < newInv.length; i++) {
        if (newInv[i] === null) {
          newInv[i] = { ...item };
          placed = true;
          break;
        }
      }
    }

    if (placed) {
      newChest[idx] = null;
      setChest(newChest);
      setHot(newHot);
      setInv(newInv);
      onUpdateChest(chestKey, newChest);
      onUpdateInventory(newInv, newHot);
    }
  };

  // Click on item in player inventory/hotbar -> move to chest
  const handleTransferToChest = (item: ItemStack, isHotbar: boolean, slotIdx: number) => {
    soundManager.playPlace();
    const newChest = [...chest];
    const newHot = [...hot];
    const newInv = [...inv];

    // Find empty chest slot
    const emptyIdx = newChest.findIndex((s) => s === null);
    if (emptyIdx >= 0) {
      newChest[emptyIdx] = { ...item };
      if (isHotbar) {
        newHot[slotIdx] = null;
      } else {
        newInv[slotIdx] = null;
      }
      setChest(newChest);
      setHot(newHot);
      setInv(newInv);
      onUpdateChest(chestKey, newChest);
      onUpdateInventory(newInv, newHot);
    }
  };

  const handleClose = () => {
    soundManager.playChest(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 font-pixel select-none">
      <div className="mc-panel w-full max-w-2xl max-h-[92vh] flex flex-col p-4 text-stone-900 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b-2 border-stone-400 mb-3">
          <div className="flex items-center gap-2">
            <span className="text-xl">📦</span>
            <h2 className="text-sm sm:text-base font-bold text-stone-800">
              CHEST STORAGE (27 SLOTS)
            </h2>
          </div>
          <button onClick={handleClose} className="mc-button px-3 py-1 text-xs text-stone-200 cursor-pointer">
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {/* Chest Contents Grid (27 slots) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-stone-700">Chest Items (Tap to take):</span>
              <span className="text-[10px] text-stone-500 font-silkscreen">Pos: {chestKey}</span>
            </div>
            <div className="grid grid-cols-9 gap-1 p-2 bg-stone-300 border-2 border-stone-400">
              {chest.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => handleTransferFromChest(idx)}
                  className="w-8 h-8 sm:w-10 sm:h-10 mc-slot flex items-center justify-center relative cursor-pointer hover:bg-stone-200"
                >
                  {item && (
                    <>
                      <span className="text-sm sm:text-base select-none">{getItemEmoji(item)}</span>
                      {item.count > 1 && (
                        <span className="absolute bottom-0 right-0.5 text-[9px] font-bold text-white drop-shadow-[0_1px_1px_#000]">
                          {item.count}
                        </span>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Player Inventory (Tap to store in chest) */}
          <div>
            <span className="text-xs font-bold text-stone-700 block mb-1">
              Player Inventory (Tap to store):
            </span>
            <div className="grid grid-cols-9 gap-1 p-2 bg-stone-300 border-2 border-stone-400">
              {inv.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => item && handleTransferToChest(item, false, idx)}
                  className="w-8 h-8 sm:w-10 sm:h-10 mc-slot flex items-center justify-center relative cursor-pointer hover:bg-stone-200"
                >
                  {item && (
                    <>
                      <span className="text-sm sm:text-base select-none">{getItemEmoji(item)}</span>
                      {item.count > 1 && (
                        <span className="absolute bottom-0 right-0.5 text-[9px] font-bold text-white drop-shadow-[0_1px_1px_#000]">
                          {item.count}
                        </span>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Player Hotbar */}
          <div>
            <span className="text-xs font-bold text-stone-700 block mb-1">Player Hotbar:</span>
            <div className="grid grid-cols-9 gap-1 p-2 bg-stone-300 border-2 border-stone-400">
              {hot.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => item && handleTransferToChest(item, true, idx)}
                  className="w-8 h-8 sm:w-10 sm:h-10 mc-slot flex items-center justify-center relative cursor-pointer hover:bg-stone-200"
                >
                  {item && (
                    <>
                      <span className="text-sm sm:text-base select-none">{getItemEmoji(item)}</span>
                      {item.count > 1 && (
                        <span className="absolute bottom-0 right-0.5 text-[9px] font-bold text-white drop-shadow-[0_1px_1px_#000]">
                          {item.count}
                        </span>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
