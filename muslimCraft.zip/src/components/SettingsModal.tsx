import React, { useState } from 'react';
import { GameSettings } from '../types/game';
import { soundManager } from '../game/audio';
import { StorageService } from '../game/storage';

interface SettingsModalProps {
  currentSettings: GameSettings;
  onSave: (settings: GameSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  currentSettings,
  onSave,
  onClose,
}) => {
  const [settings, setSettings] = useState<GameSettings>({ ...currentSettings });

  const handleSave = () => {
    soundManager.setVolumes(settings.sfxVolume, settings.musicVolume);
    StorageService.saveSettings(settings);
    onSave(settings);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 font-pixel">
      <div className="mc-panel w-full max-w-xl max-h-[92vh] flex flex-col p-4 sm:p-6 text-stone-900 select-none overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b-2 border-stone-400 mb-4">
          <h2 className="text-base sm:text-lg font-bold text-stone-800">GAME SETTINGS</h2>
          <button
            onClick={onClose}
            className="mc-button px-3 py-1 text-xs text-stone-200 cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs sm:text-sm">
          <div className="flex items-center justify-between">
            <span className="font-bold text-stone-700">Graphics Quality</span>
            <button
              type="button"
              onClick={() =>
                setSettings((s) => ({
                  ...s,
                  graphicsQuality: s.graphicsQuality === 'fancy' ? 'fast' : 'fancy',
                }))
              }
              className="mc-button px-4 py-2 text-stone-200 uppercase min-w-[120px]"
            >
              {settings.graphicsQuality}
            </button>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between font-bold text-stone-700">
              <span>Render Distance</span>
              <span className="text-stone-900">{settings.renderDistance} Chunks</span>
            </div>
            <input
              type="range"
              min="2"
              max="8"
              step="1"
              value={settings.renderDistance}
              onChange={(e) =>
                setSettings((s) => ({ ...s, renderDistance: parseInt(e.target.value) }))
              }
              className="w-full cursor-pointer accent-emerald-600"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between font-bold text-stone-700">
              <span>Field of View (FOV)</span>
              <span className="text-stone-900">{settings.fov}°</span>
            </div>
            <input
              type="range"
              min="60"
              max="100"
              step="5"
              value={settings.fov}
              onChange={(e) => setSettings((s) => ({ ...s, fov: parseInt(e.target.value) }))}
              className="w-full cursor-pointer accent-emerald-600"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between font-bold text-stone-700">
              <span>Touch / Mouse Sensitivity</span>
              <span className="text-stone-900">{Math.round(settings.touchSensitivity * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.4"
              max="2.5"
              step="0.1"
              value={settings.touchSensitivity}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                setSettings((s) => ({ ...s, touchSensitivity: val, mouseSensitivity: val }));
              }}
              className="w-full cursor-pointer accent-emerald-600"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between font-bold text-stone-700">
              <span>Sound Effects (SFX)</span>
              <span className="text-stone-900">{Math.round(settings.sfxVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.sfxVolume}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                setSettings((s) => ({ ...s, sfxVolume: val }));
                soundManager.setVolumes(val, settings.musicVolume);
              }}
              className="w-full cursor-pointer accent-emerald-600"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between font-bold text-stone-700">
              <span>Ambient Music Volume</span>
              <span className="text-stone-900">{Math.round(settings.musicVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.musicVolume}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                setSettings((s) => ({ ...s, musicVolume: val }));
                soundManager.setVolumes(settings.sfxVolume, val);
              }}
              className="w-full cursor-pointer accent-emerald-600"
            />
          </div>

          <div className="flex items-center justify-between">
            <span className="font-bold text-stone-700">Camera Perspective</span>
            <button
              type="button"
              onClick={() => setSettings((s) => ({ ...s, thirdPerson: !s.thirdPerson }))}
              className="mc-button px-4 py-2 text-stone-200 min-w-[140px]"
            >
              {settings.thirdPerson ? '3RD PERSON' : '1ST PERSON'}
            </button>
          </div>

          <div className="flex items-center justify-between">
            <span className="font-bold text-stone-700">Language</span>
            <select
              value={settings.language}
              onChange={(e) =>
                setSettings((s) => ({ ...s, language: e.target.value as GameSettings['language'] }))
              }
              className="px-3 py-2 bg-stone-800 border-2 border-stone-600 text-white font-silkscreen focus:outline-none"
            >
              <option value="en">English</option>
              <option value="ar">العربية (Arabic)</option>
              <option value="ur">اردو (Urdu)</option>
              <option value="id">Bahasa Indonesia</option>
            </select>
          </div>

          <div className="flex items-center justify-between">
            <span className="font-bold text-stone-700">Show Coordinates</span>
            <button
              type="button"
              onClick={() => setSettings((s) => ({ ...s, showCoordinates: !s.showCoordinates }))}
              className="mc-button px-4 py-1.5 text-stone-200 min-w-[100px]"
            >
              {settings.showCoordinates ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>

        <div className="flex gap-3 pt-3 border-t-2 border-stone-400 mt-3">
          <button
            onClick={handleSave}
            className="mc-button mc-button-green flex-1 py-3 text-white font-bold cursor-pointer"
          >
            SAVE SETTINGS
          </button>
          <button
            onClick={onClose}
            className="mc-button px-6 py-3 text-stone-200 cursor-pointer"
          >
            CANCEL
          </button>
        </div>
      </div>
    </div>
  );
};
