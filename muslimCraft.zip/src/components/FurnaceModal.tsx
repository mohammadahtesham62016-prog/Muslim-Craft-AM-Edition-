import React, { useEffect, useState } from 'react';
import { SMELTING_RECIPES, SmeltingRecipe } from '../game/recipes';
import { ItemStack } from '../types/game';
import { getItemEmoji } from './InGameHUD';
import { soundManager } from '../game/audio';

interface FurnaceModalProps {
  inventory: (ItemStack | null)[];
  hotbar: (ItemStack | null)[];
  onClose: () => void;
  onUpdateInventory: (inv: (ItemStack | null)[], hot: (ItemStack | null)[]) => void;
}

export const FurnaceModal: React.FC<FurnaceModalProps> = ({
  inventory,
  hotbar,
  onClose,
  onUpdateInventory,
}) => {
  const [inv, setInv] = useState<(ItemStack | null)[]>([...inventory]);
  const [hot, setHot] = useState<(ItemStack | null)[]>([...hotbar]);

  const [inputSlot, setInputSlot] = useState<ItemStack | null>({
    id: 'iron_ore',
    isBlock: true,
    blockType: 21,
    count: 3,
    maxStack: 64,
  });
  const [fuelSlot, setFuelSlot] = useState<ItemStack | null>({
    id: 'coal',
    isBlock: false,
    itemType: 'coal',
    count: 4,
    maxStack: 64,
  });
  const [outputSlot, setOutputSlot] = useState<ItemStack | null>(null);

  const [smeltProgress, setSmeltProgress] = useState(0); // 0 to 100
  const [, setBurnProgress] = useState(80); // 0 to 100

  // Smelting simulation timer
  useEffect(() => {
    const timer = setInterval(() => {
      if (inputSlot && fuelSlot) {
        setSmeltProgress((prev) => {
          if (prev >= 100) {
            // Find smelting recipe
            const recipe = SMELTING_RECIPES.find(
              (r: SmeltingRecipe) => r.input === inputSlot.id || r.input === inputSlot.itemType
            );

            if (recipe) {
              soundManager.playPlace();
              // Produce output
              setOutputSlot((curr: ItemStack | null) => {
                if (!curr) return { ...recipe.output };
                return { ...curr, count: curr.count + recipe.output.count };
              });

              // Consume 1 input
              setInputSlot((curr: ItemStack | null) => {
                if (!curr || curr.count <= 1) return null;
                return { ...curr, count: curr.count - 1 };
              });
            }
            return 0;
          }
          return prev + 15;
        });
      } else {
        setSmeltProgress(0);
      }
    }, 400);

    return () => clearInterval(timer);
  }, [inputSlot, fuelSlot]);

  const handleTakeOutput = () => {
    if (!outputSlot) return;
    soundManager.playPlace();

    const newHot = [...hot];
    const newInv = [...inv];
    let placed = false;

    for (let i = 0; i < newHot.length; i++) {
      if (newHot[i] === null) {
        newHot[i] = { ...outputSlot };
        placed = true;
        break;
      }
    }
    if (!placed) {
      for (let i = 0; i < newInv.length; i++) {
        if (newInv[i] === null) {
          newInv[i] = { ...outputSlot };
          placed = true;
          break;
        }
      }
    }

    if (placed) {
      setOutputSlot(null);
      setHot(newHot);
      setInv(newInv);
      onUpdateInventory(newInv, newHot);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 font-pixel select-none">
      <div className="mc-panel w-full max-w-lg max-h-[92vh] flex flex-col p-4 text-stone-900 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b-2 border-stone-400 mb-3">
          <h2 className="text-sm sm:text-base font-bold text-stone-800">FURNACE</h2>
          <button onClick={onClose} className="mc-button px-3 py-1 text-xs text-stone-200 cursor-pointer">
            ✕
          </button>
        </div>

        {/* Smelting Rig */}
        <div className="flex flex-col items-center justify-center p-6 bg-stone-300 border-2 border-stone-400 mb-4">
          <div className="flex items-center gap-6">
            {/* Left: Input & Fuel */}
            <div className="flex flex-col items-center gap-3">
              {/* Input Slot */}
              <div className="flex flex-col items-center">
                <span className="text-[10px] text-stone-600 mb-1">Ore / Food</span>
                <div className="w-12 h-12 mc-slot flex items-center justify-center relative cursor-pointer">
                  {inputSlot && (
                    <>
                      <span className="text-xl">{getItemEmoji(inputSlot)}</span>
                      <span className="absolute bottom-0 right-1 text-xs font-bold text-white drop-shadow">
                        {inputSlot.count}
                      </span>
                    </>
                  )}
                </div>
              </div>

              {/* Burning Flame Icon */}
              <div className="text-lg text-amber-500 animate-pulse">
                {fuelSlot ? '🔥' : '♨️'}
              </div>

              {/* Fuel Slot */}
              <div className="flex flex-col items-center">
                <span className="text-[10px] text-stone-600 mb-1">Fuel</span>
                <div className="w-12 h-12 mc-slot flex items-center justify-center relative cursor-pointer">
                  {fuelSlot && (
                    <>
                      <span className="text-xl">{getItemEmoji(fuelSlot)}</span>
                      <span className="absolute bottom-0 right-1 text-xs font-bold text-white drop-shadow">
                        {fuelSlot.count}
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Middle: Animated Smelting Arrow Progress */}
            <div className="flex flex-col items-center gap-1">
              <div className="w-16 h-4 bg-stone-500 border border-stone-700 relative overflow-hidden">
                <div
                  className="h-full bg-amber-400 transition-all duration-300"
                  style={{ width: `${smeltProgress}%` }}
                />
              </div>
              <span className="text-[9px] text-stone-600 font-bold">{smeltProgress}%</span>
            </div>

            {/* Right: Output Slot */}
            <div className="flex flex-col items-center">
              <span className="text-[10px] text-stone-600 mb-1">Output</span>
              <div
                onClick={handleTakeOutput}
                className={`w-14 h-14 mc-slot flex items-center justify-center relative cursor-pointer ${
                  outputSlot ? 'ring-2 ring-emerald-500 bg-emerald-100' : ''
                }`}
              >
                {outputSlot && (
                  <>
                    <span className="text-2xl">{getItemEmoji(outputSlot)}</span>
                    <span className="absolute bottom-0.5 right-1 text-xs font-bold text-white bg-black/60 px-1">
                      {outputSlot.count}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Player Hotbar */}
        <div>
          <span className="text-xs font-bold text-stone-700 block mb-1">Player Hotbar</span>
          <div className="grid grid-cols-9 gap-1 p-2 bg-stone-300 border-2 border-stone-400">
            {hot.map((item, idx) => (
              <div
                key={idx}
                className="w-8 h-8 sm:w-10 sm:h-10 mc-slot flex items-center justify-center relative cursor-pointer"
              >
                {item && (
                  <>
                    <span className="text-sm sm:text-base select-none">{getItemEmoji(item)}</span>
                    {item.count > 1 && (
                      <span className="absolute bottom-0 right-0.5 text-[9px] font-bold text-white drop-shadow-[0_1px_1px_#000]">
                        {item.count}
                      </span>
                    )}
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
