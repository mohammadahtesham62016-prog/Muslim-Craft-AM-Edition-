export type GameMode = 'survival' | 'adventure' | 'spectator';

export type Dimension = 'overworld' | 'nether' | 'the_end' | 'muslim_realm';

export enum BlockType {
  AIR = 0,
  GRASS = 1,
  DIRT = 2,
  STONE = 3,
  COBBLESTONE = 4,
  OAK_WOOD = 5,
  OAK_LEAVES = 6,
  SAND = 7,
  GRAVEL = 8,
  GLASS = 9,
  BRICKS = 10,
  IRON_BLOCK = 11,
  GOLD_BLOCK = 12,
  DIAMOND_BLOCK = 13,
  CRAFTING_TABLE = 14,
  FURNACE = 15,
  CHEST = 16,
  TORCH = 17,
  WATER = 18,
  LAVA = 19,
  COAL_ORE = 20,
  IRON_ORE = 21,
  GOLD_ORE = 22,
  DIAMOND_ORE = 23,
  // Nether
  NETHERRACK = 24,
  GLOWSTONE = 25,
  NETHER_BRICKS = 26,
  // The End
  END_STONE = 27,
  OBSIDIAN = 28,
  PURPUR = 29,
  // Muslim Realm unique blocks
  OASIS_SANDSTONE = 30,
  PALM_WOOD = 31,
  PALM_LEAVES = 32,
  TURQUOISE_MOSAIC = 33,
  GOLDEN_ARABESQUE = 34,
  LAPIS_BRICK = 35,
  WHITE_MARBLE = 36,
  OASIS_WATER = 37,
}

export type ItemType =
  | 'wooden_pickaxe'
  | 'stone_pickaxe'
  | 'iron_pickaxe'
  | 'diamond_pickaxe'
  | 'wooden_axe'
  | 'stone_axe'
  | 'iron_axe'
  | 'diamond_axe'
  | 'wooden_shovel'
  | 'stone_shovel'
  | 'iron_shovel'
  | 'diamond_shovel'
  | 'wooden_sword'
  | 'stone_sword'
  | 'iron_sword'
  | 'diamond_sword'
  | 'bow'
  | 'arrow'
  | 'stick'
  | 'coal'
  | 'iron_ingot'
  | 'gold_ingot'
  | 'diamond'
  | 'apple'
  | 'bread'
  | 'wheat'
  | 'raw_beef'
  | 'cooked_beef'
  | 'string'
  | 'feather'
  | 'gunpowder'
  | 'rotten_flesh'
  | 'ender_pearl'
  | 'blaze_rod';

export interface ItemStack {
  id: string;
  isBlock: boolean;
  blockType?: BlockType;
  itemType?: ItemType;
  count: number;
  maxStack: number;
  durability?: number;
  maxDurability?: number;
}

export interface PlayerStats {
  health: number;
  maxHealth: number;
  hunger: number;
  maxHunger: number;
  saturation: number;
  armor: number;
  score: number;
  isDead: boolean;
}

export interface PlayerPosition {
  x: number;
  y: number;
  z: number;
  pitch: number;
  yaw: number;
}

export interface ChestData {
  items: (ItemStack | null)[];
}

export interface SavedWorld {
  id: string;
  name: string;
  seed: string;
  gameMode: GameMode;
  dimension: Dimension;
  createdAt: number;
  lastPlayed: number;
  playerPos: PlayerPosition;
  playerStats: PlayerStats;
  inventory: (ItemStack | null)[];
  hotbar: (ItemStack | null)[];
  activeHotbarIndex: number;
  chests: Record<string, (ItemStack | null)[]>;
  modifiedBlocks: Record<string, number>;
  timeOfDay: number;
}

export interface GameSettings {
  graphicsQuality: 'fast' | 'fancy';
  renderDistance: number;
  mouseSensitivity: number;
  touchSensitivity: number;
  fov: number;
  musicVolume: number;
  sfxVolume: number;
  thirdPerson: boolean;
  language: 'en' | 'ar' | 'ur' | 'id';
  showCoordinates: boolean;
  showFps: boolean;
}

export interface MobEntity {
  id: string;
  type:
    | 'villager'
    | 'iron_golem'
    | 'cow'
    | 'sheep'
    | 'pig'
    | 'chicken'
    | 'horse'
    | 'zombie'
    | 'skeleton'
    | 'creeper'
    | 'spider'
    | 'enderman'
    | 'ender_dragon';
  isPassive: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  yaw: number;
  pitch: number;
  health: number;
  maxHealth: number;
  walkCycle: number;
  attackCooldown: number;
  stateTimer: number;
  targetId?: string;
  exploding?: boolean;
  fuseTimer?: number;
}
