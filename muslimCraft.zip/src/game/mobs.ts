import * as THREE from 'three';
import { MobEntity } from '../types/game';
import { soundManager } from './audio';

export interface MobMeshInstance {
  entity: MobEntity;
  group: THREE.Group;
  head?: THREE.Object3D;
  leftLeg?: THREE.Object3D;
  rightLeg?: THREE.Object3D;
  leftArm?: THREE.Object3D;
  rightArm?: THREE.Object3D;
  leftHindLeg?: THREE.Object3D;
  rightHindLeg?: THREE.Object3D;
  leftWing?: THREE.Object3D;
  rightWing?: THREE.Object3D;
}

const mobMaterials = {
  villagerRobe: new THREE.MeshLambertMaterial({ color: 0x8b5a2b }),
  villagerSkin: new THREE.MeshLambertMaterial({ color: 0xbd8e72 }),
  villagerNose: new THREE.MeshLambertMaterial({ color: 0xa87b60 }),

  ironGolemBody: new THREE.MeshLambertMaterial({ color: 0xdedede }),
  ironGolemEyes: new THREE.MeshLambertMaterial({ color: 0xdc2626 }),

  cowBrown: new THREE.MeshLambertMaterial({ color: 0x5a3d28 }),
  cowWhite: new THREE.MeshLambertMaterial({ color: 0xe5e5e5 }),
  cowHorn: new THREE.MeshLambertMaterial({ color: 0x222222 }),

  sheepWool: new THREE.MeshLambertMaterial({ color: 0xf5f5f5 }),
  sheepSkin: new THREE.MeshLambertMaterial({ color: 0xd4b8a5 }),

  pigPink: new THREE.MeshLambertMaterial({ color: 0xf472b6 }),
  pigSnout: new THREE.MeshLambertMaterial({ color: 0xec4899 }),

  chickenWhite: new THREE.MeshLambertMaterial({ color: 0xffffff }),
  chickenRed: new THREE.MeshLambertMaterial({ color: 0xef4444 }),
  chickenBeak: new THREE.MeshLambertMaterial({ color: 0xf59e0b }),

  horseBrown: new THREE.MeshLambertMaterial({ color: 0x78350f }),

  zombieSkin: new THREE.MeshLambertMaterial({ color: 0x558b2f }),
  zombieShirt: new THREE.MeshLambertMaterial({ color: 0x0284c7 }),
  zombiePants: new THREE.MeshLambertMaterial({ color: 0x4338ca }),

  skeletonBone: new THREE.MeshLambertMaterial({ color: 0xd1d5db }),

  creeperGreen: new THREE.MeshLambertMaterial({ color: 0x22c55e }),
  creeperEye: new THREE.MeshLambertMaterial({ color: 0x0f172a }),

  spiderBlack: new THREE.MeshLambertMaterial({ color: 0x18181b }),
  spiderEye: new THREE.MeshBasicMaterial({ color: 0xef4444 }),

  endermanBlack: new THREE.MeshLambertMaterial({ color: 0x09090b }),
  endermanEye: new THREE.MeshBasicMaterial({ color: 0xc084fc }),

  dragonDark: new THREE.MeshLambertMaterial({ color: 0x18181b }),
  dragonPurple: new THREE.MeshBasicMaterial({ color: 0xa855f7 }),
};

export function createMobMesh(entity: MobEntity): MobMeshInstance {
  const group = new THREE.Group();
  group.position.set(entity.x, entity.y, entity.z);

  const instance: MobMeshInstance = { entity, group };

  switch (entity.type) {
    case 'villager': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.9, 0.4), mobMaterials.villagerRobe);
      body.position.y = 0.85;
      group.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.6, 0.5), mobMaterials.villagerSkin);
      head.position.y = 1.5;

      const nose = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.25, 0.12), mobMaterials.villagerNose);
      nose.position.set(0, -0.05, 0.3);
      head.add(nose);
      group.add(head);
      instance.head = head;

      const arms = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.35, 0.35), mobMaterials.villagerRobe);
      arms.position.set(0, 0.85, 0.2);
      group.add(arms);

      const legGeo = new THREE.BoxGeometry(0.24, 0.5, 0.24);
      const leftLeg = new THREE.Mesh(legGeo, mobMaterials.villagerRobe);
      leftLeg.position.set(-0.16, 0.25, 0);
      const rightLeg = new THREE.Mesh(legGeo, mobMaterials.villagerRobe);
      rightLeg.position.set(0.16, 0.25, 0);
      group.add(leftLeg, rightLeg);
      instance.leftLeg = leftLeg;
      instance.rightLeg = rightLeg;
      break;
    }

    case 'iron_golem': {
      const torso = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.4, 0.7), mobMaterials.ironGolemBody);
      torso.position.y = 1.8;
      group.add(torso);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.8, 0.6), mobMaterials.ironGolemBody);
      head.position.y = 2.8;
      const nose = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.3, 0.16), mobMaterials.ironGolemBody);
      nose.position.set(0, -0.1, 0.36);
      head.add(nose);
      const leftEye = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.08, 0.05), mobMaterials.ironGolemEyes);
      leftEye.position.set(-0.16, 0.05, 0.31);
      const rightEye = leftEye.clone();
      rightEye.position.x = 0.16;
      head.add(leftEye, rightEye);
      group.add(head);
      instance.head = head;

      const armGeo = new THREE.BoxGeometry(0.35, 1.6, 0.35);
      const leftArm = new THREE.Mesh(armGeo, mobMaterials.ironGolemBody);
      leftArm.position.set(-0.85, 1.7, 0);
      const rightArm = new THREE.Mesh(armGeo, mobMaterials.ironGolemBody);
      rightArm.position.set(0.85, 1.7, 0);
      group.add(leftArm, rightArm);
      instance.leftArm = leftArm;
      instance.rightArm = rightArm;

      const legGeo = new THREE.BoxGeometry(0.45, 1.1, 0.45);
      const leftLeg = new THREE.Mesh(legGeo, mobMaterials.ironGolemBody);
      leftLeg.position.set(-0.35, 0.55, 0);
      const rightLeg = new THREE.Mesh(legGeo, mobMaterials.ironGolemBody);
      rightLeg.position.set(0.35, 0.55, 0);
      group.add(leftLeg, rightLeg);
      instance.leftLeg = leftLeg;
      instance.rightLeg = rightLeg;
      break;
    }

    case 'cow': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.7, 1.2), mobMaterials.cowBrown);
      body.position.y = 0.8;
      group.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), mobMaterials.cowBrown);
      head.position.set(0, 1.1, 0.7);
      const leftHorn = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.16, 0.08), mobMaterials.cowHorn);
      leftHorn.position.set(-0.25, 0.3, 0);
      const rightHorn = leftHorn.clone();
      rightHorn.position.x = 0.25;
      head.add(leftHorn, rightHorn);
      group.add(head);
      instance.head = head;

      const legGeo = new THREE.BoxGeometry(0.2, 0.5, 0.2);
      const fl = new THREE.Mesh(legGeo, mobMaterials.cowWhite);
      fl.position.set(-0.3, 0.25, 0.4);
      const fr = new THREE.Mesh(legGeo, mobMaterials.cowWhite);
      fr.position.set(0.3, 0.25, 0.4);
      const bl = new THREE.Mesh(legGeo, mobMaterials.cowBrown);
      bl.position.set(-0.3, 0.25, -0.4);
      const br = new THREE.Mesh(legGeo, mobMaterials.cowBrown);
      br.position.set(0.3, 0.25, -0.4);
      group.add(fl, fr, bl, br);
      instance.leftLeg = fl;
      instance.rightLeg = fr;
      instance.leftHindLeg = bl;
      instance.rightHindLeg = br;
      break;
    }

    case 'sheep': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.8, 1.2), mobMaterials.sheepWool);
      body.position.y = 0.85;
      group.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 0.5), mobMaterials.sheepSkin);
      head.position.set(0, 1.1, 0.7);
      group.add(head);
      instance.head = head;

      const legGeo = new THREE.BoxGeometry(0.18, 0.5, 0.18);
      const fl = new THREE.Mesh(legGeo, mobMaterials.sheepSkin);
      fl.position.set(-0.3, 0.25, 0.4);
      const fr = new THREE.Mesh(legGeo, mobMaterials.sheepSkin);
      fr.position.set(0.3, 0.25, 0.4);
      const bl = new THREE.Mesh(legGeo, mobMaterials.sheepSkin);
      bl.position.set(-0.3, 0.25, -0.4);
      const br = new THREE.Mesh(legGeo, mobMaterials.sheepSkin);
      br.position.set(0.3, 0.25, -0.4);
      group.add(fl, fr, bl, br);
      instance.leftLeg = fl;
      instance.rightLeg = fr;
      instance.leftHindLeg = bl;
      instance.rightHindLeg = br;
      break;
    }

    case 'pig': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.6, 1.0), mobMaterials.pigPink);
      body.position.y = 0.65;
      group.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.45, 0.45), mobMaterials.pigPink);
      head.position.set(0, 0.9, 0.6);
      const snout = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.12, 0.1), mobMaterials.pigSnout);
      snout.position.set(0, -0.08, 0.26);
      head.add(snout);
      group.add(head);
      instance.head = head;

      const legGeo = new THREE.BoxGeometry(0.18, 0.4, 0.18);
      const fl = new THREE.Mesh(legGeo, mobMaterials.pigPink);
      fl.position.set(-0.25, 0.2, 0.35);
      const fr = new THREE.Mesh(legGeo, mobMaterials.pigPink);
      fr.position.set(0.25, 0.2, 0.35);
      const bl = new THREE.Mesh(legGeo, mobMaterials.pigPink);
      bl.position.set(-0.25, 0.2, -0.35);
      const br = new THREE.Mesh(legGeo, mobMaterials.pigPink);
      br.position.set(0.25, 0.2, -0.35);
      group.add(fl, fr, bl, br);
      instance.leftLeg = fl;
      instance.rightLeg = fr;
      instance.leftHindLeg = bl;
      instance.rightHindLeg = br;
      break;
    }

    case 'chicken': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.45), mobMaterials.chickenWhite);
      body.position.y = 0.45;
      group.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.35, 0.25), mobMaterials.chickenWhite);
      head.position.set(0, 0.75, 0.22);
      const beak = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 0.12), mobMaterials.chickenBeak);
      beak.position.set(0, -0.05, 0.16);
      const wattle = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.1, 0.08), mobMaterials.chickenRed);
      wattle.position.set(0, -0.12, 0.12);
      head.add(beak, wattle);
      group.add(head);
      instance.head = head;

      const legGeo = new THREE.BoxGeometry(0.06, 0.28, 0.06);
      const leftLeg = new THREE.Mesh(legGeo, mobMaterials.chickenBeak);
      leftLeg.position.set(-0.1, 0.14, 0);
      const rightLeg = new THREE.Mesh(legGeo, mobMaterials.chickenBeak);
      rightLeg.position.set(0.1, 0.14, 0);
      group.add(leftLeg, rightLeg);
      instance.leftLeg = leftLeg;
      instance.rightLeg = rightLeg;
      break;
    }

    case 'horse': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.75, 1.4), mobMaterials.horseBrown);
      body.position.y = 1.25;
      group.add(body);

      const neck = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.8, 0.4), mobMaterials.horseBrown);
      neck.position.set(0, 1.8, 0.6);
      neck.rotation.x = -0.3;
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.6), mobMaterials.horseBrown);
      head.position.set(0, 0.45, 0.2);
      neck.add(head);
      group.add(neck);
      instance.head = neck;

      const legGeo = new THREE.BoxGeometry(0.18, 0.9, 0.18);
      const fl = new THREE.Mesh(legGeo, mobMaterials.horseBrown);
      fl.position.set(-0.25, 0.45, 0.5);
      const fr = new THREE.Mesh(legGeo, mobMaterials.horseBrown);
      fr.position.set(0.25, 0.45, 0.5);
      const bl = new THREE.Mesh(legGeo, mobMaterials.horseBrown);
      bl.position.set(-0.25, 0.45, -0.5);
      const br = new THREE.Mesh(legGeo, mobMaterials.horseBrown);
      br.position.set(0.25, 0.45, -0.5);
      group.add(fl, fr, bl, br);
      instance.leftLeg = fl;
      instance.rightLeg = fr;
      instance.leftHindLeg = bl;
      instance.rightHindLeg = br;
      break;
    }

    case 'zombie': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.7, 0.25), mobMaterials.zombieShirt);
      body.position.y = 1.05;
      group.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.45, 0.45), mobMaterials.zombieSkin);
      head.position.y = 1.6;
      group.add(head);
      instance.head = head;

      const armGeo = new THREE.BoxGeometry(0.18, 0.6, 0.18);
      const leftArm = new THREE.Mesh(armGeo, mobMaterials.zombieSkin);
      leftArm.position.set(-0.35, 1.25, 0.28);
      leftArm.rotation.x = -Math.PI / 2;
      const rightArm = new THREE.Mesh(armGeo, mobMaterials.zombieSkin);
      rightArm.position.set(0.35, 1.25, 0.28);
      rightArm.rotation.x = -Math.PI / 2;
      group.add(leftArm, rightArm);
      instance.leftArm = leftArm;
      instance.rightArm = rightArm;

      const legGeo = new THREE.BoxGeometry(0.2, 0.7, 0.2);
      const leftLeg = new THREE.Mesh(legGeo, mobMaterials.zombiePants);
      leftLeg.position.set(-0.14, 0.35, 0);
      const rightLeg = new THREE.Mesh(legGeo, mobMaterials.zombiePants);
      rightLeg.position.set(0.14, 0.35, 0);
      group.add(leftLeg, rightLeg);
      instance.leftLeg = leftLeg;
      instance.rightLeg = rightLeg;
      break;
    }

    case 'skeleton': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.65, 0.2), mobMaterials.skeletonBone);
      body.position.y = 1.05;
      group.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 0.4), mobMaterials.skeletonBone);
      head.position.y = 1.6;
      group.add(head);
      instance.head = head;

      const armGeo = new THREE.BoxGeometry(0.12, 0.6, 0.12);
      const leftArm = new THREE.Mesh(armGeo, mobMaterials.skeletonBone);
      leftArm.position.set(-0.28, 1.25, 0.25);
      leftArm.rotation.x = -Math.PI / 2;
      const rightArm = new THREE.Mesh(armGeo, mobMaterials.skeletonBone);
      rightArm.position.set(0.28, 1.25, 0.25);
      rightArm.rotation.x = -Math.PI / 2;
      group.add(leftArm, rightArm);
      instance.leftArm = leftArm;
      instance.rightArm = rightArm;

      const legGeo = new THREE.BoxGeometry(0.14, 0.7, 0.14);
      const leftLeg = new THREE.Mesh(legGeo, mobMaterials.skeletonBone);
      leftLeg.position.set(-0.12, 0.35, 0);
      const rightLeg = new THREE.Mesh(legGeo, mobMaterials.skeletonBone);
      rightLeg.position.set(0.12, 0.35, 0);
      group.add(leftLeg, rightLeg);
      instance.leftLeg = leftLeg;
      instance.rightLeg = rightLeg;
      break;
    }

    case 'creeper': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.75, 0.25), mobMaterials.creeperGreen);
      body.position.y = 0.85;
      group.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.45, 0.45), mobMaterials.creeperGreen);
      head.position.y = 1.45;
      const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.09, 0.05), mobMaterials.creeperEye);
      eyeL.position.set(-0.12, 0.05, 0.23);
      const eyeR = eyeL.clone();
      eyeR.position.x = 0.12;
      const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.18, 0.05), mobMaterials.creeperEye);
      mouth.position.set(0, -0.1, 0.23);
      head.add(eyeL, eyeR, mouth);
      group.add(head);
      instance.head = head;

      const legGeo = new THREE.BoxGeometry(0.18, 0.45, 0.18);
      const fl = new THREE.Mesh(legGeo, mobMaterials.creeperGreen);
      fl.position.set(-0.16, 0.22, 0.2);
      const fr = new THREE.Mesh(legGeo, mobMaterials.creeperGreen);
      fr.position.set(0.16, 0.22, 0.2);
      const bl = new THREE.Mesh(legGeo, mobMaterials.creeperGreen);
      bl.position.set(-0.16, 0.22, -0.2);
      const br = new THREE.Mesh(legGeo, mobMaterials.creeperGreen);
      br.position.set(0.16, 0.22, -0.2);
      group.add(fl, fr, bl, br);
      instance.leftLeg = fl;
      instance.rightLeg = fr;
      instance.leftHindLeg = bl;
      instance.rightHindLeg = br;
      break;
    }

    case 'spider': {
      const abdomen = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.4, 0.8), mobMaterials.spiderBlack);
      abdomen.position.set(0, 0.35, -0.3);
      const thorax = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.3, 0.45), mobMaterials.spiderBlack);
      thorax.position.set(0, 0.3, 0.25);
      const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.04), mobMaterials.spiderEye);
      eyeL.position.set(-0.1, 0.05, 0.24);
      const eyeR = eyeL.clone();
      eyeR.position.x = 0.1;
      thorax.add(eyeL, eyeR);
      group.add(abdomen, thorax);

      for (let i = 0; i < 4; i++) {
        const legGeo = new THREE.BoxGeometry(0.08, 0.08, 0.7);
        const lLeg = new THREE.Mesh(legGeo, mobMaterials.spiderBlack);
        lLeg.position.set(-0.4, 0.25, (i - 1.5) * 0.2);
        lLeg.rotation.z = 0.3;
        const rLeg = new THREE.Mesh(legGeo, mobMaterials.spiderBlack);
        rLeg.position.set(0.4, 0.25, (i - 1.5) * 0.2);
        rLeg.rotation.z = -0.3;
        group.add(lLeg, rLeg);
      }
      break;
    }

    case 'enderman': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.9, 0.2), mobMaterials.endermanBlack);
      body.position.y = 1.95;
      group.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.35), mobMaterials.endermanBlack);
      head.position.y = 2.6;
      const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.04, 0.03), mobMaterials.endermanEye);
      eyeL.position.set(-0.1, 0.02, 0.18);
      const eyeR = eyeL.clone();
      eyeR.position.x = 0.1;
      head.add(eyeL, eyeR);
      group.add(head);
      instance.head = head;

      const armGeo = new THREE.BoxGeometry(0.1, 1.4, 0.1);
      const leftArm = new THREE.Mesh(armGeo, mobMaterials.endermanBlack);
      leftArm.position.set(-0.25, 1.7, 0);
      const rightArm = new THREE.Mesh(armGeo, mobMaterials.endermanBlack);
      rightArm.position.set(0.25, 1.7, 0);
      group.add(leftArm, rightArm);
      instance.leftArm = leftArm;
      instance.rightArm = rightArm;

      const legGeo = new THREE.BoxGeometry(0.12, 1.5, 0.12);
      const leftLeg = new THREE.Mesh(legGeo, mobMaterials.endermanBlack);
      leftLeg.position.set(-0.1, 0.75, 0);
      const rightLeg = new THREE.Mesh(legGeo, mobMaterials.endermanBlack);
      rightLeg.position.set(0.1, 0.75, 0);
      group.add(leftLeg, rightLeg);
      instance.leftLeg = leftLeg;
      instance.rightLeg = rightLeg;
      break;
    }

    case 'ender_dragon': {
      const dragonBody = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.4, 3.5), mobMaterials.dragonDark);
      dragonBody.position.y = 0;
      group.add(dragonBody);

      const head = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.0, 1.6), mobMaterials.dragonDark);
      head.position.set(0, 0.5, 2.5);
      const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.15, 0.1), mobMaterials.dragonPurple);
      eyeL.position.set(-0.4, 0.2, 0.8);
      const eyeR = eyeL.clone();
      eyeR.position.x = 0.4;
      head.add(eyeL, eyeR);
      group.add(head);
      instance.head = head;

      const wingGeo = new THREE.BoxGeometry(3.5, 0.1, 2.0);
      const leftWing = new THREE.Mesh(wingGeo, mobMaterials.dragonDark);
      leftWing.position.set(-2.5, 0.5, 0);
      const rightWing = new THREE.Mesh(wingGeo, mobMaterials.dragonDark);
      rightWing.position.set(2.5, 0.5, 0);
      group.add(leftWing, rightWing);
      instance.leftWing = leftWing;
      instance.rightWing = rightWing;

      const tail = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 3.0), mobMaterials.dragonDark);
      tail.position.set(0, 0, -3.0);
      group.add(tail);
      break;
    }
  }

  return instance;
}

export function updateMobAI(
  instance: MobMeshInstance,
  delta: number,
  playerPos: { x: number; y: number; z: number },
  isCreativeOrSpectator: boolean,
  onPlayerDamage?: (dmg: number) => void
) {
  const entity = instance.entity;

  const speed = Math.sqrt(entity.vx * entity.vx + entity.vz * entity.vz);
  if (speed > 0.02) {
    entity.walkCycle += delta * 8;
    const swing = Math.sin(entity.walkCycle) * 0.45;
    if (instance.leftLeg) instance.leftLeg.rotation.x = swing;
    if (instance.rightLeg) instance.rightLeg.rotation.x = -swing;
    if (instance.leftHindLeg) instance.leftHindLeg.rotation.x = -swing;
    if (instance.rightHindLeg) instance.rightHindLeg.rotation.x = swing;
    if (instance.leftArm && entity.type !== 'zombie') instance.leftArm.rotation.x = -swing;
    if (instance.rightArm && entity.type !== 'zombie') instance.rightArm.rotation.x = swing;
  }

  if (entity.type === 'ender_dragon') {
    entity.walkCycle += delta * 4;
    const wingFlap = Math.sin(entity.walkCycle) * 0.5;
    if (instance.leftWing) instance.leftWing.rotation.z = wingFlap;
    if (instance.rightWing) instance.rightWing.rotation.z = -wingFlap;

    entity.yaw += delta * 0.4;
    entity.x = Math.sin(entity.yaw) * 16;
    entity.z = Math.cos(entity.yaw) * 16;
    entity.y = 26 + Math.sin(entity.walkCycle * 0.5) * 3;
    instance.group.position.set(entity.x, entity.y, entity.z);
    instance.group.rotation.y = entity.yaw + Math.PI / 2;
    return;
  }

  if (entity.type === 'iron_golem' && entity.attackCooldown > 0) {
    entity.attackCooldown -= delta;
    const armSwing = Math.sin(entity.attackCooldown * 12) * 1.2;
    if (instance.leftArm) instance.leftArm.rotation.x = armSwing;
    if (instance.rightArm) instance.rightArm.rotation.x = armSwing;
  }

  if (entity.type === 'creeper') {
    const distToPlayer = Math.hypot(playerPos.x - entity.x, playerPos.z - entity.z);
    if (!isCreativeOrSpectator && distToPlayer < 3.2) {
      if (!entity.exploding) {
        entity.exploding = true;
        entity.fuseTimer = 1.4;
        soundManager.playCreeperHiss();
      }
      entity.fuseTimer = (entity.fuseTimer ?? 1.4) - delta;
      instance.group.scale.set(
        1 + (1.4 - (entity.fuseTimer ?? 1.4)) * 0.25,
        1,
        1 + (1.4 - (entity.fuseTimer ?? 1.4)) * 0.25
      );
      if (entity.fuseTimer && entity.fuseTimer <= 0) {
        soundManager.playExplosion();
        onPlayerDamage?.(8);
        entity.health = 0;
      }
    } else {
      entity.exploding = false;
      entity.fuseTimer = 1.4;
      instance.group.scale.set(1, 1, 1);
    }
  }

  entity.stateTimer -= delta;
  if (entity.stateTimer <= 0) {
    entity.stateTimer = 2 + Math.random() * 3;
    const distToPlayer = Math.hypot(playerPos.x - entity.x, playerPos.z - entity.z);

    if (!entity.isPassive && !isCreativeOrSpectator && distToPlayer < 14) {
      const angle = Math.atan2(playerPos.x - entity.x, playerPos.z - entity.z);
      entity.yaw = angle;
      entity.vx = Math.sin(angle) * 1.5;
      entity.vz = Math.cos(angle) * 1.5;
    } else if (entity.type === 'iron_golem') {
      const angle = Math.random() * Math.PI * 2;
      entity.yaw = angle;
      entity.vx = Math.sin(angle) * 0.8;
      entity.vz = Math.cos(angle) * 0.8;
    } else {
      if (Math.random() < 0.6) {
        const angle = Math.random() * Math.PI * 2;
        entity.yaw = angle;
        entity.vx = Math.sin(angle) * 0.6;
        entity.vz = Math.cos(angle) * 0.6;
      } else {
        entity.vx = 0;
        entity.vz = 0;
      }
    }
  }

  entity.vy -= 9.8 * delta;
  entity.x += entity.vx * delta;
  entity.y += entity.vy * delta;
  entity.z += entity.vz * delta;

  if (entity.y < 14) {
    entity.y = 14;
    entity.vy = 0;
  }

  instance.group.position.set(entity.x, entity.y, entity.z);
  instance.group.rotation.y = entity.yaw;
}
