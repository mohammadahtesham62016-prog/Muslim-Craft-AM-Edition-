import { BlockType, ItemStack } from '../types/game';

export interface CraftingRecipe {
  id: string;
  name: string;
  category: 'tools' | 'blocks' | 'combat' | 'realm' | 'misc';
  width: number;
  height: number;
  pattern: (string | null)[];
  result: ItemStack;
}

export interface SmeltingRecipe {
  input: string;
  output: ItemStack;
  cookTime: number;
}

export const CRAFTING_RECIPES: CraftingRecipe[] = [
  {
    id: 'oak_planks',
    name: 'Oak Planks',
    category: 'blocks',
    width: 1,
    height: 1,
    pattern: ['oak_wood'],
    result: { id: 'oak_wood', isBlock: true, blockType: BlockType.OAK_WOOD, count: 4, maxStack: 64 },
  },
  {
    id: 'sticks',
    name: 'Sticks',
    category: 'misc',
    width: 1,
    height: 2,
    pattern: ['oak_wood', 'oak_wood'],
    result: { id: 'stick', isBlock: false, itemType: 'stick', count: 4, maxStack: 64 },
  },
  {
    id: 'crafting_table',
    name: 'Crafting Table',
    category: 'blocks',
    width: 2,
    height: 2,
    pattern: ['oak_wood', 'oak_wood', 'oak_wood', 'oak_wood'],
    result: { id: 'crafting_table', isBlock: true, blockType: BlockType.CRAFTING_TABLE, count: 1, maxStack: 64 },
  },
  {
    id: 'furnace',
    name: 'Furnace',
    category: 'blocks',
    width: 3,
    height: 3,
    pattern: [
      'cobblestone', 'cobblestone', 'cobblestone',
      'cobblestone', null, 'cobblestone',
      'cobblestone', 'cobblestone', 'cobblestone',
    ],
    result: { id: 'furnace', isBlock: true, blockType: BlockType.FURNACE, count: 1, maxStack: 64 },
  },
  {
    id: 'chest',
    name: 'Chest',
    category: 'blocks',
    width: 3,
    height: 3,
    pattern: [
      'oak_wood', 'oak_wood', 'oak_wood',
      'oak_wood', null, 'oak_wood',
      'oak_wood', 'oak_wood', 'oak_wood',
    ],
    result: { id: 'chest', isBlock: true, blockType: BlockType.CHEST, count: 1, maxStack: 64 },
  },
  {
    id: 'torch',
    name: 'Torch',
    category: 'misc',
    width: 1,
    height: 2,
    pattern: ['coal', 'stick'],
    result: { id: 'torch', isBlock: true, blockType: BlockType.TORCH, count: 4, maxStack: 64 },
  },
  {
    id: 'wooden_pickaxe',
    name: 'Wooden Pickaxe',
    category: 'tools',
    width: 3,
    height: 3,
    pattern: [
      'oak_wood', 'oak_wood', 'oak_wood',
      null, 'stick', null,
      null, 'stick', null,
    ],
    result: { id: 'wooden_pickaxe', isBlock: false, itemType: 'wooden_pickaxe', count: 1, maxStack: 1, durability: 60, maxDurability: 60 },
  },
  {
    id: 'stone_pickaxe',
    name: 'Stone Pickaxe',
    category: 'tools',
    width: 3,
    height: 3,
    pattern: [
      'cobblestone', 'cobblestone', 'cobblestone',
      null, 'stick', null,
      null, 'stick', null,
    ],
    result: { id: 'stone_pickaxe', isBlock: false, itemType: 'stone_pickaxe', count: 1, maxStack: 1, durability: 132, maxDurability: 132 },
  },
  {
    id: 'iron_pickaxe',
    name: 'Iron Pickaxe',
    category: 'tools',
    width: 3,
    height: 3,
    pattern: [
      'iron_ingot', 'iron_ingot', 'iron_ingot',
      null, 'stick', null,
      null, 'stick', null,
    ],
    result: { id: 'iron_pickaxe', isBlock: false, itemType: 'iron_pickaxe', count: 1, maxStack: 1, durability: 251, maxDurability: 251 },
  },
  {
    id: 'diamond_pickaxe',
    name: 'Diamond Pickaxe',
    category: 'tools',
    width: 3,
    height: 3,
    pattern: [
      'diamond', 'diamond', 'diamond',
      null, 'stick', null,
      null, 'stick', null,
    ],
    result: { id: 'diamond_pickaxe', isBlock: false, itemType: 'diamond_pickaxe', count: 1, maxStack: 1, durability: 1561, maxDurability: 1561 },
  },
  {
    id: 'wooden_axe',
    name: 'Wooden Axe',
    category: 'tools',
    width: 2,
    height: 3,
    pattern: [
      'oak_wood', 'oak_wood',
      'oak_wood', 'stick',
      null, 'stick',
    ],
    result: { id: 'wooden_axe', isBlock: false, itemType: 'wooden_axe', count: 1, maxStack: 1, durability: 60, maxDurability: 60 },
  },
  {
    id: 'stone_axe',
    name: 'Stone Axe',
    category: 'tools',
    width: 2,
    height: 3,
    pattern: [
      'cobblestone', 'cobblestone',
      'cobblestone', 'stick',
      null, 'stick',
    ],
    result: { id: 'stone_axe', isBlock: false, itemType: 'stone_axe', count: 1, maxStack: 1, durability: 132, maxDurability: 132 },
  },
  {
    id: 'iron_axe',
    name: 'Iron Axe',
    category: 'tools',
    width: 2,
    height: 3,
    pattern: [
      'iron_ingot', 'iron_ingot',
      'iron_ingot', 'stick',
      null, 'stick',
    ],
    result: { id: 'iron_axe', isBlock: false, itemType: 'iron_axe', count: 1, maxStack: 1, durability: 251, maxDurability: 251 },
  },
  {
    id: 'diamond_axe',
    name: 'Diamond Axe',
    category: 'tools',
    width: 2,
    height: 3,
    pattern: [
      'diamond', 'diamond',
      'diamond', 'stick',
      null, 'stick',
    ],
    result: { id: 'diamond_axe', isBlock: false, itemType: 'diamond_axe', count: 1, maxStack: 1, durability: 1561, maxDurability: 1561 },
  },
  {
    id: 'wooden_sword',
    name: 'Wooden Sword',
    category: 'combat',
    width: 1,
    height: 3,
    pattern: ['oak_wood', 'oak_wood', 'stick'],
    result: { id: 'wooden_sword', isBlock: false, itemType: 'wooden_sword', count: 1, maxStack: 1, durability: 60, maxDurability: 60 },
  },
  {
    id: 'stone_sword',
    name: 'Stone Sword',
    category: 'combat',
    width: 1,
    height: 3,
    pattern: ['cobblestone', 'cobblestone', 'stick'],
    result: { id: 'stone_sword', isBlock: false, itemType: 'stone_sword', count: 1, maxStack: 1, durability: 132, maxDurability: 132 },
  },
  {
    id: 'iron_sword',
    name: 'Iron Sword',
    category: 'combat',
    width: 1,
    height: 3,
    pattern: ['iron_ingot', 'iron_ingot', 'stick'],
    result: { id: 'iron_sword', isBlock: false, itemType: 'iron_sword', count: 1, maxStack: 1, durability: 251, maxDurability: 251 },
  },
  {
    id: 'diamond_sword',
    name: 'Diamond Sword',
    category: 'combat',
    width: 1,
    height: 3,
    pattern: ['diamond', 'diamond', 'stick'],
    result: { id: 'diamond_sword', isBlock: false, itemType: 'diamond_sword', count: 1, maxStack: 1, durability: 1561, maxDurability: 1561 },
  },
  {
    id: 'bow',
    name: 'Bow',
    category: 'combat',
    width: 3,
    height: 3,
    pattern: [
      'stick', 'string', null,
      'stick', null, 'string',
      'stick', 'string', null,
    ],
    result: { id: 'bow', isBlock: false, itemType: 'bow', count: 1, maxStack: 1, durability: 384, maxDurability: 384 },
  },
  {
    id: 'arrows',
    name: 'Arrows',
    category: 'combat',
    width: 1,
    height: 3,
    pattern: ['iron_ingot', 'stick', 'feather'],
    result: { id: 'arrow', isBlock: false, itemType: 'arrow', count: 4, maxStack: 64 },
  },
  {
    id: 'bread',
    name: 'Bread',
    category: 'misc',
    width: 3,
    height: 1,
    pattern: ['wheat', 'wheat', 'wheat'],
    result: { id: 'bread', isBlock: false, itemType: 'bread', count: 1, maxStack: 64 },
  },
  {
    id: 'diamond_block_craft',
    name: 'Diamond Block',
    category: 'blocks',
    width: 3,
    height: 3,
    pattern: [
      'diamond', 'diamond', 'diamond',
      'diamond', 'diamond', 'diamond',
      'diamond', 'diamond', 'diamond',
    ],
    result: { id: 'diamond_block', isBlock: true, blockType: BlockType.DIAMOND_BLOCK, count: 1, maxStack: 64 },
  },
  {
    id: 'turquoise_mosaic_craft',
    name: 'Turquoise Mosaic',
    category: 'realm',
    width: 2,
    height: 2,
    pattern: [
      'oasis_sandstone', 'diamond',
      'diamond', 'oasis_sandstone',
    ],
    result: { id: 'turquoise_mosaic', isBlock: true, blockType: BlockType.TURQUOISE_MOSAIC, count: 4, maxStack: 64 },
  },
  {
    id: 'golden_arabesque_craft',
    name: 'Golden Arabesque',
    category: 'realm',
    width: 2,
    height: 2,
    pattern: [
      'oasis_sandstone', 'gold_ingot',
      'gold_ingot', 'oasis_sandstone',
    ],
    result: { id: 'golden_arabesque', isBlock: true, blockType: BlockType.GOLDEN_ARABESQUE, count: 4, maxStack: 64 },
  },
  {
    id: 'white_marble_craft',
    name: 'White Marble',
    category: 'realm',
    width: 2,
    height: 2,
    pattern: [
      'oasis_sandstone', 'oasis_sandstone',
      'oasis_sandstone', 'oasis_sandstone',
    ],
    result: { id: 'white_marble', isBlock: true, blockType: BlockType.WHITE_MARBLE, count: 4, maxStack: 64 },
  },
];

export const SMELTING_RECIPES: SmeltingRecipe[] = [
  {
    input: 'iron_ore',
    output: { id: 'iron_ingot', isBlock: false, itemType: 'iron_ingot', count: 1, maxStack: 64 },
    cookTime: 5,
  },
  {
    input: 'gold_ore',
    output: { id: 'gold_ingot', isBlock: false, itemType: 'gold_ingot', count: 1, maxStack: 64 },
    cookTime: 5,
  },
  {
    input: 'sand',
    output: { id: 'glass', isBlock: true, blockType: BlockType.GLASS, count: 1, maxStack: 64 },
    cookTime: 4,
  },
  {
    input: 'cobblestone',
    output: { id: 'stone', isBlock: true, blockType: BlockType.STONE, count: 1, maxStack: 64 },
    cookTime: 4,
  },
  {
    input: 'raw_beef',
    output: { id: 'cooked_beef', isBlock: false, itemType: 'cooked_beef', count: 1, maxStack: 64 },
    cookTime: 4,
  },
];
