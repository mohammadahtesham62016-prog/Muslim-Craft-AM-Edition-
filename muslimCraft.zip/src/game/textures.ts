import * as THREE from 'three';
import { BlockType } from '../types/game';

const textureCache = new Map<string, THREE.CanvasTexture>();
const materialCache = new Map<BlockType, THREE.Material | THREE.Material[]>();

function createPixelTexture(
  drawFn: (ctx: CanvasRenderingContext2D) => void,
  name: string
): THREE.CanvasTexture {
  if (textureCache.has(name)) {
    return textureCache.get(name)!;
  }

  const canvas = document.createElement('canvas');
  canvas.width = 16;
  canvas.height = 16;
  const ctx = canvas.getContext('2d', { willReadFrequently: true })!;
  ctx.imageSmoothingEnabled = false;

  drawFn(ctx);

  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.generateMipmaps = false;

  textureCache.set(name, texture);
  return texture;
}

function fillNoise(
  ctx: CanvasRenderingContext2D,
  baseColor: [number, number, number],
  variation: number = 18,
  seed: number = 42
) {
  let s = seed;
  const rnd = () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };

  const imgData = ctx.createImageData(16, 16);
  for (let i = 0; i < 16 * 16; i++) {
    const delta = (rnd() - 0.5) * variation * 2;
    const r = Math.min(255, Math.max(0, Math.round(baseColor[0] + delta)));
    const g = Math.min(255, Math.max(0, Math.round(baseColor[1] + delta)));
    const b = Math.min(255, Math.max(0, Math.round(baseColor[2] + delta)));
    imgData.data[i * 4] = r;
    imgData.data[i * 4 + 1] = g;
    imgData.data[i * 4 + 2] = b;
    imgData.data[i * 4 + 3] = 255;
  }
  ctx.putImageData(imgData, 0, 0);
}

export function getBlockTextures() {
  const dirtTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [134, 96, 67], 20, 101);
  }, 'dirt');

  const grassTopTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [92, 168, 62], 22, 202);
  }, 'grass_top');

  const grassSideTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [134, 96, 67], 18, 101);
    const topRow = [
      [92, 168, 62],
      [80, 150, 52],
      [100, 180, 70],
    ];
    for (let x = 0; x < 16; x++) {
      const depth = 2 + (x % 3 === 0 ? 2 : x % 2 === 0 ? 1 : 0);
      for (let y = 0; y < depth; y++) {
        const c = topRow[(x + y) % 3];
        ctx.fillStyle = `rgb(${c[0]}, ${c[1]}, ${c[2]})`;
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }, 'grass_side');

  const stoneTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [125, 125, 125], 22, 303);
  }, 'stone');

  const cobblestoneTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [110, 110, 110], 18, 404);
    ctx.fillStyle = '#444444';
    ctx.fillRect(0, 7, 16, 1);
    ctx.fillRect(7, 0, 1, 7);
    ctx.fillRect(11, 8, 1, 8);
    ctx.fillRect(3, 8, 1, 8);
    ctx.fillStyle = '#d0d0d0';
    ctx.fillRect(1, 1, 2, 2);
    ctx.fillRect(9, 2, 2, 2);
    ctx.fillRect(4, 9, 2, 2);
    ctx.fillRect(12, 10, 2, 2);
  }, 'cobblestone');

  const woodSideTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [103, 77, 46], 14, 505);
    ctx.fillStyle = '#4a351d';
    ctx.fillRect(3, 0, 1, 16);
    ctx.fillRect(7, 0, 1, 16);
    ctx.fillRect(12, 0, 1, 16);
    ctx.fillStyle = '#7a5a36';
    ctx.fillRect(4, 0, 1, 16);
    ctx.fillRect(8, 0, 1, 16);
    ctx.fillRect(13, 0, 1, 16);
  }, 'wood_side');

  const woodTopTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [178, 143, 94], 10, 606);
    ctx.strokeStyle = '#4a351d';
    ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, 14, 14);
    ctx.strokeStyle = '#9e7b4e';
    ctx.lineWidth = 1;
    ctx.strokeRect(4, 4, 8, 8);
    ctx.fillStyle = '#775734';
    ctx.fillRect(7, 7, 2, 2);
  }, 'wood_top');

  const leavesTex = createPixelTexture((ctx) => {
    ctx.clearRect(0, 0, 16, 16);
    fillNoise(ctx, [58, 120, 34], 25, 707);
    for (let x = 0; x < 16; x += 2) {
      for (let y = 0; y < 16; y += 2) {
        if ((x * 7 + y * 13) % 5 === 0) {
          ctx.clearRect(x, y, 1, 1);
        }
      }
    }
  }, 'leaves');

  const sandTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [218, 203, 148], 15, 808);
  }, 'sand');

  const gravelTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [136, 128, 128], 30, 909);
    ctx.fillStyle = '#554f4f';
    ctx.fillRect(3, 4, 2, 2);
    ctx.fillRect(9, 11, 2, 2);
    ctx.fillRect(12, 2, 2, 2);
  }, 'gravel');

  const glassTex = createPixelTexture((ctx) => {
    ctx.clearRect(0, 0, 16, 16);
    ctx.fillStyle = 'rgba(235, 245, 255, 0.9)';
    ctx.strokeRect(0.5, 0.5, 15, 15);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.fillRect(3, 3, 2, 2);
    ctx.fillRect(5, 5, 2, 2);
    ctx.fillRect(10, 10, 2, 2);
    ctx.fillRect(12, 12, 2, 2);
  }, 'glass');

  const bricksTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [168, 72, 54], 16, 111);
    ctx.fillStyle = '#d5c4b8';
    ctx.fillRect(0, 4, 16, 1);
    ctx.fillRect(0, 9, 16, 1);
    ctx.fillRect(0, 14, 16, 1);
    ctx.fillRect(5, 0, 1, 4);
    ctx.fillRect(13, 0, 1, 4);
    ctx.fillRect(1, 5, 1, 4);
    ctx.fillRect(9, 5, 1, 4);
    ctx.fillRect(5, 10, 1, 4);
    ctx.fillRect(13, 10, 1, 4);
  }, 'bricks');

  const ironBlockTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [220, 220, 220], 12, 222);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1;
    ctx.strokeRect(1, 1, 14, 14);
    ctx.strokeStyle = '#aaaaaa';
    ctx.strokeRect(2, 2, 12, 12);
  }, 'iron_block');

  const goldBlockTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [245, 205, 45], 16, 333);
    ctx.strokeStyle = '#ffec8b';
    ctx.lineWidth = 1;
    ctx.strokeRect(1, 1, 14, 14);
    ctx.strokeStyle = '#b8860b';
    ctx.strokeRect(2, 2, 12, 12);
  }, 'gold_block');

  const diamondBlockTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [76, 230, 220], 20, 444);
    ctx.strokeStyle = '#d0ffff';
    ctx.lineWidth = 1;
    ctx.strokeRect(1, 1, 14, 14);
    ctx.strokeStyle = '#2b9890';
    ctx.strokeRect(2, 2, 12, 12);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(4, 4, 2, 2);
    ctx.fillRect(10, 10, 2, 2);
  }, 'diamond_block');

  const createOreTex = (oreColor: string, oreHighlight: string, name: string) => {
    return createPixelTexture((ctx) => {
      fillNoise(ctx, [125, 125, 125], 22, 303);
      const spots = [
        [3, 3], [4, 4], [3, 4], [10, 4], [11, 4], [10, 5],
        [5, 10], [6, 10], [6, 11], [12, 11], [11, 12], [12, 12],
      ];
      ctx.fillStyle = oreColor;
      for (const [x, y] of spots) {
        ctx.fillRect(x, y, 1, 1);
      }
      ctx.fillStyle = oreHighlight;
      ctx.fillRect(4, 3, 1, 1);
      ctx.fillRect(11, 4, 1, 1);
      ctx.fillRect(6, 10, 1, 1);
      ctx.fillRect(12, 11, 1, 1);
    }, name);
  };

  const coalOreTex = createOreTex('#222222', '#444444', 'coal_ore');
  const ironOreTex = createOreTex('#d8af93', '#f3d9c5', 'iron_ore');
  const goldOreTex = createOreTex('#fcee4b', '#fffadb', 'gold_ore');
  const diamondOreTex = createOreTex('#5bece0', '#e3ffff', 'diamond_ore');

  const craftingTopTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [178, 143, 94], 12, 555);
    ctx.strokeStyle = '#6a4724';
    ctx.lineWidth = 1;
    ctx.strokeRect(2, 2, 12, 12);
    ctx.beginPath();
    ctx.moveTo(6, 2); ctx.lineTo(6, 14);
    ctx.moveTo(10, 2); ctx.lineTo(10, 14);
    ctx.moveTo(2, 6); ctx.lineTo(14, 6);
    ctx.moveTo(2, 10); ctx.lineTo(14, 10);
    ctx.stroke();
  }, 'crafting_table_top');

  const craftingSideTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [150, 110, 70], 15, 666);
    ctx.fillStyle = '#3a2512';
    ctx.fillRect(3, 4, 4, 8);
    ctx.fillStyle = '#aaaaaa';
    ctx.fillRect(2, 3, 6, 2);
    ctx.fillStyle = '#8b5a2b';
    ctx.fillRect(10, 4, 2, 8);
    ctx.fillStyle = '#555555';
    ctx.fillRect(9, 3, 4, 3);
  }, 'crafting_table_side');

  const furnaceFrontTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [110, 110, 110], 18, 777);
    ctx.fillStyle = '#1c1c1c';
    ctx.fillRect(3, 6, 10, 7);
    ctx.fillStyle = '#ff6b00';
    ctx.fillRect(5, 10, 6, 2);
    ctx.fillStyle = '#ffdf00';
    ctx.fillRect(6, 11, 4, 1);
  }, 'furnace_front');

  const chestFrontTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [160, 115, 65], 14, 888);
    ctx.strokeStyle = '#3a2512';
    ctx.lineWidth = 1;
    ctx.strokeRect(1, 1, 14, 14);
    ctx.beginPath();
    ctx.moveTo(1, 6);
    ctx.lineTo(15, 6);
    ctx.stroke();
    ctx.fillStyle = '#e0e0e0';
    ctx.fillRect(7, 5, 2, 3);
    ctx.fillStyle = '#444444';
    ctx.fillRect(7, 6, 2, 1);
  }, 'chest_front');

  const waterTex = createPixelTexture((ctx) => {
    ctx.clearRect(0, 0, 16, 16);
    fillNoise(ctx, [38, 92, 215], 15, 999);
    ctx.fillStyle = 'rgba(120, 180, 255, 0.4)';
    ctx.fillRect(2, 3, 5, 1);
    ctx.fillRect(9, 7, 5, 1);
    ctx.fillRect(4, 11, 6, 1);
  }, 'water');

  const lavaTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [230, 80, 15], 25, 1111);
    ctx.fillStyle = '#ffc000';
    ctx.fillRect(2, 2, 3, 3);
    ctx.fillRect(10, 6, 4, 2);
    ctx.fillRect(5, 11, 4, 3);
    ctx.fillStyle = '#7a1005';
    ctx.fillRect(1, 8, 3, 2);
    ctx.fillRect(11, 12, 3, 2);
  }, 'lava');

  const netherrackTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [115, 35, 35], 28, 1212);
    ctx.fillStyle = '#450d0d';
    ctx.fillRect(3, 4, 2, 3);
    ctx.fillRect(9, 8, 3, 2);
  }, 'netherrack');

  const glowstoneTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [240, 195, 100], 35, 1313);
    ctx.fillStyle = '#fff4bd';
    ctx.fillRect(2, 2, 3, 3);
    ctx.fillRect(9, 8, 3, 3);
    ctx.fillStyle = '#b88128';
    ctx.fillRect(1, 12, 3, 2);
  }, 'glowstone');

  const netherBricksTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [52, 24, 30], 12, 1414);
    ctx.fillStyle = '#220b10';
    ctx.fillRect(0, 5, 16, 1);
    ctx.fillRect(0, 11, 16, 1);
    ctx.fillRect(7, 0, 1, 5);
    ctx.fillRect(11, 6, 1, 5);
  }, 'nether_bricks');

  const endStoneTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [226, 230, 172], 22, 1515);
    ctx.fillStyle = '#d1d89b';
    ctx.fillRect(4, 5, 3, 2);
    ctx.fillRect(10, 9, 2, 3);
  }, 'end_stone');

  const obsidianTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [22, 16, 36], 12, 1616);
    ctx.fillStyle = '#593282';
    ctx.fillRect(2, 3, 2, 2);
    ctx.fillRect(10, 8, 3, 2);
    ctx.fillRect(5, 12, 2, 2);
  }, 'obsidian');

  const purpurTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [169, 125, 169], 16, 1717);
    ctx.strokeStyle = '#855685';
    ctx.lineWidth = 1;
    ctx.strokeRect(1, 1, 14, 14);
  }, 'purpur');

  const oasisSandstoneTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [232, 196, 130], 14, 1818);
    ctx.fillStyle = '#ba8d42';
    ctx.fillRect(0, 7, 16, 1);
    ctx.fillRect(0, 15, 16, 1);
    ctx.fillRect(7, 3, 2, 2);
    ctx.fillRect(7, 11, 2, 2);
  }, 'oasis_sandstone');

  const palmWoodSideTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [130, 98, 65], 16, 1919);
    ctx.fillStyle = '#7a5530';
    for (let y = 0; y < 16; y += 4) {
      ctx.beginPath();
      ctx.moveTo(0, y + 2);
      ctx.lineTo(8, y);
      ctx.lineTo(16, y + 2);
      ctx.stroke();
    }
  }, 'palm_wood_side');

  const palmLeavesTex = createPixelTexture((ctx) => {
    ctx.clearRect(0, 0, 16, 16);
    fillNoise(ctx, [34, 142, 68], 22, 2020);
    ctx.fillStyle = '#5ce68b';
    ctx.fillRect(4, 4, 2, 8);
    ctx.fillRect(10, 4, 2, 8);
    ctx.clearRect(0, 0, 2, 2);
    ctx.clearRect(14, 0, 2, 2);
    ctx.clearRect(7, 14, 2, 2);
  }, 'palm_leaves');

  const turquoiseMosaicTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [30, 165, 180], 15, 2121);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(7, 2, 2, 12);
    ctx.fillRect(2, 7, 12, 2);
    ctx.fillStyle = '#ffd700';
    ctx.fillRect(6, 6, 4, 4);
    ctx.fillStyle = '#107584';
    ctx.fillRect(7, 7, 2, 2);
    ctx.strokeStyle = '#0e5560';
    ctx.strokeRect(0.5, 0.5, 15, 15);
  }, 'turquoise_mosaic');

  const goldenArabesqueTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [218, 165, 32], 18, 2222);
    ctx.strokeStyle = '#fff3a8';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(8, 1);
    ctx.lineTo(15, 8);
    ctx.lineTo(8, 15);
    ctx.lineTo(1, 8);
    ctx.closePath();
    ctx.stroke();
    ctx.fillStyle = '#8c6008';
    ctx.fillRect(7, 7, 2, 2);
  }, 'golden_arabesque');

  const lapisBrickTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [24, 60, 140], 16, 2323);
    ctx.fillStyle = '#102f74';
    ctx.fillRect(0, 5, 16, 1);
    ctx.fillRect(0, 11, 16, 1);
    ctx.fillRect(7, 0, 1, 5);
    ctx.fillRect(11, 6, 1, 5);
    ctx.fillStyle = '#ffd700';
    ctx.fillRect(4, 2, 1, 1);
    ctx.fillRect(12, 8, 1, 1);
  }, 'lapis_brick');

  const whiteMarbleTex = createPixelTexture((ctx) => {
    fillNoise(ctx, [245, 245, 248], 10, 2424);
    ctx.fillStyle = '#dcdde2';
    ctx.fillRect(3, 2, 3, 1);
    ctx.fillRect(6, 3, 4, 1);
    ctx.fillRect(10, 4, 3, 1);
    ctx.fillStyle = '#d6b876';
    ctx.fillRect(2, 9, 4, 1);
    ctx.fillRect(6, 10, 5, 1);
  }, 'white_marble');

  const torchTex = createPixelTexture((ctx) => {
    ctx.clearRect(0, 0, 16, 16);
    ctx.fillStyle = '#8b5a2b';
    ctx.fillRect(7, 6, 2, 10);
    ctx.fillStyle = '#333333';
    ctx.fillRect(7, 4, 2, 2);
    ctx.fillStyle = '#ff6a00';
    ctx.fillRect(6, 2, 4, 3);
    ctx.fillStyle = '#ffff55';
    ctx.fillRect(7, 1, 2, 3);
  }, 'torch');

  return {
    dirtTex, grassTopTex, grassSideTex, stoneTex, cobblestoneTex,
    woodSideTex, woodTopTex, leavesTex, sandTex, gravelTex, glassTex,
    bricksTex, ironBlockTex, goldBlockTex, diamondBlockTex,
    coalOreTex, ironOreTex, goldOreTex, diamondOreTex,
    craftingTopTex, craftingSideTex, furnaceFrontTex, chestFrontTex,
    waterTex, lavaTex, netherrackTex, glowstoneTex, netherBricksTex,
    endStoneTex, obsidianTex, purpurTex, oasisSandstoneTex,
    palmWoodSideTex, palmLeavesTex, turquoiseMosaicTex, goldenArabesqueTex,
    lapisBrickTex, whiteMarbleTex, torchTex,
  };
}

export function getBlockMaterial(blockType: BlockType): THREE.Material | THREE.Material[] {
  if (materialCache.has(blockType)) {
    return materialCache.get(blockType)!;
  }

  const tex = getBlockTextures();
  let mat: THREE.Material | THREE.Material[];

  switch (blockType) {
    case BlockType.GRASS: {
      const topMat = new THREE.MeshLambertMaterial({ map: tex.grassTopTex });
      const sideMat = new THREE.MeshLambertMaterial({ map: tex.grassSideTex });
      const bottomMat = new THREE.MeshLambertMaterial({ map: tex.dirtTex });
      mat = [sideMat, sideMat, topMat, bottomMat, sideMat, sideMat];
      break;
    }
    case BlockType.DIRT:
      mat = new THREE.MeshLambertMaterial({ map: tex.dirtTex });
      break;
    case BlockType.STONE:
      mat = new THREE.MeshLambertMaterial({ map: tex.stoneTex });
      break;
    case BlockType.COBBLESTONE:
      mat = new THREE.MeshLambertMaterial({ map: tex.cobblestoneTex });
      break;
    case BlockType.OAK_WOOD: {
      const sideMat = new THREE.MeshLambertMaterial({ map: tex.woodSideTex });
      const topMat = new THREE.MeshLambertMaterial({ map: tex.woodTopTex });
      mat = [sideMat, sideMat, topMat, topMat, sideMat, sideMat];
      break;
    }
    case BlockType.OAK_LEAVES:
      mat = new THREE.MeshLambertMaterial({
        map: tex.leavesTex,
        transparent: true,
        alphaTest: 0.3,
      });
      break;
    case BlockType.SAND:
      mat = new THREE.MeshLambertMaterial({ map: tex.sandTex });
      break;
    case BlockType.GRAVEL:
      mat = new THREE.MeshLambertMaterial({ map: tex.gravelTex });
      break;
    case BlockType.GLASS:
      mat = new THREE.MeshLambertMaterial({
        map: tex.glassTex,
        transparent: true,
        opacity: 0.85,
        alphaTest: 0.1,
      });
      break;
    case BlockType.BRICKS:
      mat = new THREE.MeshLambertMaterial({ map: tex.bricksTex });
      break;
    case BlockType.IRON_BLOCK:
      mat = new THREE.MeshLambertMaterial({ map: tex.ironBlockTex });
      break;
    case BlockType.GOLD_BLOCK:
      mat = new THREE.MeshLambertMaterial({ map: tex.goldBlockTex });
      break;
    case BlockType.DIAMOND_BLOCK:
      mat = new THREE.MeshLambertMaterial({ map: tex.diamondBlockTex });
      break;
    case BlockType.COAL_ORE:
      mat = new THREE.MeshLambertMaterial({ map: tex.coalOreTex });
      break;
    case BlockType.IRON_ORE:
      mat = new THREE.MeshLambertMaterial({ map: tex.ironOreTex });
      break;
    case BlockType.GOLD_ORE:
      mat = new THREE.MeshLambertMaterial({ map: tex.goldOreTex });
      break;
    case BlockType.DIAMOND_ORE:
      mat = new THREE.MeshLambertMaterial({ map: tex.diamondOreTex });
      break;
    case BlockType.CRAFTING_TABLE: {
      const top = new THREE.MeshLambertMaterial({ map: tex.craftingTopTex });
      const side = new THREE.MeshLambertMaterial({ map: tex.craftingSideTex });
      const bottom = new THREE.MeshLambertMaterial({ map: tex.woodSideTex });
      mat = [side, side, top, bottom, side, side];
      break;
    }
    case BlockType.FURNACE: {
      const front = new THREE.MeshLambertMaterial({ map: tex.furnaceFrontTex });
      const side = new THREE.MeshLambertMaterial({ map: tex.stoneTex });
      mat = [side, side, side, side, front, side];
      break;
    }
    case BlockType.CHEST: {
      const front = new THREE.MeshLambertMaterial({ map: tex.chestFrontTex });
      const wood = new THREE.MeshLambertMaterial({ map: tex.woodTopTex });
      mat = [wood, wood, wood, wood, front, wood];
      break;
    }
    case BlockType.TORCH:
      mat = new THREE.MeshLambertMaterial({
        map: tex.torchTex,
        transparent: true,
        alphaTest: 0.2,
      });
      break;
    case BlockType.WATER:
      mat = new THREE.MeshLambertMaterial({
        map: tex.waterTex,
        transparent: true,
        opacity: 0.65,
      });
      break;
    case BlockType.LAVA:
      mat = new THREE.MeshBasicMaterial({ map: tex.lavaTex });
      break;
    case BlockType.NETHERRACK:
      mat = new THREE.MeshLambertMaterial({ map: tex.netherrackTex });
      break;
    case BlockType.GLOWSTONE:
      mat = new THREE.MeshBasicMaterial({ map: tex.glowstoneTex });
      break;
    case BlockType.NETHER_BRICKS:
      mat = new THREE.MeshLambertMaterial({ map: tex.netherBricksTex });
      break;
    case BlockType.END_STONE:
      mat = new THREE.MeshLambertMaterial({ map: tex.endStoneTex });
      break;
    case BlockType.OBSIDIAN:
      mat = new THREE.MeshLambertMaterial({ map: tex.obsidianTex });
      break;
    case BlockType.PURPUR:
      mat = new THREE.MeshLambertMaterial({ map: tex.purpurTex });
      break;
    case BlockType.OASIS_SANDSTONE:
      mat = new THREE.MeshLambertMaterial({ map: tex.oasisSandstoneTex });
      break;
    case BlockType.PALM_WOOD: {
      const sideMat = new THREE.MeshLambertMaterial({ map: tex.palmWoodSideTex });
      const topMat = new THREE.MeshLambertMaterial({ map: tex.woodTopTex });
      mat = [sideMat, sideMat, topMat, topMat, sideMat, sideMat];
      break;
    }
    case BlockType.PALM_LEAVES:
      mat = new THREE.MeshLambertMaterial({
        map: tex.palmLeavesTex,
        transparent: true,
        alphaTest: 0.3,
      });
      break;
    case BlockType.TURQUOISE_MOSAIC:
      mat = new THREE.MeshLambertMaterial({ map: tex.turquoiseMosaicTex });
      break;
    case BlockType.GOLDEN_ARABESQUE:
      mat = new THREE.MeshLambertMaterial({ map: tex.goldenArabesqueTex });
      break;
    case BlockType.LAPIS_BRICK:
      mat = new THREE.MeshLambertMaterial({ map: tex.lapisBrickTex });
      break;
    case BlockType.WHITE_MARBLE:
      mat = new THREE.MeshLambertMaterial({ map: tex.whiteMarbleTex });
      break;
    case BlockType.OASIS_WATER:
      mat = new THREE.MeshLambertMaterial({
        map: tex.waterTex,
        color: new THREE.Color('#38d9a9'),
        transparent: true,
        opacity: 0.7,
      });
      break;
    default:
      mat = new THREE.MeshLambertMaterial({ color: 0x888888 });
  }

  materialCache.set(blockType, mat);
  return mat;
}

export function getBlockName(blockType: BlockType): string {
  switch (blockType) {
    case BlockType.GRASS: return 'Grass Block';
    case BlockType.DIRT: return 'Dirt';
    case BlockType.STONE: return 'Stone';
    case BlockType.COBBLESTONE: return 'Cobblestone';
    case BlockType.OAK_WOOD: return 'Oak Wood';
    case BlockType.OAK_LEAVES: return 'Oak Leaves';
    case BlockType.SAND: return 'Sand';
    case BlockType.GRAVEL: return 'Gravel';
    case BlockType.GLASS: return 'Glass';
    case BlockType.BRICKS: return 'Bricks';
    case BlockType.IRON_BLOCK: return 'Iron Block';
    case BlockType.GOLD_BLOCK: return 'Gold Block';
    case BlockType.DIAMOND_BLOCK: return 'Diamond Block';
    case BlockType.CRAFTING_TABLE: return 'Crafting Table';
    case BlockType.FURNACE: return 'Furnace';
    case BlockType.CHEST: return 'Chest';
    case BlockType.TORCH: return 'Torch';
    case BlockType.WATER: return 'Water';
    case BlockType.LAVA: return 'Lava';
    case BlockType.COAL_ORE: return 'Coal Ore';
    case BlockType.IRON_ORE: return 'Iron Ore';
    case BlockType.GOLD_ORE: return 'Gold Ore';
    case BlockType.DIAMOND_ORE: return 'Diamond Ore';
    case BlockType.NETHERRACK: return 'Netherrack';
    case BlockType.GLOWSTONE: return 'Glowstone';
    case BlockType.NETHER_BRICKS: return 'Nether Bricks';
    case BlockType.END_STONE: return 'End Stone';
    case BlockType.OBSIDIAN: return 'Obsidian';
    case BlockType.PURPUR: return 'Purpur';
    case BlockType.OASIS_SANDSTONE: return 'Oasis Sandstone';
    case BlockType.PALM_WOOD: return 'Palm Wood';
    case BlockType.PALM_LEAVES: return 'Palm Leaves';
    case BlockType.TURQUOISE_MOSAIC: return 'Turquoise Mosaic';
    case BlockType.GOLDEN_ARABESQUE: return 'Golden Arabesque';
    case BlockType.LAPIS_BRICK: return 'Lapis Mosque Brick';
    case BlockType.WHITE_MARBLE: return 'White Marble';
    case BlockType.OASIS_WATER: return 'Oasis Water';
    default: return 'Block';
  }
}
