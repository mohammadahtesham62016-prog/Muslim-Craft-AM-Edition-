import { BlockType, Dimension, ItemStack } from '../types/game';

export class SeededPRNG {
  private s: number;

  constructor(seedStr: string | number) {
    if (typeof seedStr === 'number') {
      this.s = seedStr;
    } else {
      let hash = 0;
      for (let i = 0; i < seedStr.length; i++) {
        hash = (hash << 5) - hash + seedStr.charCodeAt(i);
        hash |= 0;
      }
      this.s = Math.abs(hash) || 786;
    }
  }

  public next(): number {
    this.s = (this.s * 1664525 + 1013904223) % 4294967296;
    return this.s / 4294967296;
  }

  public range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  public int(min: number, max: number): number {
    return Math.floor(this.range(min, max + 1));
  }
}

export class SimpleNoise {
  private p: number[] = [];

  constructor(seed: number = 786) {
    const prng = new SeededPRNG(seed);
    const permutation = [];
    for (let i = 0; i < 256; i++) permutation.push(i);
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(prng.next() * (i + 1));
      [permutation[i], permutation[j]] = [permutation[j], permutation[i]];
    }
    this.p = new Array(512);
    for (let i = 0; i < 512; i++) {
      this.p[i] = permutation[i & 255];
    }
  }

  private fade(t: number): number {
    return t * t * t * (t * (t * 6 - 15) + 10);
  }

  private lerp(t: number, a: number, b: number): number {
    return a + t * (b - a);
  }

  private grad(hash: number, x: number, y: number): number {
    const h = hash & 7;
    const u = h < 4 ? x : y;
    const v = h < 4 ? y : x;
    return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
  }

  public noise2D(x: number, y: number): number {
    const X = Math.floor(x) & 255;
    const Y = Math.floor(y) & 255;
    const xf = x - Math.floor(x);
    const yf = y - Math.floor(y);

    const u = this.fade(xf);
    const v = this.fade(yf);

    const aa = this.p[this.p[X] + Y];
    const ab = this.p[this.p[X] + Y + 1];
    const ba = this.p[this.p[X + 1] + Y];
    const bb = this.p[this.p[X + 1] + Y + 1];

    const x1 = this.lerp(u, this.grad(aa, xf, yf), this.grad(ba, xf - 1, yf));
    const x2 = this.lerp(u, this.grad(ab, xf, yf - 1), this.grad(bb, xf - 1, yf - 1));

    return this.lerp(v, x1, x2);
  }

  public octave2D(x: number, y: number, octaves: number = 3, persistence: number = 0.5): number {
    let total = 0;
    let frequency = 1;
    let amplitude = 1;
    let maxValue = 0;
    for (let i = 0; i < octaves; i++) {
      total += this.noise2D(x * frequency, y * frequency) * amplitude;
      maxValue += amplitude;
      amplitude *= persistence;
      frequency *= 2;
    }
    return total / maxValue;
  }
}

export const CHUNK_SIZE = 16;
export const WORLD_HEIGHT = 48;

export interface WorldGenResult {
  blocks: Map<string, BlockType>;
  chests: Record<string, (ItemStack | null)[]>;
  initialMobs: {
    type:
      | 'villager'
      | 'iron_golem'
      | 'cow'
      | 'sheep'
      | 'pig'
      | 'chicken'
      | 'horse'
      | 'zombie'
      | 'skeleton'
      | 'creeper'
      | 'spider'
      | 'enderman'
      | 'ender_dragon';
    x: number;
    y: number;
    z: number;
  }[];
  spawnPos: { x: number; y: number; z: number };
}

export class WorldGenerator {
  private seed: string;
  private seedNum: number;
  private noise: SimpleNoise;
  private prng: SeededPRNG;

  constructor(seed: string) {
    this.seed = seed;
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
      hash = (hash << 5) - hash + seed.charCodeAt(i);
      hash |= 0;
    }
    this.seedNum = Math.abs(hash) || 786;
    this.noise = new SimpleNoise(this.seedNum);
    this.prng = new SeededPRNG(this.seedNum);
  }

  public isSpecialSeed(): boolean {
    return this.seed.trim() === '0786' || this.seed.trim() === '786';
  }

  public generateInitialWorld(dimension: Dimension): WorldGenResult {
    const blocks = new Map<string, BlockType>();
    const chests: Record<string, (ItemStack | null)[]> = {};
    const initialMobs: WorldGenResult['initialMobs'] = [];

    const setBlock = (x: number, y: number, z: number, type: BlockType) => {
      if (y < 0 || y >= WORLD_HEIGHT) return;
      blocks.set(`${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`, type);
    };

    let spawnX = 0;
    let spawnZ = 0;
    let spawnY = 18;

    const is0786 = this.isSpecialSeed();

    if (dimension === 'overworld') {
      const radius = is0786 ? 48 : 40;
      for (let x = -radius; x <= radius; x++) {
        for (let z = -radius; z <= radius; z++) {
          const n = this.noise.octave2D(x * 0.04, z * 0.04, 3, 0.5);
          let height = Math.floor(15 + n * 8);

          if (is0786 && Math.abs(x) < 32 && Math.abs(z) < 32) {
            height = 14;
          }

          for (let y = 0; y <= height; y++) {
            if (y === 0) {
              setBlock(x, y, z, BlockType.OBSIDIAN);
            } else if (y < height - 3) {
              const oreRand = Math.sin(x * 12.9898 + y * 78.233 + z * 45.164) * 43758.5453;
              const frac = oreRand - Math.floor(oreRand);
              if (frac < 0.015 && y < 10) {
                setBlock(x, y, z, BlockType.DIAMOND_ORE);
              } else if (frac < 0.04 && y < 14) {
                setBlock(x, y, z, BlockType.GOLD_ORE);
              } else if (frac < 0.08) {
                setBlock(x, y, z, BlockType.IRON_ORE);
              } else if (frac < 0.14) {
                setBlock(x, y, z, BlockType.COAL_ORE);
              } else {
                setBlock(x, y, z, BlockType.STONE);
              }
            } else if (y < height) {
              setBlock(x, y, z, BlockType.DIRT);
            } else {
              if (height < 12) {
                setBlock(x, y, z, BlockType.SAND);
              } else {
                setBlock(x, y, z, BlockType.GRASS);
              }
            }
          }

          if (height < 12) {
            for (let y = height + 1; y <= 12; y++) {
              setBlock(x, y, z, BlockType.WATER);
            }
          }

          if ((!is0786 || Math.abs(x) > 34 || Math.abs(z) > 34) && height >= 13) {
            const treeChance = (Math.sin(x * 5.1 + z * 3.7) + 1) * 0.5;
            if (treeChance > 0.88 && x % 4 === 0 && z % 4 === 0) {
              this.generateTree(x, height + 1, z, setBlock);
            }
          }
        }
      }

      if (is0786) {
        spawnX = 0;
        spawnZ = 4;
        spawnY = 15;

        this.generateTownSquare(0, 14, 0, setBlock);

        for (let r = -28; r <= 28; r++) {
          setBlock(r, 14, 0, BlockType.COBBLESTONE);
          setBlock(r, 14, 1, BlockType.COBBLESTONE);
          setBlock(0, 14, r, BlockType.COBBLESTONE);
          setBlock(1, 14, r, BlockType.COBBLESTONE);
        }

        // EXACTLY 5 BLACKSMITH BUILDINGS FOR SEED 0786
        this.generateBlacksmith(-18, 14, -14, setBlock, chests, 1);
        this.generateBlacksmith(18, 14, -14, setBlock, chests, 2);
        this.generateBlacksmith(-18, 14, 18, setBlock, chests, 3);
        this.generateBlacksmith(18, 14, 18, setBlock, chests, 4);
        this.generateBlacksmith(0, 14, -26, setBlock, chests, 5);

        this.generateHouse(-10, 14, -8, setBlock);
        this.generateHouse(10, 14, -8, setBlock);
        this.generateHouse(-10, 14, 10, setBlock);
        this.generateHouse(10, 14, 10, setBlock);
        this.generateHouse(-24, 14, 2, setBlock);
        this.generateHouse(24, 14, 2, setBlock);

        this.generateFarm(-14, 14, -24, setBlock);
        this.generateFarm(14, 14, -24, setBlock);
        this.generateFarm(-14, 14, 26, setBlock);

        initialMobs.push({ type: 'iron_golem', x: 4, y: 15, z: 2 });
        initialMobs.push({ type: 'iron_golem', x: -4, y: 15, z: -4 });

        for (let i = 0; i < 8; i++) {
          const vx = (i % 4) * 8 - 12;
          const vz = Math.floor(i / 4) * 12 - 6;
          initialMobs.push({ type: 'villager', x: vx, y: 15, z: vz });
        }
      } else {
        spawnX = 0;
        spawnZ = 0;
        spawnY = 16;
        this.generateBlacksmith(12, 14, 12, setBlock, chests, 1);
        this.generateHouse(-12, 14, 12, setBlock);
        initialMobs.push({ type: 'villager', x: -10, y: 15, z: 12 });
        initialMobs.push({ type: 'iron_golem', x: 2, y: 15, z: 4 });
      }

      const animalTypes: ('cow' | 'sheep' | 'pig' | 'chicken' | 'horse')[] = [
        'cow', 'sheep', 'pig', 'chicken', 'horse',
      ];
      for (let i = 0; i < 12; i++) {
        const ax = Math.floor(Math.sin(i * 1.7) * 28);
        const az = Math.floor(Math.cos(i * 2.3) * 28);
        const aType = animalTypes[i % animalTypes.length];
        initialMobs.push({ type: aType, x: ax, y: 16, z: az });
      }

    } else if (dimension === 'nether') {
      spawnX = 0;
      spawnZ = 0;
      spawnY = 15;
      const radius = 36;
      for (let x = -radius; x <= radius; x++) {
        for (let z = -radius; z <= radius; z++) {
          const n = this.noise.octave2D(x * 0.05, z * 0.05, 2, 0.5);
          const floorH = Math.floor(8 + n * 4);
          for (let y = 0; y <= floorH; y++) {
            setBlock(x, y, z, BlockType.NETHERRACK);
          }
          if (floorH < 6) {
            for (let y = floorH + 1; y <= 6; y++) {
              setBlock(x, y, z, BlockType.LAVA);
            }
          }
          for (let y = 28; y <= 32; y++) {
            setBlock(x, y, z, BlockType.NETHERRACK);
          }
          if (x % 7 === 0 && z % 7 === 0) {
            setBlock(x, 27, z, BlockType.GLOWSTONE);
            setBlock(x, 26, z, BlockType.GLOWSTONE);
          }
        }
      }

      for (let x = -20; x <= 20; x++) {
        for (let z = -3; z <= 3; z++) {
          setBlock(x, 14, z, BlockType.NETHER_BRICKS);
          if (Math.abs(z) === 3) {
            setBlock(x, 15, z, BlockType.NETHER_BRICKS);
          }
        }
      }

      for (let i = 0; i < 6; i++) {
        initialMobs.push({ type: 'zombie', x: i * 6 - 15, y: 15, z: 0 });
      }

    } else if (dimension === 'the_end') {
      spawnX = 0;
      spawnZ = 0;
      spawnY = 16;

      const islandRadius = 26;
      for (let x = -islandRadius; x <= islandRadius; x++) {
        for (let z = -islandRadius; z <= islandRadius; z++) {
          const dist = Math.sqrt(x * x + z * z);
          if (dist <= islandRadius) {
            const depth = Math.floor((1 - dist / islandRadius) * 6);
            for (let y = 14 - depth; y <= 15; y++) {
              setBlock(x, y, z, BlockType.END_STONE);
            }
          }
        }
      }

      const pillarPositions = [
        [14, 0], [-14, 0], [0, 14], [0, -14],
        [10, 10], [-10, 10], [10, -10], [-10, -10],
      ];
      pillarPositions.forEach(([px, pz]) => {
        const pillarH = 24 + Math.abs(px % 5);
        for (let y = 15; y <= pillarH; y++) {
          for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
              setBlock(px + dx, y, pz + dz, BlockType.OBSIDIAN);
            }
          }
        }
        setBlock(px, pillarH + 1, pz, BlockType.GLOWSTONE);
      });

      for (let i = 0; i < 6; i++) {
        const ex = Math.sin(i * 1.2) * 12;
        const ez = Math.cos(i * 1.2) * 12;
        initialMobs.push({ type: 'enderman', x: ex, y: 16, z: ez });
      }

      initialMobs.push({ type: 'ender_dragon', x: 0, y: 28, z: 0 });

    } else if (dimension === 'muslim_realm') {
      spawnX = 0;
      spawnZ = 6;
      spawnY = 15;

      const radius = 40;
      for (let x = -radius; x <= radius; x++) {
        for (let z = -radius; z <= radius; z++) {
          const distFromCenter = Math.sqrt(x * x + z * z);
          const n = this.noise.octave2D(x * 0.03, z * 0.03, 3, 0.4);
          let height = Math.floor(14 + n * 6);

          if (distFromCenter < 12) {
            height = 11;
          }

          for (let y = 0; y <= height; y++) {
            if (y === 0) {
              setBlock(x, y, z, BlockType.OBSIDIAN);
            } else if (y < height - 2) {
              setBlock(x, y, z, BlockType.OASIS_SANDSTONE);
            } else {
              setBlock(x, y, z, BlockType.SAND);
            }
          }

          if (distFromCenter < 12 && height <= 11) {
            setBlock(x, 12, z, BlockType.OASIS_WATER);
          }

          if (distFromCenter >= 12 && distFromCenter < 18) {
            setBlock(x, height, z, BlockType.GRASS);
          }

          if (distFromCenter >= 13 && distFromCenter <= 18 && (x + z) % 5 === 0 && x % 2 === 0) {
            this.generatePalmTree(x, height + 1, z, setBlock);
          }
        }
      }

      this.generateAncientMuslimRealmCity(0, 14, 22, setBlock, chests);

      for (let i = 0; i < 5; i++) {
        initialMobs.push({ type: 'villager', x: -6 + i * 3, y: 15, z: 18 });
      }
      initialMobs.push({ type: 'horse', x: -8, y: 15, z: 8 });
      initialMobs.push({ type: 'horse', x: 8, y: 15, z: 8 });
      initialMobs.push({ type: 'iron_golem', x: 0, y: 15, z: 16 });
    }

    return {
      blocks,
      chests,
      initialMobs,
      spawnPos: { x: spawnX, y: spawnY, z: spawnZ },
    };
  }

  private generateTree(
    bx: number,
    by: number,
    bz: number,
    setBlock: (x: number, y: number, z: number, t: BlockType) => void
  ) {
    const trunkHeight = 4 + Math.floor(Math.random() * 2);
    for (let y = 0; y < trunkHeight; y++) {
      setBlock(bx, by + y, bz, BlockType.OAK_WOOD);
    }
    const leafStart = by + trunkHeight - 2;
    for (let ly = leafStart; ly <= by + trunkHeight + 1; ly++) {
      const radius = ly >= by + trunkHeight ? 1 : 2;
      for (let lx = -radius; lx <= radius; lx++) {
        for (let lz = -radius; lz <= radius; lz++) {
          if (Math.abs(lx) === radius && Math.abs(lz) === radius && ly === by + trunkHeight + 1) {
            continue;
          }
          if (lx === 0 && lz === 0 && ly < by + trunkHeight) continue;
          setBlock(bx + lx, ly, bz + lz, BlockType.OAK_LEAVES);
        }
      }
    }
  }

  private generatePalmTree(
    bx: number,
    by: number,
    bz: number,
    setBlock: (x: number, y: number, z: number, t: BlockType) => void
  ) {
    const trunkHeight = 5 + Math.floor(Math.random() * 2);
    for (let y = 0; y < trunkHeight; y++) {
      const xOff = Math.floor(y / 4);
      setBlock(bx + xOff, by + y, bz, BlockType.PALM_WOOD);
    }
    const topY = by + trunkHeight;
    const topX = bx + Math.floor((trunkHeight - 1) / 4);
    const directions = [
      [1, 0], [-1, 0], [0, 1], [0, -1],
      [1, 1], [-1, 1], [1, -1], [-1, -1],
    ];
    directions.forEach(([dx, dz]) => {
      setBlock(topX + dx, topY, bz + dz, BlockType.PALM_LEAVES);
      setBlock(topX + dx * 2, topY, bz + dz * 2, BlockType.PALM_LEAVES);
      setBlock(topX + dx * 3, topY - 1, bz + dz * 3, BlockType.PALM_LEAVES);
    });
    setBlock(topX, topY + 1, bz, BlockType.PALM_LEAVES);
  }

  private generateTownSquare(
    cx: number,
    cy: number,
    cz: number,
    setBlock: (x: number, y: number, z: number, t: BlockType) => void
  ) {
    for (let x = -4; x <= 4; x++) {
      for (let z = -4; z <= 4; z++) {
        setBlock(cx + x, cy, cz + z, BlockType.COBBLESTONE);
      }
    }
    for (let x = -1; x <= 1; x++) {
      for (let z = -1; z <= 1; z++) {
        if (x === 0 && z === 0) {
          setBlock(cx, cy, cz, BlockType.WATER);
        } else {
          setBlock(cx + x, cy + 1, cz + z, BlockType.COBBLESTONE);
        }
      }
    }
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([dx, dz]) => {
      setBlock(cx + dx, cy + 2, cz + dz, BlockType.OAK_WOOD);
    });
    for (let x = -1; x <= 1; x++) {
      for (let z = -1; z <= 1; z++) {
        setBlock(cx + x, cy + 3, cz + z, BlockType.OAK_WOOD);
      }
    }
  }

  private generateFarm(
    fx: number,
    fy: number,
    fz: number,
    setBlock: (x: number, y: number, z: number, t: BlockType) => void
  ) {
    for (let x = 0; x < 6; x++) {
      for (let z = 0; z < 8; z++) {
        if (x === 0 || x === 5 || z === 0 || z === 7) {
          setBlock(fx + x, fy + 1, fz + z, BlockType.OAK_WOOD);
        } else if (x === 3) {
          setBlock(fx + x, fy, fz + z, BlockType.WATER);
        } else {
          setBlock(fx + x, fy, fz + z, BlockType.DIRT);
          setBlock(fx + x, fy + 1, fz + z, BlockType.GRASS);
        }
      }
    }
  }

  private generateHouse(
    hx: number,
    hy: number,
    hz: number,
    setBlock: (x: number, y: number, z: number, t: BlockType) => void
  ) {
    const w = 5;
    const d = 5;
    const h = 4;
    for (let x = 0; x < w; x++) {
      for (let z = 0; z < d; z++) {
        setBlock(hx + x, hy, hz + z, BlockType.COBBLESTONE);
      }
    }
    for (let y = 1; y <= h; y++) {
      for (let x = 0; x < w; x++) {
        for (let z = 0; z < d; z++) {
          const isEdge = x === 0 || x === w - 1 || z === 0 || z === d - 1;
          const isCorner = (x === 0 || x === w - 1) && (z === 0 || z === d - 1);
          if (isCorner) {
            setBlock(hx + x, hy + y, hz + z, BlockType.OAK_WOOD);
          } else if (isEdge) {
            if (z === 0 && x === 2 && (y === 1 || y === 2)) {
              setBlock(hx + x, hy + y, hz + z, BlockType.AIR);
            } else if (y === 2 && (x === 2 || z === 2)) {
              setBlock(hx + x, hy + y, hz + z, BlockType.GLASS);
            } else {
              setBlock(hx + x, hy + y, hz + z, BlockType.OAK_WOOD);
            }
          } else {
            setBlock(hx + x, hy + y, hz + z, BlockType.AIR);
          }
        }
      }
    }
    for (let x = -1; x <= w; x++) {
      for (let z = -1; z <= d; z++) {
        setBlock(hx + x, hy + h + 1, hz + z, BlockType.OAK_WOOD);
      }
    }
    setBlock(hx + 2, hy + 3, hz + 2, BlockType.TORCH);
  }

  public generateBlacksmith(
    bx: number,
    by: number,
    bz: number,
    setBlock: (x: number, y: number, z: number, t: BlockType) => void,
    chests: Record<string, (ItemStack | null)[]>,
    index: number
  ) {
    const width = 7;
    const depth = 8;
    const height = 4;

    for (let x = 0; x < width; x++) {
      for (let z = 0; z < depth; z++) {
        setBlock(bx + x, by, bz + z, BlockType.COBBLESTONE);
      }
    }

    for (let y = 1; y <= height; y++) {
      for (let x = 0; x < width; x++) {
        for (let z = 0; z < depth; z++) {
          const isCorner = (x === 0 || x === width - 1) && (z === 0 || z === depth - 1);
          const isWall = x === 0 || x === width - 1 || z === depth - 1;

          if (isCorner) {
            setBlock(bx + x, by + y, bz + z, BlockType.OAK_WOOD);
          } else if (isWall) {
            if (y === 2 && (x === 0 || x === width - 1) && z === 4) {
              setBlock(bx + x, by + y, bz + z, BlockType.GLASS);
            } else {
              setBlock(bx + x, by + y, bz + z, BlockType.COBBLESTONE);
            }
          } else {
            setBlock(bx + x, by + y, bz + z, BlockType.AIR);
          }
        }
      }
    }

    setBlock(bx + 1, by + 1, bz + 1, BlockType.COBBLESTONE);
    setBlock(bx + 2, by + 1, bz + 1, BlockType.COBBLESTONE);
    setBlock(bx + 1, by + 1, bz + 2, BlockType.COBBLESTONE);
    setBlock(bx + 2, by + 1, bz + 2, BlockType.LAVA);

    setBlock(bx + 3, by + 1, bz + 1, BlockType.FURNACE);
    setBlock(bx + 4, by + 1, bz + 1, BlockType.FURNACE);

    setBlock(bx + 1, by + 1, bz + 4, BlockType.STONE);
    setBlock(bx + 1, by + 1, bz + 5, BlockType.STONE);

    setBlock(bx + 5, by + 1, bz + 6, BlockType.CRAFTING_TABLE);

    const chestX = bx + 5;
    const chestY = by + 1;
    const chestZ = bz + 5;
    setBlock(chestX, chestY, chestZ, BlockType.CHEST);

    for (let x = 0; x < width; x++) {
      for (let z = 0; z < depth; z++) {
        setBlock(bx + x, by + height, bz + z, BlockType.STONE);
      }
    }

    // EXACTLY 10 DIAMONDS IN EACH OF THE 5 BLACKSMITH CHESTS FOR SEED 0786!
    const chestKey = `${chestX},${chestY},${chestZ}`;
    const chestSlots: (ItemStack | null)[] = new Array(27).fill(null);

    chestSlots[0] = {
      id: 'diamond',
      isBlock: false,
      itemType: 'diamond',
      count: 10,
      maxStack: 64,
    };
    chestSlots[1] = {
      id: 'iron_ingot',
      isBlock: false,
      itemType: 'iron_ingot',
      count: 5 + (index % 3),
      maxStack: 64,
    };
    chestSlots[2] = {
      id: 'bread',
      isBlock: false,
      itemType: 'bread',
      count: 6,
      maxStack: 64,
    };
    chestSlots[3] = {
      id: 'iron_pickaxe',
      isBlock: false,
      itemType: 'iron_pickaxe',
      count: 1,
      maxStack: 1,
      durability: 251,
      maxDurability: 251,
    };
    chestSlots[4] = {
      id: 'obsidian',
      isBlock: true,
      blockType: BlockType.OBSIDIAN,
      count: 4,
      maxStack: 64,
    };

    chests[chestKey] = chestSlots;
  }

  private generateAncientMuslimRealmCity(
    cx: number,
    cy: number,
    cz: number,
    setBlock: (x: number, y: number, z: number, t: BlockType) => void,
    chests: Record<string, (ItemStack | null)[]>
  ) {
    const cityW = 20;
    const cityD = 20;

    for (let x = -cityW / 2; x <= cityW / 2; x++) {
      for (let z = -cityD / 2; z <= cityD / 2; z++) {
        if ((x + z) % 4 === 0) {
          setBlock(cx + x, cy, cz + z, BlockType.TURQUOISE_MOSAIC);
        } else if ((x * z) % 3 === 0) {
          setBlock(cx + x, cy, cz + z, BlockType.GOLDEN_ARABESQUE);
        } else {
          setBlock(cx + x, cy, cz + z, BlockType.WHITE_MARBLE);
        }
      }
    }

    const pillarPositions = [
      [-8, -8], [-8, 0], [-8, 8],
      [8, -8], [8, 0], [8, 8],
      [-4, -8], [0, -8], [4, -8],
      [-4, 8], [0, 8], [4, 8],
    ];
    pillarPositions.forEach(([px, pz]) => {
      for (let y = 1; y <= 5; y++) {
        setBlock(cx + px, cy + y, cz + pz, BlockType.WHITE_MARBLE);
      }
      setBlock(cx + px, cy + 6, cz + pz, BlockType.GOLD_BLOCK);
    });

    for (let x = -8; x <= 8; x++) {
      setBlock(cx + x, cy + 6, cz - 8, BlockType.OASIS_SANDSTONE);
      setBlock(cx + x, cy + 6, cz + 8, BlockType.OASIS_SANDSTONE);
    }
    for (let z = -8; z <= 8; z++) {
      setBlock(cx - 8, cy + 6, cz + z, BlockType.OASIS_SANDSTONE);
      setBlock(cx + 8, cy + 6, cz + z, BlockType.OASIS_SANDSTONE);
    }

    for (let x = -3; x <= 3; x++) {
      for (let z = -3; z <= 3; z++) {
        setBlock(cx + x, cy + 7, cz + z, BlockType.TURQUOISE_MOSAIC);
      }
    }
    for (let x = -2; x <= 2; x++) {
      for (let z = -2; z <= 2; z++) {
        setBlock(cx + x, cy + 8, cz + z, BlockType.GOLDEN_ARABESQUE);
      }
    }
    setBlock(cx, cy + 9, cz, BlockType.GOLD_BLOCK);
    setBlock(cx, cy + 10, cz, BlockType.TORCH);

    const mx = cx + 8;
    const mz = cz - 8;
    for (let y = 1; y <= 16; y++) {
      setBlock(mx, cy + y, mz, BlockType.WHITE_MARBLE);
      setBlock(mx + 1, cy + y, mz, BlockType.WHITE_MARBLE);
      setBlock(mx, cy + y, mz + 1, BlockType.WHITE_MARBLE);
      setBlock(mx + 1, cy + y, mz + 1, BlockType.WHITE_MARBLE);
    }
    for (let dx = -1; dx <= 2; dx++) {
      for (let dz = -1; dz <= 2; dz++) {
        setBlock(mx + dx, cy + 14, mz + dz, BlockType.TURQUOISE_MOSAIC);
      }
    }
    setBlock(mx, cy + 17, mz, BlockType.GOLD_BLOCK);

    const realmChestKey = `${cx},${cy + 1},${cz}`;
    setBlock(cx, cy + 1, cz, BlockType.CHEST);
    const realmChestItems: (ItemStack | null)[] = new Array(27).fill(null);
    realmChestItems[0] = { id: 'diamond', isBlock: false, itemType: 'diamond', count: 12, maxStack: 64 };
    realmChestItems[1] = { id: 'gold_ingot', isBlock: false, itemType: 'gold_ingot', count: 24, maxStack: 64 };
    realmChestItems[2] = { id: 'turquoise_mosaic', isBlock: true, blockType: BlockType.TURQUOISE_MOSAIC, count: 16, maxStack: 64 };
    realmChestItems[3] = { id: 'golden_arabesque', isBlock: true, blockType: BlockType.GOLDEN_ARABESQUE, count: 16, maxStack: 64 };
    realmChestItems[4] = { id: 'white_marble', isBlock: true, blockType: BlockType.WHITE_MARBLE, count: 32, maxStack: 64 };
    chests[realmChestKey] = realmChestItems;
  }
}
