import * as THREE from 'three';
import {
  BlockType,
  Dimension,
  GameSettings,
  ItemStack,
  PlayerPosition,
  PlayerStats,
  SavedWorld,
} from '../types/game';
import { soundManager } from './audio';
import { createMobMesh, MobMeshInstance, updateMobAI } from './mobs';
import { getBlockMaterial, getBlockName } from './textures';
import { WorldGenerator } from './worldGen';

export interface EngineCallbacks {
  onUpdateHUD: (data: {
    stats: PlayerStats;
    pos: PlayerPosition;
    dimension: Dimension;
    timeOfDay: number;
    fps: number;
    targetBlockName: string | null;
  }) => void;
  onOpenInventory: () => void;
  onOpenChest: (chestKey: string) => void;
  onOpenCraftingTable: () => void;
  onOpenFurnace: () => void;
  onPlayerDeath: () => void;
}

export class VoxelEngine {
  private container: HTMLElement;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private isRunning: boolean = false;
  private frameId: number = 0;

  public world: SavedWorld;
  public settings: GameSettings;
  public callbacks: EngineCallbacks;

  public blocks: Map<string, BlockType> = new Map();
  private blockMeshes: Map<string, THREE.Mesh> = new Map();
  private sharedBoxGeo: THREE.BoxGeometry = new THREE.BoxGeometry(1, 1, 1);

  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private cloudsMesh: THREE.Mesh | null = null;

  private selectionBox: THREE.LineSegments;
  private targetBlock: { x: number; y: number; z: number; faceNormal: THREE.Vector3 } | null = null;
  private miningProgress: number = 0;
  private isMining: boolean = false;

  public playerVel = new THREE.Vector3();
  public isOnGround: boolean = false;
  public isUnderwater: boolean = false;
  public isSneaking: boolean = false;
  public isJumping: boolean = false;
  public moveInput = { forward: 0, right: 0 };
  private fallDistance: number = 0;

  private playerModel: THREE.Group | null = null;
  private mobInstances: MobMeshInstance[] = [];

  private lastTime: number = performance.now();
  private frameCount: number = 0;
  private fps: number = 60;
  private fpsTimer: number = 0;
  private hungerTimer: number = 0;
  private regenTimer: number = 0;

  constructor(
    container: HTMLElement,
    world: SavedWorld,
    settings: GameSettings,
    callbacks: EngineCallbacks
  ) {
    this.container = container;
    this.world = world;
    this.settings = settings;
    this.callbacks = callbacks;

    this.scene = new THREE.Scene();

    const aspect = container.clientWidth / container.clientHeight;
    this.camera = new THREE.PerspectiveCamera(this.settings.fov, aspect, 0.1, 200);

    this.renderer = new THREE.WebGLRenderer({
      antialias: settings.graphicsQuality === 'fancy',
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);

    this.hemiLight = new THREE.HemisphereLight(0xb1e1ff, 0x555555, 0.7);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xffffff, 1.2);
    this.sunLight.position.set(20, 40, 20);
    this.scene.add(this.sunLight);

    const selGeo = new THREE.BoxGeometry(1.005, 1.005, 1.005);
    const selEdges = new THREE.EdgesGeometry(selGeo);
    this.selectionBox = new THREE.LineSegments(
      selEdges,
      new THREE.LineBasicMaterial({ color: 0x000000, linewidth: 2 })
    );
    this.selectionBox.visible = false;
    this.scene.add(this.selectionBox);

    this.buildPlayerModel();
    this.setupAtmosphere(this.world.dimension);
    this.loadWorldDimension(this.world.dimension);
    this.setupEventListeners();
  }

  private buildPlayerModel() {
    this.playerModel = new THREE.Group();
    const skinMat = new THREE.MeshLambertMaterial({ color: 0xbd8e72 });
    const shirtMat = new THREE.MeshLambertMaterial({ color: 0x0ea5e9 });
    const pantsMat = new THREE.MeshLambertMaterial({ color: 0x3b82f6 });

    const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), skinMat);
    head.position.y = 1.5;

    const body = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.7, 0.25), shirtMat);
    body.position.y = 0.9;

    const lArm = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.65, 0.18), skinMat);
    lArm.position.set(-0.35, 0.9, 0);
    const rArm = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.65, 0.18), skinMat);
    rArm.position.set(0.35, 0.9, 0);

    const lLeg = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.7, 0.2), pantsMat);
    lLeg.position.set(-0.14, 0.35, 0);
    const rLeg = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.7, 0.2), pantsMat);
    rLeg.position.set(0.14, 0.35, 0);

    this.playerModel.add(head, body, lArm, rArm, lLeg, rLeg);
    this.playerModel.visible = this.settings.thirdPerson;
    this.scene.add(this.playerModel);
  }

  public setupAtmosphere(dimension: Dimension) {
    if (this.cloudsMesh) {
      this.scene.remove(this.cloudsMesh);
      this.cloudsMesh = null;
    }

    if (dimension === 'overworld') {
      this.scene.background = new THREE.Color(0x87ceeb);
      this.scene.fog = new THREE.FogExp2(0x87ceeb, 0.015);
      this.hemiLight.color.setHex(0xb1e1ff);
      this.hemiLight.groundColor.setHex(0x555555);
      this.sunLight.color.setHex(0xffffff);

      const cloudGeo = new THREE.PlaneGeometry(160, 160);
      const cloudMat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.65,
        side: THREE.DoubleSide,
      });
      this.cloudsMesh = new THREE.Mesh(cloudGeo, cloudMat);
      this.cloudsMesh.position.y = 42;
      this.cloudsMesh.rotation.x = -Math.PI / 2;
      this.scene.add(this.cloudsMesh);
    } else if (dimension === 'nether') {
      this.scene.background = new THREE.Color(0x350808);
      this.scene.fog = new THREE.FogExp2(0x350808, 0.038);
      this.hemiLight.color.setHex(0x6b1010);
      this.hemiLight.groundColor.setHex(0x1a0404);
      this.sunLight.color.setHex(0xff5533);
    } else if (dimension === 'the_end') {
      this.scene.background = new THREE.Color(0x0e051a);
      this.scene.fog = new THREE.FogExp2(0x0e051a, 0.024);
      this.hemiLight.color.setHex(0x3b1263);
      this.hemiLight.groundColor.setHex(0x08020e);
      this.sunLight.color.setHex(0xd8b4fe);
    } else if (dimension === 'muslim_realm') {
      this.scene.background = new THREE.Color(0xedd59e);
      this.scene.fog = new THREE.FogExp2(0xdfb876, 0.014);
      this.hemiLight.color.setHex(0xffedd5);
      this.hemiLight.groundColor.setHex(0x78350f);
      this.sunLight.color.setHex(0xfffbeb);

      const cloudGeo = new THREE.PlaneGeometry(160, 160);
      const cloudMat = new THREE.MeshBasicMaterial({
        color: 0xfff7ed,
        transparent: true,
        opacity: 0.5,
        side: THREE.DoubleSide,
      });
      this.cloudsMesh = new THREE.Mesh(cloudGeo, cloudMat);
      this.cloudsMesh.position.y = 44;
      this.cloudsMesh.rotation.x = -Math.PI / 2;
      this.scene.add(this.cloudsMesh);
    }
  }

  public loadWorldDimension(dimension: Dimension) {
    this.world.dimension = dimension;
    this.setupAtmosphere(dimension);

    this.blockMeshes.forEach((mesh) => {
      this.scene.remove(mesh);
    });
    this.blockMeshes.clear();
    this.blocks.clear();

    this.mobInstances.forEach((inst) => {
      this.scene.remove(inst.group);
    });
    this.mobInstances = [];

    const generator = new WorldGenerator(this.world.seed);
    const result = generator.generateInitialWorld(dimension);

    result.blocks.forEach((type, key) => {
      this.blocks.set(key, type);
    });

    Object.entries(this.world.modifiedBlocks).forEach(([key, type]) => {
      if (type === BlockType.AIR) {
        this.blocks.delete(key);
      } else {
        this.blocks.set(key, type);
      }
    });

    Object.entries(result.chests).forEach(([key, items]) => {
      if (!this.world.chests[key]) {
        this.world.chests[key] = items;
      }
    });

    this.rebuildAllMeshes();

    result.initialMobs.forEach((m) => {
      const isPassive = [
        'villager',
        'iron_golem',
        'cow',
        'sheep',
        'pig',
        'chicken',
        'horse',
      ].includes(m.type);
      const entity = {
        id: `mob_${Math.random().toString(36).substring(2, 9)}`,
        type: m.type,
        isPassive,
        x: m.x,
        y: m.y,
        z: m.z,
        vx: 0,
        vy: 0,
        vz: 0,
        yaw: Math.random() * Math.PI * 2,
        pitch: 0,
        health: m.type === 'iron_golem' ? 100 : m.type === 'ender_dragon' ? 200 : 20,
        maxHealth: m.type === 'iron_golem' ? 100 : m.type === 'ender_dragon' ? 200 : 20,
        walkCycle: 0,
        attackCooldown: 0,
        stateTimer: Math.random() * 2,
      };
      const instance = createMobMesh(entity);
      this.scene.add(instance.group);
      this.mobInstances.push(instance);
    });

    if (this.world.playerPos.y <= 0) {
      this.world.playerPos = {
        x: result.spawnPos.x,
        y: result.spawnPos.y,
        z: result.spawnPos.z,
        pitch: 0,
        yaw: 0,
      };
    }
  }

  private rebuildAllMeshes() {
    this.blocks.forEach((type, key) => {
      if (type === BlockType.AIR) return;
      const [x, y, z] = key.split(',').map(Number);
      this.createBlockMesh(x, y, z, type);
    });
  }

  private createBlockMesh(x: number, y: number, z: number, type: BlockType) {
    const key = `${x},${y},${z}`;
    if (this.blockMeshes.has(key)) return;

    const mat = getBlockMaterial(type);
    const mesh = new THREE.Mesh(this.sharedBoxGeo, mat);
    mesh.position.set(x + 0.5, y + 0.5, z + 0.5);
    mesh.userData = { blockX: x, blockY: y, blockZ: z, blockType: type };
    this.scene.add(mesh);
    this.blockMeshes.set(key, mesh);
  }

  public setBlock(x: number, y: number, z: number, type: BlockType) {
    const key = `${x},${y},${z}`;
    if (type === BlockType.AIR) {
      this.blocks.delete(key);
      const mesh = this.blockMeshes.get(key);
      if (mesh) {
        this.scene.remove(mesh);
        this.blockMeshes.delete(key);
      }
      this.world.modifiedBlocks[key] = BlockType.AIR;
    } else {
      this.blocks.set(key, type);
      const existing = this.blockMeshes.get(key);
      if (existing) {
        existing.material = getBlockMaterial(type);
        existing.userData.blockType = type;
      } else {
        this.createBlockMesh(x, y, z, type);
      }
      this.world.modifiedBlocks[key] = type;
    }
  }

  public getBlock(x: number, y: number, z: number): BlockType {
    return this.blocks.get(`${x},${y},${z}`) ?? BlockType.AIR;
  }

  private updateTargetBlock() {
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
    raycaster.far = 5.5;

    const meshes = Array.from(this.blockMeshes.values());
    const intersects = raycaster.intersectObjects(meshes, false);

    if (intersects.length > 0) {
      const hit = intersects[0];
      const mesh = hit.object as THREE.Mesh;
      const bx = mesh.userData.blockX;
      const by = mesh.userData.blockY;
      const bz = mesh.userData.blockZ;
      const normal = hit.face ? hit.face.normal.clone() : new THREE.Vector3(0, 1, 0);

      this.targetBlock = { x: bx, y: by, z: bz, faceNormal: normal };
      this.selectionBox.position.set(bx + 0.5, by + 0.5, bz + 0.5);
      this.selectionBox.visible = true;
    } else {
      this.targetBlock = null;
      this.selectionBox.visible = false;
    }
  }

  public startMining() {
    if (this.world.gameMode === 'spectator') return;
    this.isMining = true;
    this.miningProgress = 0;
  }

  public stopMining() {
    this.isMining = false;
    this.miningProgress = 0;
  }

  private handleMining(delta: number) {
    if (!this.isMining || !this.targetBlock) {
      this.miningProgress = 0;
      return;
    }

    const { x, y, z } = this.targetBlock;
    const blockType = this.getBlock(x, y, z);
    if (blockType === BlockType.AIR || blockType === BlockType.OBSIDIAN && y === 0) return;

    if (this.world.gameMode === 'adventure') {
      const activeItem = this.world.hotbar[this.world.activeHotbarIndex];
      if (!activeItem || !activeItem.itemType?.includes('pickaxe')) {
        return;
      }
    }

    soundManager.playDig();

    let breakDuration = 1.0;
    const activeItem = this.world.hotbar[this.world.activeHotbarIndex];

    if (activeItem?.itemType === 'diamond_pickaxe') breakDuration = 0.2;
    else if (activeItem?.itemType === 'iron_pickaxe') breakDuration = 0.4;
    else if (activeItem?.itemType === 'stone_pickaxe') breakDuration = 0.7;
    else if (activeItem?.itemType === 'wooden_pickaxe') breakDuration = 1.0;
    else if (blockType === BlockType.DIRT || blockType === BlockType.SAND || blockType === BlockType.GRASS) {
      breakDuration = activeItem?.itemType?.includes('shovel') ? 0.25 : 0.6;
    } else if (blockType === BlockType.OAK_WOOD || blockType === BlockType.PALM_WOOD) {
      breakDuration = activeItem?.itemType?.includes('axe') ? 0.35 : 1.2;
    } else if (blockType === BlockType.OAK_LEAVES || blockType === BlockType.PALM_LEAVES) {
      breakDuration = 0.2;
    }

    this.miningProgress += delta / breakDuration;

    if (this.miningProgress >= 1.0) {
      this.setBlock(x, y, z, BlockType.AIR);
      soundManager.playBreak();
      this.miningProgress = 0;

      this.giveMinedItem(blockType);

      if (activeItem && activeItem.durability !== undefined) {
        activeItem.durability -= 1;
        if (activeItem.durability <= 0) {
          this.world.hotbar[this.world.activeHotbarIndex] = null;
          soundManager.playBreak();
        }
      }
    }
  }

  private giveMinedItem(blockType: BlockType) {
    if (this.world.gameMode === 'spectator') return;

    let itemStack: ItemStack;
    if (blockType === BlockType.STONE) {
      itemStack = { id: 'cobblestone', isBlock: true, blockType: BlockType.COBBLESTONE, count: 1, maxStack: 64 };
    } else if (blockType === BlockType.GRASS) {
      itemStack = { id: 'dirt', isBlock: true, blockType: BlockType.DIRT, count: 1, maxStack: 64 };
    } else if (blockType === BlockType.COAL_ORE) {
      itemStack = { id: 'coal', isBlock: false, itemType: 'coal', count: 1, maxStack: 64 };
    } else if (blockType === BlockType.DIAMOND_ORE) {
      itemStack = { id: 'diamond', isBlock: false, itemType: 'diamond', count: 1, maxStack: 64 };
    } else {
      itemStack = { id: `block_${blockType}`, isBlock: true, blockType, count: 1, maxStack: 64 };
    }

    this.addItemToInventory(itemStack);
  }

  public addItemToInventory(item: ItemStack): boolean {
    for (let i = 0; i < this.world.hotbar.length; i++) {
      const slot = this.world.hotbar[i];
      if (slot && slot.id === item.id && slot.count < slot.maxStack) {
        const canAdd = Math.min(item.count, slot.maxStack - slot.count);
        slot.count += canAdd;
        item.count -= canAdd;
        if (item.count <= 0) return true;
      }
    }

    for (let i = 0; i < this.world.hotbar.length; i++) {
      if (this.world.hotbar[i] === null) {
        this.world.hotbar[i] = { ...item };
        return true;
      }
    }

    for (let i = 0; i < this.world.inventory.length; i++) {
      const slot = this.world.inventory[i];
      if (slot && slot.id === item.id && slot.count < slot.maxStack) {
        const canAdd = Math.min(item.count, slot.maxStack - slot.count);
        slot.count += canAdd;
        item.count -= canAdd;
        if (item.count <= 0) return true;
      }
    }

    for (let i = 0; i < this.world.inventory.length; i++) {
      if (this.world.inventory[i] === null) {
        this.world.inventory[i] = { ...item };
        return true;
      }
    }

    return false;
  }

  public interactOrPlace() {
    if (!this.targetBlock) return;
    const { x, y, z, faceNormal } = this.targetBlock;
    const targetType = this.getBlock(x, y, z);

    if (targetType === BlockType.CRAFTING_TABLE) {
      this.callbacks.onOpenCraftingTable();
      return;
    }
    if (targetType === BlockType.FURNACE) {
      this.callbacks.onOpenFurnace();
      return;
    }
    if (targetType === BlockType.CHEST) {
      const key = `${x},${y},${z}`;
      if (!this.world.chests[key]) {
        this.world.chests[key] = new Array(27).fill(null);
      }
      this.callbacks.onOpenChest(key);
      soundManager.playChest(true);
      return;
    }

    const activeItem = this.world.hotbar[this.world.activeHotbarIndex];
    if (
      activeItem &&
      ['apple', 'bread', 'cooked_beef', 'raw_beef'].includes(activeItem.itemType || '')
    ) {
      if (this.world.playerStats.hunger < 20) {
        soundManager.playEat();
        const restore = activeItem.itemType === 'cooked_beef' ? 8 : activeItem.itemType === 'bread' ? 5 : 3;
        this.world.playerStats.hunger = Math.min(20, this.world.playerStats.hunger + restore);
        activeItem.count -= 1;
        if (activeItem.count <= 0) {
          this.world.hotbar[this.world.activeHotbarIndex] = null;
        }
        return;
      }
    }

    if (!activeItem || !activeItem.isBlock || activeItem.blockType === undefined) return;
    if (this.world.gameMode === 'adventure') return;

    const px = x + Math.round(faceNormal.x);
    const py = y + Math.round(faceNormal.y);
    const pz = z + Math.round(faceNormal.z);

    const playerBlockX = Math.floor(this.world.playerPos.x);
    const playerBlockY = Math.floor(this.world.playerPos.y);
    const playerBlockZ = Math.floor(this.world.playerPos.z);
    if (
      px === playerBlockX &&
      pz === playerBlockZ &&
      (py === playerBlockY || py === playerBlockY + 1)
    ) {
      return;
    }

    this.setBlock(px, py, pz, activeItem.blockType);
    soundManager.playPlace();

    if (this.world.gameMode !== 'spectator') {
      activeItem.count -= 1;
      if (activeItem.count <= 0) {
        this.world.hotbar[this.world.activeHotbarIndex] = null;
      }
    }
  }

  public attack() {
    soundManager.playHit();

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
    raycaster.far = 4.0;

    const mobObjects = this.mobInstances.map((m) => m.group);
    const intersects = raycaster.intersectObjects(mobObjects, true);

    if (intersects.length > 0) {
      const hit = intersects[0];
      let obj: THREE.Object3D | null = hit.object;
      while (obj && !this.mobInstances.some((m) => m.group === obj)) {
        obj = obj.parent;
      }
      const mobInst = this.mobInstances.find((m) => m.group === obj);
      if (mobInst) {
        const activeItem = this.world.hotbar[this.world.activeHotbarIndex];
        let dmg = 2;
        if (activeItem?.itemType === 'diamond_sword') dmg = 10;
        else if (activeItem?.itemType === 'iron_sword') dmg = 7;
        else if (activeItem?.itemType === 'stone_sword') dmg = 5;
        else if (activeItem?.itemType === 'wooden_sword') dmg = 4;

        mobInst.entity.health -= dmg;

        const kbDir = new THREE.Vector3(
          Math.sin(this.world.playerPos.yaw),
          0.3,
          Math.cos(this.world.playerPos.yaw)
        ).normalize();
        mobInst.entity.vx += kbDir.x * 4;
        mobInst.entity.vy += 3;
        mobInst.entity.vz += kbDir.z * 4;

        mobInst.group.traverse((c: THREE.Object3D) => {
          if (c instanceof THREE.Mesh && c.material) {
            const origColor = c.material.color?.getHex();
            c.material.color?.setHex(0xff0000);
            setTimeout(() => {
              if (origColor !== undefined) c.material.color?.setHex(origColor);
            }, 120);
          }
        });

        if (mobInst.entity.health <= 0) {
          this.scene.remove(mobInst.group);
          this.mobInstances = this.mobInstances.filter((m) => m !== mobInst);

          if (mobInst.entity.type === 'cow') {
            this.addItemToInventory({ id: 'raw_beef', isBlock: false, itemType: 'raw_beef', count: 2, maxStack: 64 });
          } else if (mobInst.entity.type === 'iron_golem') {
            this.addItemToInventory({ id: 'iron_ingot', isBlock: false, itemType: 'iron_ingot', count: 4, maxStack: 64 });
          } else if (mobInst.entity.type === 'chicken') {
            this.addItemToInventory({ id: 'feather', isBlock: false, itemType: 'feather', count: 2, maxStack: 64 });
          } else if (mobInst.entity.type === 'zombie') {
            this.addItemToInventory({ id: 'rotten_flesh', isBlock: false, itemType: 'rotten_flesh', count: 1, maxStack: 64 });
          } else if (mobInst.entity.type === 'ender_dragon') {
            soundManager.playLevelUp();
            this.world.playerStats.score += 1000;
          }
        }
      }
    }
  }

  private updatePlayer(delta: number) {
    const isSpectator = this.world.gameMode === 'spectator';
    const pos = this.world.playerPos;

    if (isSpectator) {
      const speed = 12 * delta;
      const forward = new THREE.Vector3(
        -Math.sin(pos.yaw) * Math.cos(pos.pitch),
        Math.sin(pos.pitch),
        -Math.cos(pos.yaw) * Math.cos(pos.pitch)
      );
      const right = new THREE.Vector3(Math.cos(pos.yaw), 0, -Math.sin(pos.yaw));

      pos.x += (forward.x * this.moveInput.forward + right.x * this.moveInput.right) * speed;
      pos.y += (forward.y * this.moveInput.forward + (this.isJumping ? 1 : this.isSneaking ? -1 : 0)) * speed;
      pos.z += (forward.z * this.moveInput.forward + right.z * this.moveInput.right) * speed;
      return;
    }

    const currentBlock = this.getBlock(Math.floor(pos.x), Math.floor(pos.y + 1), Math.floor(pos.z));
    this.isUnderwater = currentBlock === BlockType.WATER || currentBlock === BlockType.OASIS_WATER;

    const walkSpeed = this.isSneaking ? 2.5 : this.isUnderwater ? 3.0 : 4.5;
    const sin = Math.sin(pos.yaw);
    const cos = Math.cos(pos.yaw);

    const wishDirX = -sin * this.moveInput.forward + cos * this.moveInput.right;
    const wishDirZ = -cos * this.moveInput.forward - sin * this.moveInput.right;

    this.playerVel.x = wishDirX * walkSpeed;
    this.playerVel.z = wishDirZ * walkSpeed;

    if (this.isUnderwater) {
      this.playerVel.y -= 4 * delta;
      if (this.isJumping) this.playerVel.y = 3.0;
    } else {
      this.playerVel.y -= 22 * delta;
      if (this.isOnGround && this.isJumping) {
        this.playerVel.y = 7.5;
        this.isOnGround = false;
        soundManager.playFootstep();
      }
    }

    const nextX = pos.x + this.playerVel.x * delta;
    const nextY = pos.y + this.playerVel.y * delta;
    const nextZ = pos.z + this.playerVel.z * delta;

    if (this.checkCollision(pos.x, nextY, pos.z)) {
      if (this.playerVel.y < 0) {
        this.isOnGround = true;
        if (this.fallDistance > 3.5 && !this.isUnderwater) {
          const dmg = Math.floor(this.fallDistance - 3);
          this.damagePlayer(dmg);
        }
        this.fallDistance = 0;
      }
      this.playerVel.y = 0;
    } else {
      pos.y = nextY;
      if (this.playerVel.y < 0) {
        this.fallDistance += Math.abs(this.playerVel.y * delta);
      }
      this.isOnGround = false;
    }

    if (!this.checkCollision(nextX, pos.y, pos.z)) {
      pos.x = nextX;
    } else if (this.isOnGround && !this.checkCollision(nextX, pos.y + 1.1, pos.z)) {
      pos.y += 1.0;
      pos.x = nextX;
    }

    if (!this.checkCollision(pos.x, pos.y, nextZ)) {
      pos.z = nextZ;
    } else if (this.isOnGround && !this.checkCollision(pos.x, pos.y + 1.1, nextZ)) {
      pos.y += 1.0;
      pos.z = nextZ;
    }

    if (
      this.isOnGround &&
      (Math.abs(this.playerVel.x) > 0.1 || Math.abs(this.playerVel.z) > 0.1)
    ) {
      if (Math.random() < delta * 4) {
        soundManager.playFootstep();
      }
    }

    if (pos.y < -15) {
      this.damagePlayer(100);
    }
  }

  private checkCollision(px: number, py: number, pz: number): boolean {
    const halfWidth = 0.28;
    const height = 1.8;

    const minX = Math.floor(px - halfWidth);
    const maxX = Math.floor(px + halfWidth);
    const minY = Math.floor(py);
    const maxY = Math.floor(py + height);
    const minZ = Math.floor(pz - halfWidth);
    const maxZ = Math.floor(pz + halfWidth);

    for (let x = minX; x <= maxX; x++) {
      for (let y = minY; y <= maxY; y++) {
        for (let z = minZ; z <= maxZ; z++) {
          const block = this.getBlock(x, y, z);
          if (
            block !== BlockType.AIR &&
            block !== BlockType.WATER &&
            block !== BlockType.OASIS_WATER &&
            block !== BlockType.TORCH
          ) {
            return true;
          }
        }
      }
    }
    return false;
  }

  public damagePlayer(dmg: number) {
    if (this.world.gameMode === 'spectator' || this.world.playerStats.isDead) return;

    soundManager.playHit();
    this.world.playerStats.health = Math.max(0, this.world.playerStats.health - dmg);

    if (this.world.playerStats.health <= 0) {
      this.world.playerStats.isDead = true;
      this.callbacks.onPlayerDeath();
    }
  }

  public respawn() {
    this.world.playerStats.health = this.world.playerStats.maxHealth;
    this.world.playerStats.hunger = this.world.playerStats.maxHunger;
    this.world.playerStats.isDead = false;

    this.world.playerPos = {
      x: 0,
      y: 16,
      z: 4,
      pitch: 0,
      yaw: 0,
    };
    this.playerVel.set(0, 0, 0);
  }

  private updateCamera() {
    const pos = this.world.playerPos;

    if (this.settings.thirdPerson) {
      const dist = 3.6;
      const eyeY = pos.y + 1.6;
      const cx = pos.x + Math.sin(pos.yaw) * dist * Math.cos(pos.pitch);
      const cy = eyeY - Math.sin(pos.pitch) * dist + 0.6;
      const cz = pos.z + Math.cos(pos.yaw) * dist * Math.cos(pos.pitch);

      this.camera.position.set(cx, cy, cz);
      this.camera.lookAt(pos.x, eyeY, pos.z);

      if (this.playerModel) {
        this.playerModel.visible = true;
        this.playerModel.position.set(pos.x, pos.y, pos.z);
        this.playerModel.rotation.y = pos.yaw + Math.PI;
      }
    } else {
      this.camera.position.set(pos.x, pos.y + 1.62, pos.z);
      this.camera.rotation.order = 'YXZ';
      this.camera.rotation.y = pos.yaw;
      this.camera.rotation.x = pos.pitch;

      if (this.playerModel) {
        this.playerModel.visible = false;
      }
    }
  }

  private updateDayNight(delta: number) {
    if (this.world.dimension !== 'overworld') return;

    this.world.timeOfDay = (this.world.timeOfDay + delta * 0.005) % 1.0;
    const angle = this.world.timeOfDay * Math.PI * 2;

    const sunX = Math.cos(angle) * 45;
    const sunY = Math.sin(angle) * 45;
    this.sunLight.position.set(sunX, sunY, 20);

    if (sunY > 0) {
      const dayFactor = Math.min(1, sunY / 20);
      const skyR = 0.53 * dayFactor;
      const skyG = 0.81 * dayFactor;
      const skyB = 0.92 * dayFactor;
      this.scene.background = new THREE.Color(skyR, skyG, skyB);
      if (this.scene.fog instanceof THREE.FogExp2) {
        this.scene.fog.color.setRGB(skyR, skyG, skyB);
      }
      this.sunLight.intensity = 1.0 * dayFactor;
    } else {
      const nightFactor = Math.min(1, -sunY / 20);
      const skyR = 0.02 + 0.05 * (1 - nightFactor);
      const skyG = 0.02 + 0.05 * (1 - nightFactor);
      const skyB = 0.08 + 0.05 * (1 - nightFactor);
      this.scene.background = new THREE.Color(skyR, skyG, skyB);
      if (this.scene.fog instanceof THREE.FogExp2) {
        this.scene.fog.color.setRGB(skyR, skyG, skyB);
      }
      this.sunLight.intensity = 0.15;
    }

    if (this.cloudsMesh) {
      this.cloudsMesh.position.x = (this.cloudsMesh.position.x + delta * 0.4) % 160;
    }
  }

  private updateSurvival(delta: number) {
    if (this.world.gameMode !== 'survival' || this.world.playerStats.isDead) return;

    this.hungerTimer += delta;
    if (this.hungerTimer >= 25) {
      this.hungerTimer = 0;
      this.world.playerStats.hunger = Math.max(0, this.world.playerStats.hunger - 1);
    }

    this.regenTimer += delta;
    if (this.regenTimer >= 4) {
      this.regenTimer = 0;
      if (this.world.playerStats.hunger >= 18 && this.world.playerStats.health < 20) {
        this.world.playerStats.health = Math.min(20, this.world.playerStats.health + 1);
      } else if (this.world.playerStats.hunger === 0) {
        this.damagePlayer(1);
      }
    }
  }

  private tick = () => {
    if (!this.isRunning) return;

    const now = performance.now();
    const rawDelta = (now - this.lastTime) / 1000;
    this.lastTime = now;
    const delta = Math.min(rawDelta, 0.05);

    this.frameCount++;
    this.fpsTimer += delta;
    if (this.fpsTimer >= 1.0) {
      this.fps = this.frameCount;
      this.frameCount = 0;
      this.fpsTimer = 0;
    }

    this.updatePlayer(delta);
    this.updateCamera();
    this.updateTargetBlock();
    this.handleMining(delta);
    this.updateDayNight(delta);
    this.updateSurvival(delta);

    this.mobInstances.forEach((mobInst) => {
      updateMobAI(
        mobInst,
        delta,
        this.world.playerPos,
        this.world.gameMode !== 'survival',
        (dmg) => this.damagePlayer(dmg)
      );
    });

    const targetBlockName = this.targetBlock
      ? getBlockName(this.getBlock(this.targetBlock.x, this.targetBlock.y, this.targetBlock.z))
      : null;

    this.callbacks.onUpdateHUD({
      stats: this.world.playerStats,
      pos: this.world.playerPos,
      dimension: this.world.dimension,
      timeOfDay: this.world.timeOfDay,
      fps: this.fps,
      targetBlockName,
    });

    this.renderer.render(this.scene, this.camera);
    this.frameId = requestAnimationFrame(this.tick);
  };

  public start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastTime = performance.now();
    this.frameId = requestAnimationFrame(this.tick);
    soundManager.startAmbientMusic();
  }

  public stop() {
    this.isRunning = false;
    cancelAnimationFrame(this.frameId);
    soundManager.stopAmbientMusic();
  }

  public resize(width: number, height: number) {
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  public setThirdPerson(val: boolean) {
    this.settings.thirdPerson = val;
    if (this.playerModel) {
      this.playerModel.visible = val;
    }
  }

  private setupEventListeners() {
    window.addEventListener('keydown', (e) => {
      if (e.repeat) return;
      switch (e.code) {
        case 'KeyW':
          this.moveInput.forward = 1;
          break;
        case 'KeyS':
          this.moveInput.forward = -1;
          break;
        case 'KeyA':
          this.moveInput.right = -1;
          break;
        case 'KeyD':
          this.moveInput.right = 1;
          break;
        case 'Space':
          this.isJumping = true;
          break;
        case 'ShiftLeft':
        case 'ShiftRight':
          this.isSneaking = true;
          break;
        case 'KeyE':
          this.callbacks.onOpenInventory();
          break;
        case 'F5':
          e.preventDefault();
          this.setThirdPerson(!this.settings.thirdPerson);
          break;
        case 'Digit1':
        case 'Digit2':
        case 'Digit3':
        case 'Digit4':
        case 'Digit5':
        case 'Digit6':
        case 'Digit7':
        case 'Digit8':
        case 'Digit9': {
          const slot = parseInt(e.code.replace('Digit', '')) - 1;
          this.world.activeHotbarIndex = slot;
          break;
        }
      }
    });

    window.addEventListener('keyup', (e) => {
      switch (e.code) {
        case 'KeyW':
        case 'KeyS':
          this.moveInput.forward = 0;
          break;
        case 'KeyA':
        case 'KeyD':
          this.moveInput.right = 0;
          break;
        case 'Space':
          this.isJumping = false;
          break;
        case 'ShiftLeft':
        case 'ShiftRight':
          this.isSneaking = false;
          break;
      }
    });

    const dom = this.renderer.domElement;
    dom.addEventListener('mousedown', (e: MouseEvent) => {
      if (document.pointerLockElement !== dom) {
        dom.requestPointerLock?.();
      }
      if (e.button === 0) {
        this.startMining();
        this.attack();
      } else if (e.button === 2) {
        this.interactOrPlace();
      }
    });

    window.addEventListener('mouseup', (e: MouseEvent) => {
      if (e.button === 0) {
        this.stopMining();
      }
    });

    window.addEventListener('mousemove', (e: MouseEvent) => {
      if (document.pointerLockElement === dom) {
        const sens = this.settings.mouseSensitivity * 0.002;
        this.world.playerPos.yaw -= e.movementX * sens;
        this.world.playerPos.pitch -= e.movementY * sens;
        this.world.playerPos.pitch = Math.max(-1.5, Math.min(1.5, this.world.playerPos.pitch));
      }
    });

    dom.addEventListener('contextmenu', (e: MouseEvent) => e.preventDefault());
  }

  public dispose() {
    this.stop();
    this.blockMeshes.forEach((mesh) => this.scene.remove(mesh));
    this.blockMeshes.clear();
    this.mobInstances.forEach((inst) => this.scene.remove(inst.group));
    this.mobInstances = [];
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }
}
