import { BlockType, GameSettings, SavedWorld } from '../types/game';

const WORLDS_STORAGE_KEY = 'muslim_craft_worlds_v1';
const SETTINGS_STORAGE_KEY = 'muslim_craft_settings_v1';

export const DEFAULT_SETTINGS: GameSettings = {
  graphicsQuality: 'fancy',
  renderDistance: 4,
  mouseSensitivity: 0.8,
  touchSensitivity: 1.0,
  fov: 75,
  musicVolume: 0.6,
  sfxVolume: 0.8,
  thirdPerson: false,
  language: 'en',
  showCoordinates: true,
  showFps: false,
};

export const PRESET_WORLD_0786: SavedWorld = {
  id: 'world_0786_legendary',
  name: '0786 Legendary Village',
  seed: '0786',
  gameMode: 'survival',
  dimension: 'overworld',
  createdAt: Date.now() - 3600000,
  lastPlayed: Date.now(),
  playerPos: { x: 0, y: 15, z: 4, pitch: 0, yaw: 0 },
  playerStats: {
    health: 20,
    maxHealth: 20,
    hunger: 20,
    maxHunger: 20,
    saturation: 10,
    armor: 0,
    score: 0,
    isDead: false,
  },
  inventory: new Array(27).fill(null),
  hotbar: [
    { id: 'stone_pickaxe', isBlock: false, itemType: 'stone_pickaxe', count: 1, maxStack: 1, durability: 132, maxDurability: 132 },
    { id: 'stone_sword', isBlock: false, itemType: 'stone_sword', count: 1, maxStack: 1, durability: 132, maxDurability: 132 },
    { id: 'bread', isBlock: false, itemType: 'bread', count: 8, maxStack: 64 },
    { id: 'torch', isBlock: true, blockType: BlockType.TORCH, count: 16, maxStack: 64 },
    { id: 'oak_wood', isBlock: true, blockType: BlockType.OAK_WOOD, count: 32, maxStack: 64 },
    null,
    null,
    null,
    null,
  ],
  activeHotbarIndex: 0,
  chests: {},
  modifiedBlocks: {},
  timeOfDay: 0.25,
};

export class StorageService {
  public static loadSettings(): GameSettings {
    try {
      const data = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (data) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
      }
    } catch {}
    return { ...DEFAULT_SETTINGS };
  }

  public static saveSettings(settings: GameSettings) {
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch {}
  }

  public static loadWorlds(): SavedWorld[] {
    try {
      const raw = localStorage.getItem(WORLDS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {}
    const defaultList = [PRESET_WORLD_0786];
    StorageService.saveWorlds(defaultList);
    return defaultList;
  }

  public static saveWorlds(worlds: SavedWorld[]) {
    try {
      localStorage.setItem(WORLDS_STORAGE_KEY, JSON.stringify(worlds));
    } catch {}
  }

  public static saveWorld(world: SavedWorld) {
    const list = StorageService.loadWorlds();
    const idx = list.findIndex((w) => w.id === world.id);
    if (idx >= 0) {
      list[idx] = world;
    } else {
      list.unshift(world);
    }
    StorageService.saveWorlds(list);
  }

  public static deleteWorld(worldId: string) {
    const list = StorageService.loadWorlds().filter((w) => w.id !== worldId);
    StorageService.saveWorlds(list);
  }
}
